from pathlib import Path

import numpy as np

from app.analyzer import analyze_document, normalize_config, prefab_id_for_path
from app.map_parser import MapDocument, PrefabInstance, decode_biome, parse_map
from app.renderer import NORMAL_MAP_STRENGTH, SPLAT_PALETTE, _biome_weights, _display_point


def test_demo_map_matches_rock_and_ice_rules():
    payload = Path("examples/demo-map.json").read_bytes()
    doc = parse_map(payload, "demo-map.json")
    report = analyze_document(doc)
    assert report["summary"]["prefab_count"] == 9
    assert report["summary"]["matched_marker_count"] == 5
    assert report["summary"]["rule_matches"]["god-rock"] == 3
    assert report["summary"]["rule_matches"]["ice-lake"] == 1
    assert report["summary"]["rule_matches"]["cave"] == 1
    ice_marker = next(marker for marker in report["markers"] if marker["rule_id"] == "ice-lake")
    assert ice_marker["analysis"]["building"]["status"] == "blocked"
    god_rock = next(marker for marker in report["markers"] if marker["rule_id"] == "god-rock")
    assert god_rock["short_name"] in {"rock_formation_a", "rock_formation_e", "rock_formation_f"}
    assert len(god_rock["grid_reference"]["reference"]) >= 2
    assert "quality" not in god_rock["analysis"]
    gradual_rock = next(marker for marker in report["markers"] if marker["position"]["x"] == -900.0)
    assert "quality" not in gradual_rock["analysis"]
    topology = gradual_rock["analysis"]["topology"]
    assert topology["sample_grid"]["size"] == 27
    assert len(topology["sample_grid"]["cells"]) == 27
    assert len(topology["sample_grid"]["heights_m"]) == 27
    assert topology["sample_grid"]["radius_m"] == 40.0
    assert topology["sample_grid"]["cell_m"] == 2.963
    assert topology["sample_grid"]["foundation_reference"] == {"footprint_m": 3.0, "height_step_m": 1.25, "step_slope_deg": 22.62}
    assert topology["sample_grid"]["axis_labels"] == {"top": "North", "bottom": "South", "left": "West", "right": "East"}
    assert all(
        height is not None
        for labels, heights in zip(topology["sample_grid"]["cells"], topology["sample_grid"]["heights_m"])
        for label, height in zip(labels, heights)
        if label is not None
    )
    assert topology["sample_grid"]["height_min_m"] <= topology["sample_grid"]["center_height_m"] <= topology["sample_grid"]["height_max_m"]
    assert topology["sample_grid"]["height_min_m"] <= topology["sample_grid"]["height_max_m"]
    assert len(topology["sample_grid"]["slope_deg"]) == 27
    assert topology["sample_grid"]["slope_min_deg"] <= topology["sample_grid"]["slope_max_deg"]
    assert topology["sample_grid"]["rise_min_m"] <= 1.25 <= topology["sample_grid"]["rise_max_m"]
    assert len(topology["sample_grid"]["rise_per_foundation_m"]) == 27
    assert all(
        slope is not None
        for heights, slopes in zip(topology["sample_grid"]["heights_m"], topology["sample_grid"]["slope_deg"])
        for height, slope in zip(heights, slopes)
        if height is not None
    )
    ice_marker = next(marker for marker in report["markers"] if marker["rule_id"] == "ice-lake")
    assert "sample_grid" not in ice_marker["analysis"]["topology"]
    ice = next(marker for marker in report["markers"] if marker["rule_id"] == "ice-lake")
    assert ice["analysis"]["proximity"]["nearby_prefab_count"] >= 3
    assert ice["analysis"]["proximity"]["center_prefab_count"] >= 1


def test_unknown_prefab_ids_are_reported():
    payload = Path("examples/demo-map.json").read_text()
    payload = payload.replace('"prefab":"assets/bundled/prefabs/autospawn/decor/v3_rock_formations_large/rock_formation_a.prefab"', '"prefab":""', 1)
    doc = parse_map(payload.encode(), "anonymous.json")
    report = analyze_document(doc)
    assert report["summary"]["unresolved_id_count"] == 1
    assert any("prefab IDs" in warning for warning in report["warnings"])


def test_default_god_rock_rule_includes_formation_f_id():
    config = normalize_config(None)
    rule = next(item for item in config["rules"] if item["id"] == "god-rock")
    path = "assets/bundled/prefabs/autospawn/decor/v3_rock_formations_large/rock_formation_f.prefab"
    assert path in rule["paths"]
    assert "291142845" in rule["ids"]


def test_rock_formation_f_id_matches_native_prefab():
    doc = MapDocument(prefabs=[PrefabInstance(prefab_id=291142845)])
    report = analyze_document(doc)
    assert report["summary"]["matched_marker_count"] == 1
    assert report["markers"][0]["short_name"] == "rock_formation_f"


def test_current_five_channel_biome_map_is_decoded():
    resolution = 8
    payload = bytes([0] * (5 * resolution * resolution))
    decoded = decode_biome(MapDocument(maps={"biome": payload}))
    assert decoded is not None
    assert decoded.shape == (5, resolution, resolution)


def test_renderer_retains_current_five_biome_channels():
    values = np.zeros((5, 8, 8), dtype=np.uint8)
    values[4] = 255
    weights = _biome_weights(values, (8, 8))
    assert weights is not None
    assert weights.shape == (5, 8, 8)
    assert float(weights[4].mean()) == 1.0


def test_requested_palette_and_normal_strength_are_fixed():
    assert NORMAL_MAP_STRENGTH == 1.5
    assert tuple(SPLAT_PALETTE[0].astype(int)) == (153, 122, 84)
    assert tuple(SPLAT_PALETTE[6].astype(int)) == (220, 237, 240)
    assert tuple(SPLAT_PALETTE[7].astype(int)) == (35, 71, 70)


def test_rustedit_reference_orientation_flips_native_rows():
    doc = MapDocument(size_m=100.0, origin_x_m=0.0, origin_z_m=0.0)
    assert _display_point(doc, 10.0, 20.0, 100.0, 100.0, "flip_y") == (10.0, 80.0)
    # Keep the previous transforms available for legacy reports.
    assert _display_point(doc, 10.0, 20.0, 100.0, 100.0, "rotate_ccw") == (20.0, 90.0)
    assert _display_point(doc, 10.0, 20.0, 100.0, 100.0, "rotate_cw") == (80.0, 10.0)


def test_native_starter_paths_derive_prefab_ids():
    paths = [
        "assets/bundled/prefabs/autospawn/decor/v3_rock_formations_large/rock_formation_a.prefab",
        "assets/bundled/prefabs/autospawn/monument/ice_lakes/ice_lake_1.prefab",
        "assets/bundled/prefabs/autospawn/monument/cave/cave_small_easy.prefab",
    ]
    doc = MapDocument(prefabs=[PrefabInstance(prefab_id=prefab_id_for_path(path)) for path in paths])
    report = analyze_document(doc)
    assert report["summary"]["matched_marker_count"] == 3
    assert report["summary"]["unresolved_id_count"] == 0
    ice = next(marker for marker in report["markers"] if marker["rule_id"] == "ice-lake")
    assert ice["analysis"]["building"]["status"] == "blocked"
