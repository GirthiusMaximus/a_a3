"""Parsing helpers for Rust world .map files and map-export JSON.

The native Rust world format is:

    4 byte serialization version + 8 byte timestamp + legacy LZ4 stream
    containing protobuf WorldData.

This module deliberately keeps the protobuf decoder small and schema-focused so
that the container has no code-generation step. JSON is also accepted because
several Rust map tools and hosting sites expose an interchange representation.
"""

from __future__ import annotations

import base64
import binascii
import io
import json
import math
import struct
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

import numpy as np

try:  # Optional acceleration; the pure-Python decoder below remains a fallback.
    import lz4.block as _lz4_block
except ImportError:  # pragma: no cover - exercised only in minimal environments
    _lz4_block = None


class MapParseError(ValueError):
    """Raised when an input cannot be recognised as a supported map."""


@dataclass
class PrefabInstance:
    category: str = ""
    prefab_id: int | str | None = None
    name: str = ""
    preview_url: str = ""
    model_url: str = ""
    model_format: str = ""
    asset_path: str = ""
    position: tuple[float, float, float] = (0.0, 0.0, 0.0)
    rotation: tuple[float, float, float] = (0.0, 0.0, 0.0)
    scale: tuple[float, float, float] = (1.0, 1.0, 1.0)
    index: int = 0

    @property
    def id_text(self) -> str:
        return "" if self.prefab_id is None else str(self.prefab_id)

    @property
    def display_name(self) -> str:
        return self.name or (f"id:{self.id_text}" if self.id_text else "unknown prefab")


@dataclass
class MapDocument:
    size_m: float = 4500.0
    size_y_m: float = 1000.0
    maps: dict[str, bytes] = field(default_factory=dict)
    prefabs: list[PrefabInstance] = field(default_factory=list)
    paths: list[dict[str, Any]] = field(default_factory=list)
    source_format: str = "unknown"
    serialization_version: int | None = None
    timestamp: int | None = None
    source_name: str = "map"
    origin_x_m: float | None = None
    origin_z_m: float | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def origin(self) -> tuple[float, float]:
        # Unity Terrain is positioned at -0.5 * terrain.size in RustEdit and
        # procedural Rust maps use a centred world coordinate system.
        return (
            -self.size_m / 2.0 if self.origin_x_m is None else self.origin_x_m,
            -self.size_m / 2.0 if self.origin_z_m is None else self.origin_z_m,
        )


# ---------------------------------------------------------------------------
# General decoding helpers
# ---------------------------------------------------------------------------


def _finite_float(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
        return result if math.isfinite(result) else default
    except (TypeError, ValueError):
        return default


def _vec3(value: Any, default: tuple[float, float, float]) -> tuple[float, float, float]:
    if isinstance(value, dict):
        return (
            _finite_float(value.get("x", default[0]), default[0]),
            _finite_float(value.get("y", default[1]), default[1]),
            _finite_float(value.get("z", default[2]), default[2]),
        )
    if isinstance(value, (list, tuple)):
        vals = list(value) + list(default)
        return (_finite_float(vals[0], default[0]), _finite_float(vals[1], default[1]), _finite_float(vals[2], default[2]))
    return default


def _size_from_value(value: Any, default: float = 4500.0) -> tuple[float, float]:
    if isinstance(value, dict):
        x = _finite_float(value.get("x", value.get("width", default)), default)
        z = _finite_float(value.get("z", value.get("depth", x)), x)
        y = _finite_float(value.get("y", value.get("height", 1000.0)), 1000.0)
        return max(1.0, (x + z) / 2.0), max(1.0, y)
    if isinstance(value, (list, tuple)):
        vals = list(value) + [default, 1000.0, default]
        return max(1.0, (float(vals[0]) + float(vals[2])) / 2.0), max(1.0, float(vals[1]))
    number = _finite_float(value, default)
    return max(1.0, number), 1000.0


def _decode_data(value: Any, map_name: str = "") -> bytes:
    """Decode common JSON representations of a Rust byte map."""
    if value is None:
        return b""
    if isinstance(value, bytes):
        return value
    if isinstance(value, bytearray):
        return bytes(value)
    if isinstance(value, str):
        text = value.strip()
        if text.startswith("base64:"):
            text = text[7:].strip()
        try:
            if text.startswith("0x") or text.lower().startswith("hex:"):
                hex_text = text[2:] if text.startswith("0x") else text[4:].strip()
                return bytes.fromhex(hex_text)
            # Rust map interchange JSON normally uses base64. Decode that
            # before the legacy unprefixed-hex fallback; some valid base64
            # payloads consist only of hexadecimal-looking characters.
            try:
                return base64.b64decode(text, validate=True)
            except (binascii.Error, ValueError):
                if len(text) % 2 == 0 and text and all(c in "0123456789abcdefABCDEF" for c in text[: min(len(text), 128)]):
                    if len(text) >= 32:
                        return bytes.fromhex(text)
                raise
        except (binascii.Error, ValueError):
            return text.encode("utf-8")
    if isinstance(value, dict):
        for key in ("data", "bytes", "base64", "value"):
            if key in value:
                return _decode_data(value[key], map_name)
    if isinstance(value, list):
        # Nested numeric arrays are convenient for small map fixtures. Height
        # arrays are normalized floats and are encoded like RustEdit's short map.
        if value and isinstance(value[0], (list, tuple)):
            arr = np.asarray(value)
            if map_name.lower() in {"height", "heightmap", "height_map", "terrain"} and np.issubdtype(arr.dtype, np.floating):
                shorts = np.clip(np.rint(arr.astype(np.float64) * 32766.0), -32768, 32767).astype("<i2")
                return shorts.tobytes(order="C")
            if np.issubdtype(arr.dtype, np.floating):
                return arr.astype("<f4").tobytes(order="C")
            if np.issubdtype(arr.dtype, np.integer):
                return arr.astype("<i4").tobytes(order="C")
        try:
            return bytes(max(0, min(255, int(v))) for v in value)
        except (TypeError, ValueError):
            return b""
    return b""


def _map_entries(raw: Any) -> Iterable[tuple[str, Any]]:
    if isinstance(raw, list):
        for entry in raw:
            if isinstance(entry, dict):
                name = entry.get("name", entry.get("layer", entry.get("key", "")))
                yield str(name), entry.get("data", entry.get("bytes", entry.get("value")))
    elif isinstance(raw, dict):
        for name, value in raw.items():
            if isinstance(value, dict) and any(k in value for k in ("data", "bytes", "base64", "value")):
                value = value.get("data", value.get("bytes", value.get("base64", value.get("value"))))
            yield str(name), value


def _find_map_value(obj: dict[str, Any], names: tuple[str, ...]) -> Any:
    lowered = {str(k).lower(): v for k, v in obj.items()}
    for name in names:
        if name.lower() in lowered:
            return lowered[name.lower()]
    return None


def _prefab_from_json(raw: Any, index: int) -> PrefabInstance:
    if not isinstance(raw, dict):
        return PrefabInstance(prefab_id=str(raw), index=index)
    prefab_id = raw.get("id", raw.get("prefab_id", raw.get("prefabId", raw.get("hash"))))
    name = raw.get(
        "name",
        raw.get("prefab", raw.get("prefab_path", raw.get("prefabPath", raw.get("full_name", raw.get("path", ""))))),
    )
    if isinstance(name, dict):
        name = name.get("name", name.get("path", ""))
    pos = raw.get("position", raw.get("pos", raw))
    rotation = raw.get("rotation", raw.get("euler", (0.0, 0.0, 0.0)))
    scale = raw.get("scale", raw.get("local_scale", raw.get("localScale", (1.0, 1.0, 1.0))))
    return PrefabInstance(
        category=str(raw.get("category", raw.get("type", "")) or ""),
        prefab_id=prefab_id,
        name=str(name or ""),
        preview_url=str(raw.get("preview_url", raw.get("preview", raw.get("thumbnail", raw.get("image", "")))) or ""),
        model_url=str(raw.get("model_url", raw.get("model", raw.get("mesh_url", raw.get("mesh", "")))) or ""),
        model_format=str(raw.get("model_format", raw.get("format", "")) or ""),
        asset_path=str(raw.get("asset_path", raw.get("asset", "")) or ""),
        position=_vec3(pos, (0.0, 0.0, 0.0)),
        rotation=_vec3(rotation, (0.0, 0.0, 0.0)),
        scale=_vec3(scale, (1.0, 1.0, 1.0)),
        index=index,
    )


def parse_json_map(data: bytes, source_name: str = "map.json") -> MapDocument:
    try:
        raw = json.loads(data.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise MapParseError(f"JSON map could not be decoded: {exc}") from exc
    if not isinstance(raw, dict):
        raise MapParseError("JSON map root must be an object")

    world = raw.get("world", raw.get("worldData", raw))
    if not isinstance(world, dict):
        world = raw
    size_m, size_y = _size_from_value(world.get("size", raw.get("size", 4500.0)))
    size_y = _finite_float(world.get("size_y", world.get("height_scale", raw.get("height_scale", size_y))), size_y)
    doc = MapDocument(
        size_m=size_m,
        size_y_m=max(1.0, size_y),
        source_format="json",
        source_name=source_name,
        metadata={"json_keys": sorted(str(k) for k in raw.keys())[:100]},
    )

    maps_raw = world.get("maps", world.get("layers", raw.get("maps", raw.get("layers", {}))))
    for name, value in _map_entries(maps_raw):
        if name:
            doc.maps[name] = _decode_data(value, name)

    # A friendly interchange form can put layers directly at the top level.
    for key in ("height", "heightmap", "height_map", "terrain", "topology", "water", "biome", "splat", "alpha"):
        if key in raw and key.lower() not in {k.lower() for k in doc.maps}:
            doc.maps[key] = _decode_data(raw[key], key)
        elif key in world and key.lower() not in {k.lower() for k in doc.maps}:
            doc.maps[key] = _decode_data(world[key], key)

    prefabs_raw = world.get("prefabs", raw.get("prefabs", raw.get("objects", [])))
    if isinstance(prefabs_raw, dict):
        prefabs_raw = list(prefabs_raw.values())
    if isinstance(prefabs_raw, list):
        doc.prefabs = [_prefab_from_json(value, i) for i, value in enumerate(prefabs_raw)]

    paths = world.get("paths", raw.get("paths", []))
    if isinstance(paths, list):
        doc.paths = [p for p in paths if isinstance(p, dict)]

    origin = world.get("origin", raw.get("origin"))
    if isinstance(origin, dict):
        doc.origin_x_m = _finite_float(origin.get("x"), -doc.size_m / 2.0)
        doc.origin_z_m = _finite_float(origin.get("z"), -doc.size_m / 2.0)
    elif isinstance(origin, (list, tuple)) and len(origin) >= 3:
        doc.origin_x_m = _finite_float(origin[0], -doc.size_m / 2.0)
        doc.origin_z_m = _finite_float(origin[2], -doc.size_m / 2.0)
    return doc


# ---------------------------------------------------------------------------
# Protobuf reader for the Rust WorldData schema
# ---------------------------------------------------------------------------


def _read_varint(data: bytes, offset: int) -> tuple[int, int]:
    result = 0
    shift = 0
    while offset < len(data) and shift < 70:
        byte = data[offset]
        offset += 1
        result |= (byte & 0x7F) << shift
        if not byte & 0x80:
            return result, offset
        shift += 7
    raise MapParseError("Invalid or truncated protobuf varint")


def _read_fields(data: bytes) -> Iterable[tuple[int, int, Any]]:
    offset = 0
    while offset < len(data):
        key, offset = _read_varint(data, offset)
        field_no, wire_type = key >> 3, key & 0x07
        if field_no <= 0:
            raise MapParseError("Invalid protobuf field number")
        if wire_type == 0:
            value, offset = _read_varint(data, offset)
        elif wire_type == 1:
            if offset + 8 > len(data):
                raise MapParseError("Truncated protobuf fixed64 field")
            value = data[offset : offset + 8]
            offset += 8
        elif wire_type == 2:
            length, offset = _read_varint(data, offset)
            if length > len(data) - offset:
                raise MapParseError("Truncated protobuf length-delimited field")
            value = data[offset : offset + length]
            offset += length
        elif wire_type == 5:
            if offset + 4 > len(data):
                raise MapParseError("Truncated protobuf fixed32 field")
            value = data[offset : offset + 4]
            offset += 4
        else:
            raise MapParseError(f"Unsupported protobuf wire type {wire_type}")
        yield field_no, wire_type, value


def _first_field(fields: list[tuple[int, int, Any]], number: int, default: Any = None) -> Any:
    for field_no, _, value in fields:
        if field_no == number:
            return value
    return default


def _all_fields(fields: list[tuple[int, int, Any]], number: int) -> list[Any]:
    return [value for field_no, _, value in fields if field_no == number]


def _proto_string(value: Any) -> str:
    if not isinstance(value, (bytes, bytearray)):
        return str(value)
    return value.decode("utf-8", errors="replace")


def _proto_float(value: Any, default: float = 0.0) -> float:
    if isinstance(value, (bytes, bytearray)) and len(value) == 4:
        return float(struct.unpack("<f", value)[0])
    if isinstance(value, (bytes, bytearray)) and len(value) == 8:
        return float(struct.unpack("<d", value)[0])
    if isinstance(value, (int, float)):
        return float(value)
    return default


def _proto_vec3(data: bytes | None) -> tuple[float, float, float]:
    if not data:
        return (0.0, 0.0, 0.0)
    values = {field_no: _proto_float(value) for field_no, _, value in _read_fields(data) if field_no in (1, 2, 3)}
    return (values.get(1, 0.0), values.get(2, 0.0), values.get(3, 0.0))


def _proto_map(data: bytes) -> tuple[str, bytes]:
    fields = list(_read_fields(data))
    return _proto_string(_first_field(fields, 1, b"")), bytes(_first_field(fields, 2, b""))


def _proto_prefab(data: bytes, index: int) -> PrefabInstance:
    fields = list(_read_fields(data))
    return PrefabInstance(
        category=_proto_string(_first_field(fields, 1, b"")),
        prefab_id=_first_field(fields, 2, None),
        position=_proto_vec3(_first_field(fields, 3, None)),
        rotation=_proto_vec3(_first_field(fields, 4, None)),
        scale=_proto_vec3(_first_field(fields, 5, None)) if _first_field(fields, 5, None) is not None else (1.0, 1.0, 1.0),
        index=index,
    )


def _protobuf_world(data: bytes, source_name: str, version: int | None, timestamp: int | None) -> MapDocument:
    fields = list(_read_fields(data))
    size = _first_field(fields, 1, 4500)
    doc = MapDocument(
        size_m=max(1.0, float(size)),
        size_y_m=1000.0,
        source_format="rust-binary",
        source_name=source_name,
        serialization_version=version,
        timestamp=timestamp,
    )
    for entry in _all_fields(fields, 2):
        if isinstance(entry, (bytes, bytearray)):
            name, payload = _proto_map(bytes(entry))
            if name:
                doc.maps[name] = payload
    doc.prefabs = [_proto_prefab(bytes(entry), i) for i, entry in enumerate(_all_fields(fields, 3)) if isinstance(entry, (bytes, bytearray))]
    # Paths are kept as opaque fields for now; their nodes are not required by
    # the prefab/topology analysis and preserving a count is useful in reports.
    for entry in _all_fields(fields, 4):
        if isinstance(entry, (bytes, bytearray)):
            path_fields = list(_read_fields(bytes(entry)))
            nodes = [_proto_vec3(bytes(node)) for node in _all_fields(path_fields, 15) if isinstance(node, (bytes, bytearray))]
            doc.paths.append({
                "name": _proto_string(_first_field(path_fields, 1, b"")),
                "spline": bool(_first_field(path_fields, 2, 0)),
                "width": _proto_float(_first_field(path_fields, 5, 0.0)),
                "node_count": len(nodes),
                "nodes": nodes,
            })
    return doc


# ---------------------------------------------------------------------------
# Pure Python legacy LZ4 decoder
# ---------------------------------------------------------------------------


def _read_stream_varint(data: bytes, offset: int) -> tuple[int, int]:
    return _read_varint(data, offset)


def _lz4_block_decode(source: bytes, expected_length: int) -> bytes:
    """Decode one LZ4 block (the standard token/literal/match block format)."""
    if _lz4_block is not None:
        try:
            decoded = _lz4_block.decompress(source, uncompressed_size=expected_length)
            if len(decoded) == expected_length:
                return decoded
        except Exception:
            # Fall through to the dependency-free decoder for unusual blocks
            # or when a runtime's native extension rejects the input.
            pass
    output = bytearray()
    offset = 0
    while offset < len(source):
        token = source[offset]
        offset += 1
        literal_length = token >> 4
        if literal_length == 15:
            while True:
                if offset >= len(source):
                    raise MapParseError("Truncated LZ4 literal length")
                extra = source[offset]
                offset += 1
                literal_length += extra
                if extra != 255:
                    break
        if offset + literal_length > len(source):
            raise MapParseError("Truncated LZ4 literals")
        output.extend(source[offset : offset + literal_length])
        offset += literal_length
        if offset >= len(source):
            break
        if offset + 2 > len(source):
            raise MapParseError("Truncated LZ4 match offset")
        match_offset = source[offset] | (source[offset + 1] << 8)
        offset += 2
        if match_offset <= 0 or match_offset > len(output):
            raise MapParseError("Invalid LZ4 match offset")
        match_length = token & 0x0F
        if match_length == 15:
            while True:
                if offset >= len(source):
                    raise MapParseError("Truncated LZ4 match length")
                extra = source[offset]
                offset += 1
                match_length += extra
                if extra != 255:
                    break
        match_length += 4
        for _ in range(match_length):
            output.append(output[-match_offset])
        if len(output) > max(expected_length, 1) + 1_048_576:
            raise MapParseError("LZ4 block expands beyond safety limit")
    if len(output) != expected_length:
        raise MapParseError(f"LZ4 block length mismatch: expected {expected_length}, got {len(output)}")
    return bytes(output)


def _legacy_lz4_decode(data: bytes, max_output: int = 768 * 1024 * 1024) -> bytes:
    """Decode K4os/lz4net legacy LZ4Stream chunks.

    Each chunk is: varint flags, varint original length, optional varint
    compressed length, then the block bytes. Bit 0 means compressed.
    """
    result = bytearray()
    offset = 0
    while offset < len(data):
        flags, offset = _read_stream_varint(data, offset)
        original_length, offset = _read_stream_varint(data, offset)
        if original_length > max_output or original_length < 0:
            raise MapParseError("LZ4 chunk is too large")
        is_compressed = bool(flags & 0x01)
        compressed_length = original_length
        if is_compressed:
            compressed_length, offset = _read_stream_varint(data, offset)
        if compressed_length > len(data) - offset:
            raise MapParseError("Truncated LZ4 chunk")
        chunk = data[offset : offset + compressed_length]
        offset += compressed_length
        if is_compressed:
            decoded = _lz4_block_decode(chunk, original_length)
        else:
            if compressed_length != original_length:
                raise MapParseError("Invalid uncompressed LZ4 chunk")
            decoded = chunk
        result.extend(decoded)
        if len(result) > max_output:
            raise MapParseError("Decoded map exceeds safety limit")
    return bytes(result)


def parse_rust_binary_map(data: bytes, source_name: str = "map.map") -> MapDocument:
    if len(data) < 13:
        raise MapParseError("Rust binary map is shorter than its header")
    version = struct.unpack_from("<I", data, 0)[0]
    timestamp = struct.unpack_from("<Q", data, 4)[0]
    try:
        decompressed = _legacy_lz4_decode(data[12:])
    except MapParseError as exc:
        raise MapParseError(f"Could not decode the legacy LZ4 stream: {exc}") from exc
    return _protobuf_world(decompressed, source_name, version, timestamp)


def parse_map(data: bytes, source_name: str = "map") -> MapDocument:
    """Auto-detect JSON, ZIP-wrapped interchange, or native Rust binary map."""
    if not data:
        raise MapParseError("The uploaded map is empty")
    stripped = data.lstrip()
    if stripped.startswith(b"{") or stripped.startswith(b"["):
        return parse_json_map(data, source_name)
    if data[:2] == b"PK":
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                names = archive.namelist()
                json_names = [n for n in names if n.lower().endswith((".json", ".map.json"))]
                if json_names:
                    return parse_json_map(archive.read(json_names[0]), f"{source_name}:{json_names[0]}")
                map_names = [n for n in names if n.lower().endswith(".map")]
                if map_names:
                    return parse_rust_binary_map(archive.read(map_names[0]), f"{source_name}:{map_names[0]}")
        except zipfile.BadZipFile as exc:
            raise MapParseError(f"ZIP map could not be opened: {exc}") from exc
        raise MapParseError("ZIP input contains no supported .map or JSON map")
    return parse_rust_binary_map(data, source_name)


# ---------------------------------------------------------------------------
# Terrain decoding helpers used by the analyzer and renderer
# ---------------------------------------------------------------------------


def _case_insensitive_map(doc: MapDocument) -> dict[str, bytes]:
    return {key.lower().replace("_", ""): value for key, value in doc.maps.items()}


def decode_heightmap(doc: MapDocument) -> np.ndarray | None:
    maps = _case_insensitive_map(doc)
    for key in ("height", "heightmap", "terrain"):
        payload = maps.get(key)
        if not payload:
            continue
        if len(payload) % 2 == 0:
            resolution = int(round(math.sqrt(len(payload) // 2)))
            if resolution * resolution * 2 == len(payload):
                values = np.frombuffer(payload, dtype="<i2").reshape((resolution, resolution)).astype(np.float32)
                # RustEdit encodes normalized terrain heights as short / 32766.
                return np.clip(values / 32766.0, 0.0, 1.0)
        if len(payload) % 4 == 0:
            resolution = int(round(math.sqrt(len(payload) // 4)))
            if resolution * resolution * 4 == len(payload):
                values = np.frombuffer(payload, dtype="<f4").reshape((resolution, resolution)).astype(np.float32)
                return np.clip(values, 0.0, 1.0)
    return None


def decode_topology(doc: MapDocument) -> np.ndarray | None:
    maps = _case_insensitive_map(doc)
    payload = maps.get("topology")
    if not payload or len(payload) % 4:
        return None
    resolution = int(round(math.sqrt(len(payload) // 4)))
    if resolution * resolution * 4 != len(payload):
        return None
    return np.frombuffer(payload, dtype="<i4").reshape((resolution, resolution)).astype(np.int64)


def _decode_channel_map(doc: MapDocument, name: str, channels: int) -> np.ndarray | None:
    """Decode RustEdit's channel-major byte map.

    RustEdit stores splat/biome/alpha channels as one complete channel after
    another, not interleaved per pixel: ``channel, z, x``. Returning the
    channel-first shape keeps large native maps from being copied unnecessarily.
    """
    maps = _case_insensitive_map(doc)
    payload = maps.get(name.lower())
    if not payload or len(payload) % channels:
        return None
    bytes_per_channel = len(payload) // channels
    resolution = int(round(math.sqrt(bytes_per_channel)))
    if resolution * resolution * channels != len(payload):
        return None
    values = np.frombuffer(payload, dtype=np.uint8).reshape((channels, resolution, resolution))
    return values


def decode_splat(doc: MapDocument) -> np.ndarray | None:
    """Return the eight Rust ground-texture weights as channel-first bytes."""
    splat = _decode_channel_map(doc, "splat", 8)
    return splat if splat is not None else _decode_channel_map(doc, "ground", 8)


def decode_biome(doc: MapDocument) -> np.ndarray | None:
    """Return Rust biome weights as channel-first bytes.

    Current Rust maps can contain five biome channels: Arid, Temperate,
    Tundra, Arctic, and Jungle. Older RustEdit maps contain four and are kept
    compatible with the fallback below.
    """
    biome = _decode_channel_map(doc, "biome", 5)
    return biome if biome is not None else _decode_channel_map(doc, "biome", 4)


def decode_alpha(doc: MapDocument) -> np.ndarray | None:
    """Return the one-channel alpha/visibility map when present."""
    return _decode_channel_map(doc, "alpha", 1)


def decode_water(doc: MapDocument) -> np.ndarray | None:
    maps = _case_insensitive_map(doc)
    payload = maps.get("water")
    if not payload:
        return None
    # RustEdit's WaterMap is exposed as a float map when saved, while older
    # exports may contain its underlying 16-bit values.
    if len(payload) % 4 == 0:
        resolution = int(round(math.sqrt(len(payload) // 4)))
        if resolution * resolution * 4 == len(payload):
            return np.frombuffer(payload, dtype="<f4").reshape((resolution, resolution)).astype(np.float32)
    if len(payload) % 2 == 0:
        resolution = int(round(math.sqrt(len(payload) // 2)))
        if resolution * resolution * 2 == len(payload):
            values = np.frombuffer(payload, dtype="<i2").reshape((resolution, resolution)).astype(np.float32)
            return values / 32766.0
    return None


__all__ = [
    "MapDocument",
    "MapParseError",
    "PrefabInstance",
    "decode_alpha",
    "decode_biome",
    "decode_heightmap",
    "decode_splat",
    "decode_topology",
    "decode_water",
    "parse_json_map",
    "parse_map",
    "parse_rust_binary_map",
]
