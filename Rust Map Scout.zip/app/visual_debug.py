"""Export compact visual-layer diagnostics for large Rust map files."""

from __future__ import annotations

import io
import json
import zipfile
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image

from .map_parser import MapDocument, decode_biome, decode_heightmap, decode_splat, decode_topology, decode_water
from .renderer import render_annotated_map


SPLAT_NAMES = ["Dirt", "Forest", "Grass", "Gravel", "Rock", "Sand", "Snow", "Stones"]
BIOME_NAMES = ["Arid", "Temperate", "Tundra", "Arctic", "Jungle"]
SPLAT_COLORS = np.asarray(
    [
        (0x99, 0x7A, 0x54),  # Dirt   #997A54
        (0x3F, 0x4C, 0x12),  # Forest #3F4C12
        (0x5A, 0x5E, 0x34),  # Grass  #5A5E34
        (0x40, 0x3E, 0x38),  # Gravel #403E38
        (0x66, 0x64, 0x60),  # Rock   #666460
        (0xB2, 0xA8, 0x87),  # Sand   #B2A887
        (0xDC, 0xED, 0xF0),  # Snow   #DCEDF0
        (0x23, 0x47, 0x46),  # Stones #234746
    ],
    dtype=np.uint8,
)
BIOME_COLORS = np.asarray(
    [(194, 157, 91), (93, 130, 71), (137, 143, 126), (231, 238, 233), (55, 116, 58)],
    dtype=np.uint8,
)
TOPOLOGY_COLORS = {
    1 << 7: (40, 122, 178),       # Ocean
    1 << 8: (49, 138, 185),       # Oceanside
    1 << 14: (45, 157, 190),     # River
    1 << 16: (75, 174, 192),     # Lake
    1 << 17: (88, 187, 196),     # Lakeside
    1 << 1: (151, 143, 132),     # Cliff
    1 << 11: (185, 143, 78),     # Road
}


def _png_bytes(image: Image.Image) -> bytes:
    output = io.BytesIO()
    image.save(output, format="PNG", optimize=True)
    return output.getvalue()


def _resize_gray(values: np.ndarray, size: int, *, nearest: bool = False) -> bytes:
    values = np.nan_to_num(values.astype(np.float32, copy=False), nan=0.0, posinf=0.0, neginf=0.0)
    low, high = np.percentile(values, (1.0, 99.0)) if float(np.max(values)) > float(np.min(values)) else (0.0, 1.0)
    normalized = np.clip((values - low) / max(1e-6, high - low), 0.0, 1.0)
    image = Image.fromarray(np.rint(normalized * 255.0).astype(np.uint8), mode="L")
    return _png_bytes(image.resize((size, size), Image.Resampling.NEAREST if nearest else Image.Resampling.BILINEAR))


def _resize_weight(values: np.ndarray, size: int) -> bytes:
    image = Image.fromarray(np.clip(values.astype(np.float32, copy=False), 0.0, 255.0).astype(np.uint8), mode="L")
    return _png_bytes(image.resize((size, size), Image.Resampling.BILINEAR))


def _dominant_png(channels: np.ndarray, colors: np.ndarray, size: int) -> bytes:
    values = np.nan_to_num(channels.astype(np.float32, copy=False), nan=0.0, posinf=0.0, neginf=0.0)
    totals = np.maximum(values.sum(axis=0), 1.0)
    dominant = np.argmax(values / totals[None, ...], axis=0)
    rgb = colors[np.minimum(dominant, len(colors) - 1)]
    image = Image.fromarray(rgb.astype(np.uint8), mode="RGB")
    return _png_bytes(image.resize((size, size), Image.Resampling.NEAREST))


def _topology_png(topology: np.ndarray, size: int) -> bytes:
    rgb = np.zeros((*topology.shape, 3), dtype=np.uint8)
    rgb[:] = (35, 43, 53)
    for bit, color in TOPOLOGY_COLORS.items():
        mask = (topology & bit) != 0
        rgb[mask] = color
    return _png_bytes(Image.fromarray(rgb, mode="RGB").resize((size, size), Image.Resampling.NEAREST))


def _layer_info(doc: MapDocument) -> list[dict[str, Any]]:
    return [{"name": name, "bytes": len(payload)} for name, payload in doc.maps.items()]


def build_visual_debug_bundle(
    doc: MapDocument,
    report: dict[str, Any],
    output_path: str | Path,
    size: int = 1024,
) -> Path:
    """Write a small ZIP of decoded layers without including the source map.

    This is intended for diagnosing a large native map that cannot be shared in
    the workspace. It exposes the actual decoded channel masks, dominant
    splat/biome classifications, topology, current renderer output, and the
    channel/layer metadata needed to tune the compositor.
    """
    size = max(256, min(int(size), 1600))
    height = decode_heightmap(doc)
    splat = decode_splat(doc)
    biome = decode_biome(doc)
    topology = decode_topology(doc)
    water = decode_water(doc)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    diagnostics = {
        "source": report.get("source", {}),
        "map": report.get("map", {}),
        "render": report.get("render", {}),
        "raw_layers": _layer_info(doc),
        "decoded": {
            "height": None if height is None else {"resolution": int(height.shape[0]), "dtype": str(height.dtype)},
            "splat": None if splat is None else {"resolution": int(splat.shape[1]), "channels": SPLAT_NAMES},
            "biome": None if biome is None else {"resolution": int(biome.shape[1]), "channels": BIOME_NAMES},
            "topology": None if topology is None else {"resolution": int(topology.shape[0])},
            "water": None if water is None else {"resolution": int(water.shape[0])},
        },
        "notes": [
            "Splat channels are RustEdit order: Dirt, Forest, Grass, Gravel, Rock, Sand, Snow, Stones.",
            "Biome channels are Rust order: Arid, Temperate, Tundra, Arctic, Jungle when five channels are present.",
            "PNG files are downsampled diagnostics; the original map is deliberately not included.",
            "renderer-preview.png is the current clean backdrop, without web overlays.",
            "The renderer uses the requested splat palette, native row-axis correction, and a heightmap-derived normal-map strength of 1.5.",
        ],
    }

    with zipfile.ZipFile(output_path, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
        bundle.writestr("diagnostics.json", json.dumps(diagnostics, indent=2, ensure_ascii=False))
        bundle.writestr(
            "README.txt",
            "Rust Map Scout visual-layer diagnostics\n"
            "=====================================\n\n"
            "This ZIP contains compact decoded layer previews for tuning the RustEdit-style compositor.\n"
            "It does not contain the original .map file.\n\n"
            "Channel order:\n"
            "  Splat: Dirt, Forest, Grass, Gravel, Rock, Sand, Snow, Stones\n"
            "  Biome: Arid, Temperate, Tundra, Arctic, Jungle (five-channel maps)\n",
        )
        if height is not None:
            bundle.writestr("layers/height.png", _resize_gray(height, size))
        if splat is not None:
            for index, name in enumerate(SPLAT_NAMES):
                bundle.writestr(f"layers/splat-{index:02d}-{name.lower()}.png", _resize_weight(splat[index], size))
            bundle.writestr("layers/splat-dominant.png", _dominant_png(splat, SPLAT_COLORS, size))
        if biome is not None:
            for index, name in enumerate(BIOME_NAMES):
                bundle.writestr(f"layers/biome-{index:02d}-{name.lower()}.png", _resize_weight(biome[index], size))
            bundle.writestr("layers/biome-dominant.png", _dominant_png(biome, BIOME_COLORS, size))
        if topology is not None:
            bundle.writestr("layers/topology.png", _topology_png(topology, size))
        if water is not None:
            bundle.writestr("layers/water.png", _resize_gray(water, size))
        preview = render_annotated_map(doc, report, output_size=size)
        bundle.writestr("renderer-preview.png", _png_bytes(preview))
    return output_path


__all__ = ["build_visual_debug_bundle"]
