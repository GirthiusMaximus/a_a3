"""Render a readable 2D annotated map image from analysis output."""

from __future__ import annotations

import math
from typing import Any

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from .map_parser import MapDocument, decode_biome, decode_heightmap, decode_splat, decode_topology


# User-supplied RustEdit-style ground palette. Keep these values as the
# actual splat colours; biome context only repairs sparse Arctic/Snow paint.
SPLAT_PALETTE = np.asarray(
    [
        (0x99, 0x7A, 0x54),  # Dirt   #997A54
        (0x3F, 0x4C, 0x12),  # Forest #3F4C12
        (0x5A, 0x5E, 0x34),  # Grass  #5A5E34
        (0x40, 0x3E, 0x38),  # Gravel #403E38
        (0x66, 0x64, 0x60),  # Rock   #666460
        (0xB2, 0xA8, 0x87),  # Sand   #B2A887
        (0xDC, 0xED, 0xF0),  # Snow   #DCEDF0
        (0x23, 0x47, 0x46),  # Stones #234746
    ],
    dtype=np.float32,
)
WATER_COLOR = np.asarray((0x2B, 0x51, 0x5C), dtype=np.float32)  # #2B515C
NORMAL_MAP_STRENGTH = 1.5

TOPOLOGY_COLORS = {
    1 << 16: (43, 81, 92),   # lake / water
    1 << 7: (43, 81, 92),    # ocean / water
    1 << 14: (43, 81, 92),   # river / water
    1 << 1: (142, 137, 129), # cliff
    1 << 11: (202, 157, 90), # road
}


def _font(size: int = 16):
    for path in (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
    ):
        try:
            return ImageFont.truetype(path, size=size)
        except OSError:
            pass
    return ImageFont.load_default()


def _bold_font(size: int = 18):
    for path in (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf",
    ):
        try:
            return ImageFont.truetype(path, size=size)
        except OSError:
            pass
    return ImageFont.load_default()


def _hex_rgb(value: str) -> tuple[int, int, int]:
    try:
        value = value.lstrip("#")
        return int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16)
    except (ValueError, IndexError):
        return (230, 237, 243)


def _sample_grid(
    array: np.ndarray,
    out_width: int,
    out_height: int,
    resample: Image.Resampling = Image.Resampling.BILINEAR,
) -> np.ndarray:
    """Resample a map layer without making a full-size RGB copy."""
    def resize_layer(layer: np.ndarray) -> np.ndarray:
        if layer.dtype == np.int64:
            layer = layer.astype(np.int32)
        return np.asarray(Image.fromarray(layer).resize((out_width, out_height), resample=resample))

    if array.ndim == 2:
        return resize_layer(array)
    channels = [resize_layer(channel) for channel in array]
    return np.stack(channels, axis=0)

def _terrain_shade(
    height: np.ndarray,
    out_size: tuple[int, int],
    scale_m: float,
    normal_strength: float = NORMAL_MAP_STRENGTH,
) -> tuple[np.ndarray, np.ndarray]:
    """Return sampled height and a directional normal-map hillshade.

    The native map does not carry a Unity-ready normal texture, so the
    renderer derives one from the decoded heightmap. ``normal_strength`` is
    deliberately exposed here because the supplied target needs stronger
    relief than a flat splat-colour composite; the requested default is 1.5.
    """
    out_width, out_height = out_size
    sampled = _sample_grid(height.astype(np.float32, copy=False), out_width, out_height)
    sampled = np.nan_to_num(sampled, nan=0.0, posinf=1.0, neginf=0.0)
    sampled = np.clip(sampled, 0.0, 1.0)
    # Work in the output grid so a 4097 map does not create another large
    # gradient array. The physical spacing keeps the normal direction stable
    # when the output size changes; the normal strength then scales its XY
    # components just like a material normal-map multiplier.
    pixel_x_m = max(1.0, float(scale_m) / max(2.0, out_width))
    pixel_z_m = max(1.0, float(scale_m) / max(2.0, out_height))
    gy, gx = np.gradient(sampled * float(scale_m), pixel_z_m, pixel_x_m)
    strength = max(0.0, float(normal_strength))
    nx = -gx * strength
    ny = -gy * strength
    nz = np.full_like(sampled, 2.0)
    length = np.sqrt(nx * nx + ny * ny + nz * nz)
    nx /= np.maximum(length, 1e-6)
    ny /= np.maximum(length, 1e-6)
    nz /= np.maximum(length, 1e-6)
    # Soft northwest light, matching the readable relief direction in the
    # supplied RustEdit render without crushing the user-selected colours.
    light = np.asarray((-0.48, -0.58, 0.66), dtype=np.float32)
    light /= np.linalg.norm(light)
    diffuse = nx * light[0] + ny * light[1] + nz * light[2]
    shade = 0.72 + 0.58 * diffuse
    return sampled, np.clip(shade, 0.42, 1.30)


def _normalise_channels(channels: np.ndarray) -> np.ndarray:
    """Normalise channel-major Rust terrain weights per pixel."""
    values = np.nan_to_num(channels.astype(np.float32, copy=False), nan=0.0, posinf=0.0, neginf=0.0)
    values = np.clip(values, 0.0, 255.0)
    totals = np.sum(values, axis=0, keepdims=True)
    return values / np.maximum(totals, 1.0)


def _biome_weights(biome: np.ndarray | None, out_size: tuple[int, int]) -> np.ndarray | None:
    if biome is None or biome.ndim != 3 or biome.shape[0] < 4:
        return None
    # Current Rust maps expose five biome channels. Preserve Jungle when it is
    # present instead of silently truncating the decoded array to the legacy
    # four-channel layout.
    channel_count = min(5, int(biome.shape[0]))
    sampled = _sample_grid(biome[:channel_count], out_size[0], out_size[1], Image.Resampling.BILINEAR)
    return _normalise_channels(sampled)


def _apply_biome_context(
    rgb: np.ndarray,
    biome_weights: np.ndarray | None,
    splat_weights: np.ndarray,
) -> np.ndarray:
    """Use biome data to repair sparse snow paint without changing the palette.

    The requested colours are the authoritative splat colours. Rust's Snow
    splat is sparse on this map, so Arctic/Tundra context is still allowed to
    blend toward the supplied Snow colour; Arid, Temperate, and Jungle do not
    replace the user-selected Dirt/Grass/Forest/Sand colours.
    """
    splat = _normalise_channels(splat_weights)
    snow = splat[6]
    snow_colour = SPLAT_PALETTE[6]
    if biome_weights is None:
        snow_strength = np.clip(0.72 * snow, 0.0, 0.94)
    else:
        tundra = biome_weights[2]
        arctic = biome_weights[3]
        snow_strength = np.clip(0.72 * snow + 0.85 * arctic + 0.14 * tundra, 0.0, 0.96)
    return rgb * (1.0 - snow_strength[..., None]) + snow_colour * snow_strength[..., None]


def _height_base(
    height: np.ndarray,
    out_size: tuple[int, int],
    scale_m: float,
    topology: np.ndarray | None = None,
    biome: np.ndarray | None = None,
) -> Image.Image:
    h, shade = _terrain_shade(height, out_size, scale_m)
    # If a source map has no ground-texture layer, use a deliberately higher
    # contrast relief palette rather than the flat green cast of a raw
    # normalized heightmap.
    p_low, p_high = np.percentile(h, (2.0, 98.0))
    contrast = np.clip((h - p_low) / max(0.04, p_high - p_low), 0.0, 1.0)
    stops = np.asarray(
        [
            [24, 54, 82],    # deep water / low ground
            [52, 96, 112],   # shallow/coastal low ground
            [183, 165, 112], # beach and low dry ground
            [92, 139, 74],   # grassland
            [58, 102, 62],   # forested middle ground
            [135, 132, 119], # rock
            [225, 225, 212], # high/snow ground
        ],
        dtype=np.float32,
    )
    pos = contrast * (len(stops) - 1)
    lo = np.floor(pos).astype(np.int32)
    hi = np.minimum(lo + 1, len(stops) - 1)
    mix = (pos - lo)[..., None]
    rgb = stops[lo] * (1.0 - mix) + stops[hi] * mix
    rgb *= shade[..., None]
    biome_weights = _biome_weights(biome, out_size)
    if biome_weights is not None:
        arctic = biome_weights[3]
        tundra = biome_weights[2]
        snow_strength = np.clip(0.72 * arctic + 0.14 * tundra, 0.0, 0.86)
        rgb = rgb * (1.0 - snow_strength[..., None]) + SPLAT_PALETTE[6] * snow_strength[..., None]
    if topology is not None:
        topo = _sample_grid(topology, out_size[0], out_size[1], Image.Resampling.NEAREST)
        ocean = (topo & ((1 << 7) | (1 << 8) | (1 << 18))) != 0
        inland_water = (topo & ((1 << 14) | (1 << 16) | (1 << 17))) != 0
        rgb[ocean] = WATER_COLOR
        rgb[inland_water] = WATER_COLOR
    image = Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8), mode="RGB")
    return image


def _splat_base(
    height: np.ndarray,
    splat: np.ndarray,
    biome: np.ndarray | None,
    topology: np.ndarray | None,
    out_size: tuple[int, int],
    scale_m: float,
) -> Image.Image:
    """Render Rust's ground texture weights into a readable top-down map.

    RustEdit stores eight channel-major splat maps. The palette follows the
    standard RustEdit ground texture order: dirt, forest, grass, gravel, rock,
    sand, snow, stones. It is not a replacement for the game's shader, but it
    uses the map's own ground data instead of inventing a green height palette.
    """
    weights = _sample_grid(splat, out_size[0], out_size[1], Image.Resampling.BILINEAR).astype(np.float32)
    palette = SPLAT_PALETTE
    normalised_weights = _normalise_channels(weights)
    rgb = np.einsum("czx,cd->zxd", normalised_weights, palette)
    rgb = _apply_biome_context(rgb, _biome_weights(biome, out_size), weights)
    _, shade = _terrain_shade(height, out_size, scale_m)
    # Keep texture colours visible while retaining pronounced terrain relief.
    rgb *= (0.72 + 0.45 * shade)[..., None]
    if topology is not None:
        topo = _sample_grid(topology, out_size[0], out_size[1], Image.Resampling.NEAREST)
        ocean = (topo & ((1 << 7) | (1 << 8) | (1 << 18))) != 0
        inland_water = (topo & ((1 << 14) | (1 << 16) | (1 << 17))) != 0
        # Water and offshore use the exact user-supplied colour rather than
        # the brighter diagnostic blue.
        rgb[ocean] = WATER_COLOR
        rgb[inland_water] = WATER_COLOR
    return Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8), mode="RGB")

def _topology_base(topology: np.ndarray, out_size: tuple[int, int]) -> Image.Image:
    height, width = topology.shape
    rgb = np.zeros((height, width, 3), dtype=np.float32)
    rgb[:] = (35, 43, 53)
    rgb += np.asarray((13, 17, 22), dtype=np.float32)
    for bit, color in TOPOLOGY_COLORS.items():
        mask = (topology & bit) != 0
        rgb[mask] = np.asarray(color, dtype=np.float32) * 0.8 + rgb[mask] * 0.2
    image = Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8), mode="RGB")
    return image.resize(out_size, Image.Resampling.NEAREST)


def _empty_base(out_size: tuple[int, int]) -> Image.Image:
    image = Image.new("RGB", out_size, (25, 32, 41))
    draw = ImageDraw.Draw(image)
    step = max(32, out_size[0] // 24)
    for x in range(0, out_size[0], step):
        draw.line((x, 0, x, out_size[1]), fill=(36, 47, 58), width=1)
    for y in range(0, out_size[1], step):
        draw.line((0, y, out_size[0], y), fill=(36, 47, 58), width=1)
    return image


def _rounded_label(draw: ImageDraw.ImageDraw, xy: tuple[float, float], text: str, fill: tuple[int, int, int, int], text_fill=(247, 250, 252), font=None):
    font = font or _font(15)
    x, y = xy
    bbox = draw.textbbox((x, y), text, font=font)
    pad_x, pad_y = 6, 4
    draw.rounded_rectangle(
        (bbox[0] - pad_x, bbox[1] - pad_y, bbox[2] + pad_x, bbox[3] + pad_y),
        radius=5,
        fill=fill,
    )
    draw.text((x, y), text, font=font, fill=text_fill)


def _orient_base(base: Image.Image, orientation: str) -> Image.Image:
    if orientation == "rotate_cw_flip_vertical":
        # RustEdit authority: rotate clockwise, then mirror across the
        # vertical axis (left/right in the displayed image).
        rotated = base.transpose(Image.Transpose.ROTATE_270)
        return rotated.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
    if orientation == "rotate_cw":
        return base.transpose(Image.Transpose.ROTATE_270)
    if orientation == "rotate_ccw":
        return base.transpose(Image.Transpose.ROTATE_90)
    if orientation == "flip_x":
        return base.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
    if orientation == "flip_y":
        return base.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
    return base


def _display_point(
    doc: MapDocument,
    world_x: float,
    world_z: float,
    map_width: float,
    map_height: float,
    orientation: str,
) -> tuple[float, float]:
    """Convert world X/Z to the displayed raster orientation."""
    source_x = (world_x - doc.origin[0]) / doc.size_m * map_width
    source_y = (world_z - doc.origin[1]) / doc.size_m * map_height
    if orientation == "rotate_cw_flip_vertical":
        # Apply the same operations as _orient_base to source pixel space:
        # clockwise rotation (max-y, x), then vertical-axis mirror.
        return source_y, source_x
    if orientation == "rotate_cw":
        return map_width - source_y, source_x
    if orientation == "rotate_ccw":
        return source_y, map_height - source_x
    if orientation == "flip_x":
        return map_width - source_x, source_y
    if orientation == "flip_y":
        return source_x, map_height - source_y
    return source_x, source_y


def render_annotated_map(doc: MapDocument, report: dict[str, Any], output_size: int = 1400) -> Image.Image:
    """Render only the clean map backdrop.

    Prefab markers, flat-area boxes, grid lines and popups belong to the web
    overlay. Keeping them out of this PNG prevents a duplicate marker beneath
    the interactive SVG layer and makes the downloaded image useful as a clean
    RustEdit-style map render.
    """
    output_size = max(700, min(int(output_size), 2400))
    height = decode_heightmap(doc)
    topology = decode_topology(doc)
    splat = decode_splat(doc)
    biome = decode_biome(doc)
    # The supplied RustEdit render establishes the native row-axis direction:
    # decoded map rows must be flipped top-to-bottom to put Rust grid row A0
    # at the top of the displayed raster. Older reports may still explicitly
    # request one of the legacy rotation names.
    orientation = str(report.get("render", {}).get("orientation", "flip_y"))

    if height is not None:
        height_scale = float(report.get("map", {}).get("height_scale_m", doc.size_y_m))
        if splat is not None:
            base = _splat_base(height, splat, biome, topology, (output_size, output_size), height_scale)
        else:
            base = _height_base(height, (output_size, output_size), height_scale, topology, biome)
    elif topology is not None:
        base = _topology_base(topology, (output_size, output_size))
    else:
        base = _empty_base((output_size, output_size))
    base = _orient_base(base, orientation)

    # Authored paths are part of the map itself, not prefab annotations. Keep
    # them subtle because the source splat layer often already paints roads.
    if doc.paths:
        path_layer = Image.new("RGBA", (output_size, output_size), (0, 0, 0, 0))
        path_draw = ImageDraw.Draw(path_layer, "RGBA")
        path_colors = {
            "road": (50, 45, 37, 135),
            "river": (21, 104, 143, 170),
            "rail": (73, 68, 51, 145),
        }
        for path in doc.paths:
            nodes = path.get("nodes") or []
            points: list[tuple[float, float]] = []
            for node in nodes:
                if isinstance(node, dict):
                    world_x = float(node.get("x", 0.0))
                    world_z = float(node.get("z", 0.0))
                elif isinstance(node, (tuple, list)) and len(node) >= 3:
                    world_x, world_z = float(node[0]), float(node[2])
                else:
                    continue
                px, py = _display_point(doc, world_x, world_z, output_size, output_size, orientation)
                points.append((px, py))
            if len(points) >= 2:
                name = str(path.get("name", "")).lower()
                color = next((value for key, value in path_colors.items() if key in name), (68, 67, 58, 110))
                path_draw.line(points, fill=(8, 14, 17, 95), width=3, joint="curve")
                path_draw.line(points, fill=color, width=1, joint="curve")
        base = Image.alpha_composite(base.convert("RGBA"), path_layer).convert("RGB")

    return base


__all__ = ["render_annotated_map"]
