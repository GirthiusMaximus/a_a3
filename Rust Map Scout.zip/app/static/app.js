const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));

let selectedFile = null;
let activeSource = "file";
let defaultRules = "";
let latestResult = null;
let selectedMarkerId = null;
let selectedAreaId = null;
const mapState = { zoom: 1, tx: 0, ty: 0, dragging: false, lastX: 0, lastY: 0 };
const SVG_NS = "http://www.w3.org/2000/svg";

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function safeResourceUrl(value) {
  const text = String(value ?? "").trim();
  if (!text) return "";
  try {
    const parsed = new URL(text, window.location.href);
    return ["http:", "https:"].includes(parsed.protocol) ? parsed.href : "";
  } catch (_) {
    return "";
  }
}

function formatBytes(value) {
  if (!value) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  let n = value;
  let i = 0;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i += 1; }
  return `${n.toFixed(n >= 10 || i === 0 ? 0 : 1)} ${units[i]}`;
}

function setStatus(message, error = false) {
  const box = $("#statusBox");
  box.textContent = message;
  box.classList.toggle("error", error);
  box.classList.remove("hidden");
}

function clearStatus() {
  $("#statusBox").classList.add("hidden");
}

function setSelectedFile(file) {
  selectedFile = file || null;
  if (selectedFile) activeSource = "file";
  const chip = $("#fileChip");
  if (!selectedFile) {
    chip.classList.add("hidden");
    $("#fileName").textContent = "No file selected";
    $("#fileInput").value = "";
    return;
  }
  $("#fileName").textContent = `${selectedFile.name} · ${formatBytes(selectedFile.size)}`;
  chip.classList.remove("hidden");
  $("#mapUrl").value = "";
  clearStatus();
}

function activateSource(source) {
  activeSource = source;
  $$(".source-tab").forEach((button) => {
    const active = button.dataset.source === source;
    button.classList.toggle("active", active);
    button.setAttribute("aria-selected", active ? "true" : "false");
  });
  $$(".source-pane").forEach((pane) => {
    pane.hidden = pane.dataset.pane !== source;
    pane.classList.toggle("active", pane.dataset.pane === source);
  });
}

function numberText(value, suffix = "") {
  if (value === null || value === undefined || value === "") return "—";
  return `${value}${suffix}`;
}

function visualLayerInfo(map) {
  const visual = map?.visual_layers || {};
  const splat = visual.splat?.present ? "splat" : "no splat";
  const biome = visual.biome?.present ? "biome" : "no biome";
  return ` · ${splat} · ${biome}`;
}

function renderSizeAndInset(data) {
  const render = data.render || {};
  const size = Number(render.size || 1400);
  const rect = render.map_rect;
  if (rect) {
    const left = Number(rect.left || 0);
    const top = Number(rect.top || 0);
    const width = Number(rect.width || size);
    const height = Number(rect.height || size);
    return { size, left, top, right: Math.max(0, size - left - width), bottom: Math.max(0, size - top - height) };
  }
  const inset = render.map_inset || { left: 22, top: 54, right: 22, bottom: 42 };
  return {
    size,
    left: Number(inset.left ?? 22),
    top: Number(inset.top ?? 54),
    right: Number(inset.right ?? 22),
    bottom: Number(inset.bottom ?? 42),
  };
}

function displayPixel(x, y, resolution, data = latestResult) {
  const orientation = data?.render?.orientation || "flip_y";
  const max = Math.max(1, resolution - 1);
  if (orientation === "rotate_cw_flip_vertical") return { x: y, y: x };
  if (orientation === "rotate_cw") return { x: max - y, y: x };
  if (orientation === "rotate_ccw") return { x: y, y: max - x };
  if (orientation === "flip_x") return { x: max - x, y };
  if (orientation === "flip_y") return { x, y: max - y };
  return { x, y };
}

function markerPoint(marker, data = latestResult) {
  if (!marker || !marker.pixel || !data) return null;
  const layout = renderSizeAndInset(data);
  const resolution = Number(marker.pixel.resolution || 1);
  const mapWidth = layout.size - layout.left - layout.right;
  const mapHeight = layout.size - layout.top - layout.bottom;
  const point = displayPixel(Number(marker.pixel.x || 0), Number(marker.pixel.y || 0), resolution, data);
  return {
    x: layout.left + point.x / Math.max(1, resolution - 1) * mapWidth,
    y: layout.top + point.y / Math.max(1, resolution - 1) * mapHeight,
  };
}

function svgElement(name, attrs = {}) {
  const node = document.createElementNS(SVG_NS, name);
  Object.entries(attrs).forEach(([key, value]) => node.setAttribute(key, String(value)));
  return node;
}

function renderMapGrid(data) {
  const overlay = $("#mapOverlay");
  if (!overlay || !data) return;
  const layout = renderSizeAndInset(data);
  const map = data.map || {};
  const grid = map.grid || { cell_size_m: 150, numbering: "zero_based" };
  const cellSize = Number(grid.cell_size_m || 150);
  const worldSize = Number(map.size_m || 4500);
  const columns = Math.ceil(worldSize / cellSize);
  const rows = Math.ceil(worldSize / cellSize);
  const mapWidth = layout.size - layout.left - layout.right;
  const mapHeight = layout.size - layout.top - layout.bottom;
  const orientation = data?.render?.orientation || "flip_y";
  const gridGroup = svgElement("g", { class: "map-grid" });
  const columnName = (index) => {
    let result = "";
    let number = index + 1;
    while (number) {
      number -= 1;
      result = String.fromCharCode(65 + (number % 26)) + result;
      number = Math.floor(number / 26);
    }
    return result;
  };
  const addLine = (x1, y1, x2, y2) => gridGroup.appendChild(svgElement("line", { x1, y1, x2, y2, class: "grid-line" }));
  const addLabel = (x, y, text) => {
    const label = svgElement("text", { x, y, class: "grid-label" });
    label.textContent = text;
    gridGroup.appendChild(label);
  };

  // Project the actual world-grid boundaries through the same transform as
  // the raster and markers. RustEdit's north/top row numbering is handled
  // explicitly below for the native row-axis correction.
  const projectionResolution = Math.max(2, Number(map.heightmap_resolution || 2));
  const project = (nx, ny) => {
    const point = displayPixel(nx * (projectionResolution - 1), ny * (projectionResolution - 1), projectionResolution, data);
    return {
      x: layout.left + point.x / (projectionResolution - 1) * mapWidth,
      y: layout.top + point.y / (projectionResolution - 1) * mapHeight,
    };
  };
  for (let i = 0; i <= columns; i += 1) {
    const start = project(i / columns, 0);
    const end = project(i / columns, 1);
    addLine(start.x, start.y, end.x, end.y);
    if (i < columns) {
      const labelPoint = project((i + 0.5) / columns, 0.018);
      addLabel(labelPoint.x + 5, labelPoint.y + 16, columnName(i));
    }
  }
  for (let i = 0; i <= rows; i += 1) {
    // RustEdit labels row 0 at the north/top edge. With the native row-axis
    // correction, source row zero is the south/bottom edge, so invert the
    // source-space Y used to project grid labels and lines.
    const sourceRow = orientation === "flip_y" ? 1 - i / rows : i / rows;
    const start = project(0, sourceRow);
    const end = project(1, sourceRow);
    addLine(start.x, start.y, end.x, end.y);
    if (i < rows) {
      const rowNumber = grid.numbering === "one_based" ? i + 1 : i;
      const labelSourceRow = orientation === "flip_y" ? 1 - (i + 0.5) / rows : (i + 0.5) / rows;
      const labelPoint = project(0.018, labelSourceRow);
      addLabel(labelPoint.x + 5, labelPoint.y + 16, rowNumber);
    }
  }
  overlay.appendChild(gridGroup);
}

function snapToStagePoint(point, requestedZoom = 1.8) {
  const viewport = $("#mapViewport");
  if (!viewport || !point) return;
  const nextZoom = Math.max(mapState.zoom, Math.min(3.2, requestedZoom));
  mapState.zoom = nextZoom;
  mapState.tx = viewport.clientWidth / 2 - point.x * nextZoom;
  mapState.ty = viewport.clientHeight / 2 - point.y * nextZoom;
  applyMapTransform();
}

function topologySlug(label) {
  return String(label || "none").toLowerCase().replace(/[^a-z0-9]+/g, "-") || "none";
}

function foundationHeatColor(ratio) {
  const stops = [
    [0, [38, 157, 99]],
    [.25, [108, 181, 80]],
    [1, [239, 205, 68]],
    [1.5, [239, 127, 54]],
    [2, [210, 49, 48]],
  ];
  const value = Math.max(0, Math.min(2, Number(ratio) || 0));
  for (let index = 1; index < stops.length; index += 1) {
    if (value <= stops[index][0]) {
      const [lowStop, lowColor] = stops[index - 1];
      const [highStop, highColor] = stops[index];
      const t = (value - lowStop) / Math.max(.001, highStop - lowStop);
      const color = lowColor.map((channel, channelIndex) => Math.round(channel + (highColor[channelIndex] - channel) * t));
      return `rgb(${color.join(",")})`;
    }
  }
  return "rgb(210,49,48)";
}

function sampleDirection(rowIndex, columnIndex, center, cellMeters) {
  const northMeters = (center - rowIndex) * cellMeters;
  const eastMeters = (columnIndex - center) * cellMeters;
  const parts = [];
  if (Math.abs(northMeters) >= cellMeters * .45) parts.push(`${northMeters > 0 ? "N" : "S"} ${Math.abs(northMeters).toFixed(1)} m`);
  if (Math.abs(eastMeters) >= cellMeters * .45) parts.push(`${eastMeters > 0 ? "E" : "W"} ${Math.abs(eastMeters).toFixed(1)} m`);
  return parts.length ? parts.join(" · ") : "CENTRE";
}

function topologyVisualizationHtml(topology, data = latestResult) {
  const sample = topology && topology.sample_grid;
  if (!sample || !Array.isArray(sample.cells) || !sample.size) return "";
  const size = Math.max(9, Math.min(31, Number(sample.size) || 31));
  const center = Number(sample.center ?? Math.floor(size / 2));
  const reverseRows = data?.render?.orientation === "flip_y";
  const rawCells = sample.cells;
  const rawHeights = Array.isArray(sample.heights_m) ? sample.heights_m : [];
  const rawSlopes = Array.isArray(sample.slope_deg) ? sample.slope_deg : [];
  const rawRises = Array.isArray(sample.rise_per_foundation_m) ? sample.rise_per_foundation_m : [];
  const finiteSlopes = rawSlopes.flat().filter((value) => Number.isFinite(Number(value))).map(Number);
  const finiteRises = rawRises.flat().filter((value) => Number.isFinite(Number(value))).map(Number);
  const foundationReference = sample.foundation_reference || {};
  const foundationSize = Number(foundationReference.footprint_m || 3.0);
  const foundationStep = Number(foundationReference.height_step_m || 1.25);
  const cellMeters = Number(sample.cell_m || ((Number(sample.radius_m || 0) * 2) / size) || 1);
  const displayCells = reverseRows ? rawCells.slice().reverse() : rawCells;
  const displayHeights = reverseRows ? rawHeights.slice().reverse() : rawHeights;
  const displaySlopes = reverseRows ? rawSlopes.slice().reverse() : rawSlopes;
  const displayRises = reverseRows ? rawRises.slice().reverse() : rawRises;
  const cells = displayCells.map((row, rowIndex) => (row || []).map((label, columnIndex) => {
    const heightValue = displayHeights[rowIndex]?.[columnIndex];
    const slopeValue = displaySlopes[rowIndex]?.[columnIndex];
    const riseValue = displayRises[rowIndex]?.[columnIndex];
    const numericHeight = Number(heightValue);
    const numericSlope = Number(slopeValue);
    const numericRise = Number(riseValue);
    const hasHeight = Number.isFinite(numericHeight);
    const hasSlope = Number.isFinite(numericSlope);
    const hasRise = Number.isFinite(numericRise);
    if (!hasHeight && !hasSlope && !hasRise && !label) return `<span class="topology-cell topology-outside" title="Outside sampled circle"></span>`;
    const centerClass = rowIndex === center && columnIndex === center ? " topology-center" : "";
    const derivedRise = hasRise ? numericRise : (hasSlope ? Math.tan(numericSlope * Math.PI / 180) * foundationSize : null);
    const heatRatio = Number.isFinite(derivedRise) ? Math.max(0, derivedRise / Math.max(.01, foundationStep)) : 0;
    const heatColor = Number.isFinite(derivedRise) ? foundationHeatColor(heatRatio) : "#29454b";
    const direction = sampleDirection(rowIndex, columnIndex, center, cellMeters);
    const heightText = hasHeight ? `Y ${numericHeight.toFixed(2)} m` : "Y unavailable";
    const slopeText = hasSlope ? `slope ${numericSlope.toFixed(2)}°` : "slope unavailable";
    const riseText = Number.isFinite(derivedRise) ? `ΔY/${foundationSize.toFixed(1)}m ${derivedRise.toFixed(2)} m` : "ΔY unavailable";
    const ariaLabel = `${direction} · ${heightText} · ${riseText} · ${slopeText}`;
    return `<span class="topology-cell topology-height-cell height-sample-cell${centerClass}" style="background:${heatColor}" data-height-m="${hasHeight ? numericHeight : ""}" data-slope-deg="${hasSlope ? numericSlope : ""}" data-rise-m="${Number.isFinite(derivedRise) ? derivedRise.toFixed(2) : ""}" data-direction="${escapeHtml(direction)}" tabindex="0" aria-label="${escapeHtml(ariaLabel)}" title="${escapeHtml(ariaLabel)}"></span>`;
  }).join("")).join("");
  const radius = Number(topology.radius_m ?? sample.radius_m);
  const radiusText = Number.isFinite(radius) ? `${radius.toFixed(1)} m radius` : "— radius";
  const widthText = Number.isFinite(radius) ? `${(radius * 2).toFixed(1)} × ${(radius * 2).toFixed(1)} m window` : "sample window";
  const cell = Number.isFinite(cellMeters) ? ` · ${cellMeters.toFixed(2)} m cells` : "";
  const bounds = sample.world_bounds || {};
  const centerWorld = sample.center_world || {};
  const worldMeta = centerWorld.x !== undefined && centerWorld.z !== undefined
    ? `Centre X ${escapeHtml(centerWorld.x)} · Z ${escapeHtml(centerWorld.z)}`
    : "North is up · East is right";
  const worldBounds = bounds.west_x !== undefined
    ? `W ${escapeHtml(bounds.west_x)} → E ${escapeHtml(bounds.east_x)} X · S ${escapeHtml(bounds.south_z)} → N ${escapeHtml(bounds.north_z)} Z`
    : "";
  const axis = sample.axis_labels || { top: "North", bottom: "South", left: "West", right: "East" };
  const centerSlope = Number(displaySlopes[center]?.[center]);
  const centerRise = Number(displayRises[center]?.[center]);
  const riseMin = Number.isFinite(Number(sample.rise_min_m)) ? Number(sample.rise_min_m) : (finiteRises.length ? Math.min(...finiteRises) : 0);
  const riseMax = Number.isFinite(Number(sample.rise_max_m)) ? Number(sample.rise_max_m) : (finiteRises.length ? Math.max(...finiteRises) : 0);
  const foundationLimitSlope = Number(foundationReference.step_slope_deg || (Math.atan(foundationStep / foundationSize) * 180 / Math.PI));
  const slopeReadout = finiteSlopes.length
    ? `<div class="topology-slope-readout"><b>Terrain slope</b> <strong>${escapeHtml(sample.slope_min_deg ?? 0)}–${escapeHtml(sample.slope_max_deg ?? Math.max(...finiteSlopes).toFixed(2))}°</strong>${Number.isFinite(centerSlope) ? ` · centre <strong>${centerSlope.toFixed(2)}°</strong>` : ""}<br><b>Rise over ${foundationSize.toFixed(1)} m</b> <strong>${riseMin.toFixed(2)}–${riseMax.toFixed(2)} m</strong>${Number.isFinite(centerRise) ? ` · centre <strong>${centerRise.toFixed(2)} m</strong>` : ""} · adjacent foundation allowance <strong>${foundationStep.toFixed(2)} m</strong> (${foundationLimitSlope.toFixed(2)}°)</div><div class="topology-slope-scale"><span>FLAT</span><i></i><span>&gt; ${foundationStep.toFixed(2)} m / ${foundationSize.toFixed(1)} m</span></div>`
    : `<div class="topology-slope-readout"><b>Terrain slope unavailable</b> — no per-cell slope could be derived</div>`;
  const heightReadout = Number.isFinite(Number(sample.height_min_m)) && Number.isFinite(Number(sample.height_max_m))
    ? `<div class="topology-height-readout"><b>Y elevation</b> <strong>${escapeHtml(sample.height_min_m)}–${escapeHtml(sample.height_max_m)} m</strong>${Number.isFinite(Number(sample.center_height_m)) ? ` · centre <strong>${escapeHtml(sample.center_height_m)} m</strong>` : ""}</div>`
    : `<div class="topology-height-readout"><b>Y elevation unavailable</b> — this map has no decoded height layer</div>`;
  return `<div class="topology-visual"><div class="topology-visual-head"><b>HEIGHT / SLOPE HEATMAP</b><span>${escapeHtml(radiusText)}${cell}</span></div><div class="topology-sample-meta"><b>${escapeHtml(widthText)}</b> · ${worldMeta}${worldBounds ? `<br>${worldBounds}` : ""}</div>${heightReadout}${slopeReadout}<div class="topology-direction-north">${escapeHtml(axis.top.toUpperCase())} ↑</div><div class="topology-grid-row"><div class="topology-direction-side">← ${escapeHtml(axis.left.toUpperCase())}</div><div class="topology-grid" style="--topology-size:${size}">${cells}</div><div class="topology-direction-side">${escapeHtml(axis.right.toUpperCase())} →</div></div><div class="topology-direction-south">↓ ${escapeHtml(axis.bottom.toUpperCase())}</div><div class="topology-hover-readout" aria-live="polite">Hover or focus a cell to read direction, Y height and slope.</div><div class="topology-legend"><span class="topology-key"><i class="slope-swatch slope-swatch-flat"></i>flatter</span><span class="topology-key"><i class="slope-swatch slope-swatch-steep"></i>steeper</span></div></div>`;
}

function isGodRockMarker(marker) {
  return marker && (marker.rule_id === "god-rock" || marker.kind === "god_rock");
}

function topologyOverlayColor(label) {
  const colors = {
    Ocean: "#2b515c", Offshore: "#2b515c", Lake: "#4d9db0", River: "#4d9db0",
    Cliff: "#b1876f", Road: "#c7954f", Runway: "#c7954f", Beach: "#d0b77d",
    Beachside: "#d0b77d", Forest: "#4d7130", Forestside: "#4d7130", Field: "#7e9a4d",
    Hilltop: "#7e9a4d", Summit: "#a4a9a0", Mountain: "#a4a9a0", Swamp: "#4e735e",
    Building: "#b36d9f", Monument: "#b36d9f", Decor: "#b36d9f", None: "#52616a",
  };
  return colors[label] || "#66706a";
}

function appendTopologyOverlay(group, marker, point, data, mapWidth, mapHeight) {
  if (!isGodRockMarker(marker)) return;
  const sample = marker.analysis?.topology?.sample_grid;
  if (!sample || !Array.isArray(sample.cells) || !sample.size) return;
  const size = Math.max(9, Math.min(31, Number(sample.size) || 31));
  const radius = Number(marker.analysis?.topology?.radius_m ?? sample.radius_m ?? 0);
  const worldSize = Number(data.map?.size_m || 1);
  if (!(radius > 0) || !(worldSize > 0)) return;
  const radiusX = radius / worldSize * mapWidth;
  const radiusY = radius / worldSize * mapHeight;
  const cellWidth = radiusX * 2 / size;
  const cellHeight = radiusY * 2 / size;
  const reverseRows = data?.render?.orientation === "flip_y";
  const heights = Array.isArray(sample.heights_m) ? sample.heights_m : [];
  const slopes = Array.isArray(sample.slope_deg) ? sample.slope_deg : [];
  const rises = Array.isArray(sample.rise_per_foundation_m) ? sample.rise_per_foundation_m : [];
  const foundationReference = sample.foundation_reference || {};
  const foundationSize = Number(foundationReference.footprint_m || 3.0);
  const foundationStep = Number(foundationReference.height_step_m || 1.25);
  const cellMeters = Number(sample.cell_m || ((radius * 2) / size) || 1);
  const center = Number(sample.center ?? Math.floor(size / 2));
  const overlay = svgElement("g", { class: "topology-overlay", "aria-label": "God Rock height and slope heatmap" });
  sample.cells.forEach((row, rawRowIndex) => (row || []).forEach((label, columnIndex) => {
    const rowIndex = reverseRows ? size - 1 - rawRowIndex : rawRowIndex;
    const heightValue = Number(heights[rawRowIndex]?.[columnIndex]);
    const slopeValue = Number(slopes[rawRowIndex]?.[columnIndex]);
    const riseValue = Number(rises[rawRowIndex]?.[columnIndex]);
    const hasSlope = Number.isFinite(slopeValue);
    const hasRise = Number.isFinite(riseValue);
    if (!Number.isFinite(heightValue) && !hasSlope && !hasRise) return;
    const derivedRise = hasRise ? riseValue : (hasSlope ? Math.tan(slopeValue * Math.PI / 180) * foundationSize : null);
    const heatRatio = Number.isFinite(derivedRise) ? Math.max(0, derivedRise / Math.max(.01, foundationStep)) : 0;
    const direction = sampleDirection(rowIndex, columnIndex, center, cellMeters);
    const rect = svgElement("rect", {
      x: point.x - radiusX + columnIndex * cellWidth,
      y: point.y - radiusY + rowIndex * cellHeight,
      width: Math.max(1, cellWidth - 0.5),
      height: Math.max(1, cellHeight - 0.5),
      rx: 1,
      class: "topology-overlay-cell height-overlay-cell",
      fill: Number.isFinite(derivedRise) ? foundationHeatColor(heatRatio) : "#29454b",
      "fill-opacity": Number.isFinite(derivedRise) ? .7 + .2 * Math.min(1, heatRatio / 2) : .55,
      "data-height-m": Number.isFinite(heightValue) ? heightValue.toFixed(2) : "",
      "data-slope-deg": hasSlope ? slopeValue.toFixed(2) : "",
      "data-rise-m": Number.isFinite(derivedRise) ? derivedRise.toFixed(2) : "",
      "data-direction": direction,
    });
    const title = svgElement("title");
    title.textContent = `${direction} · ${Number.isFinite(heightValue) ? `Y ${heightValue.toFixed(2)} m` : "Y unavailable"}${Number.isFinite(derivedRise) ? ` · ΔY/${foundationSize.toFixed(1)}m ${derivedRise.toFixed(2)} m` : ""}${hasSlope ? ` · slope ${slopeValue.toFixed(2)}°` : ""}`;
    rect.appendChild(title);
    overlay.appendChild(rect);
  }));
  overlay.appendChild(svgElement("circle", {
    cx: point.x, cy: point.y, r: Math.max(radiusX, radiusY),
    class: "topology-overlay-ring", fill: "none", "stroke-width": 2,
  }));
  const addDirection = (x, y, label, anchor = "middle") => {
    const text = svgElement("text", { x, y, class: "topology-overlay-direction", "text-anchor": anchor });
    text.textContent = label;
    overlay.appendChild(text);
  };
  addDirection(point.x, point.y - radiusY - 7, "N");
  addDirection(point.x, point.y + radiusY + 15, "S");
  addDirection(point.x - radiusX - 7, point.y + 4, "W", "end");
  addDirection(point.x + radiusX + 7, point.y + 4, "E", "start");
  group.appendChild(overlay);
}

function openMarkerPopup(marker, focus = false) {
  const popup = $("#markerPopup");
  if (!popup || !marker) return;
  selectedAreaId = null;
  selectedMarkerId = marker.marker_id;
  const p = marker.position || {};
  const scale = marker.scale || {};
  const grid = marker.grid_reference || {};
  const slope = marker.analysis && marker.analysis.slope;
  const topology = marker.analysis && marker.analysis.topology;
  const showTopology = isGodRockMarker(marker) && topology;
  const building = marker.analysis && marker.analysis.building;
  const fullName = marker.name || "unknown prefab";
  const modelUrl = safeResourceUrl(marker.model_url);
  const previewUrl = safeResourceUrl(marker.preview_url);
  const modelFormat = String(marker.model_format || "model").toUpperCase();
  const modelLink = modelUrl ? `<a class="popup-asset-link" href="${escapeHtml(modelUrl)}" target="_blank" rel="noreferrer">Open extracted ${escapeHtml(modelFormat)} model ↗</a>` : "";
  const previewTitle = marker.preview_kind === "asset" ? "Extracted Rust asset preview" : "Category 3D preview";
  const previewNote = marker.preview_is_placeholder ? "Stylised category fallback · add an exact asset render in the catalog" : previewTitle;
  const preview = previewUrl ? `<div class="popup-preview-wrap"><img class="popup-preview" src="${escapeHtml(previewUrl)}" alt="${escapeHtml(marker.short_name || "Prefab")} preview"><div class="popup-preview-note"><span class="preview-badge">${escapeHtml(previewTitle)}</span>${escapeHtml(previewNote)}</div>${modelLink}</div>` : (modelLink ? `<div class="popup-preview-empty"><b>Extracted ${escapeHtml(modelFormat)} model</b><span>Use the asset link to open the supplied mesh.</span>${modelLink}</div>` : `<div class="popup-preview-empty"><b>Category 3D preview unavailable</b><span>No preview asset was supplied for this prefab.</span></div>`);
  const buildingInfo = building && building.status !== "unknown" ? `<div class="popup-quality ${building.status === "blocked" ? "poor" : "ideal"}"><b>${building.status === "blocked" ? "BUILDING-BLOCKING ELEMENTS" : "NO CONFIGURED BUILDING BLOCKERS"}</b><div class="subline">${escapeHtml(building.message)}</div></div>` : "";
  popup.innerHTML = `
    <button class="popup-close" type="button" aria-label="Close marker details">×</button>
    <div class="popup-kicker">${escapeHtml(marker.label || marker.kind || "Prefab")}</div>
    <div class="popup-title">${escapeHtml(marker.short_name || marker.name || "Unknown prefab")}</div>
    <div class="popup-path">${escapeHtml(fullName)}</div>
    ${preview}
    <div class="popup-grid">
      <div class="popup-field"><label>Grid reference</label><b>${escapeHtml(grid.reference || "—")}</b></div>
      <div class="popup-field"><label>Prefab ID</label><b>${escapeHtml(marker.prefab_id ?? "—")}</b></div>
      <div class="popup-field"><label>World X / Y / Z</label><b>${escapeHtml(`${p.x ?? "—"}, ${p.y ?? "—"}, ${p.z ?? "—"}`)}</b></div>
      <div class="popup-field"><label>Scale X / Y / Z</label><b>${escapeHtml(`${scale.x ?? "—"} × ${scale.y ?? "—"} × ${scale.z ?? "—"}`)}</b></div>
    </div>
    ${slope ? `<div class="subline">Floor angle: ${escapeHtml(slope.mean_angle_deg ?? "—")}° mean · ${escapeHtml(slope.p90_angle_deg ?? "—")}° p90 · Y delta ${escapeHtml(slope.vertical_delta_abs_m ?? "—")} m · surrounding Y range ${escapeHtml(slope.surrounding_y_range_m ?? "—")} m</div>` : ""}
    ${showTopology ? topologyVisualizationHtml(topology, latestResult) : ""}
    ${buildingInfo}
  `;
  popup.classList.remove("hidden");
  popup.querySelector(".popup-close").addEventListener("click", (event) => { event.stopPropagation(); closeMarkerPopup(); });
  const topologyReadout = popup.querySelector(".topology-hover-readout");
  if (topologyReadout) {
    const defaultTopologyReadout = "Hover or focus a sampled cell to read direction, Y height and slope.";
    popup.querySelectorAll(".height-sample-cell").forEach((cell) => {
      const showCellHeight = () => {
        const heightValue = Number(cell.dataset.heightM);
        const slopeValue = Number(cell.dataset.slopeDeg);
        const riseValue = Number(cell.dataset.riseM);
        const direction = cell.dataset.direction || "CENTRE";
        const heightText = Number.isFinite(heightValue) ? `Y <b>${heightValue.toFixed(2)} m</b>` : "Y unavailable";
        const slopeText = Number.isFinite(slopeValue) ? `slope <b>${slopeValue.toFixed(2)}°</b>` : "slope unavailable";
        const riseText = Number.isFinite(riseValue) ? `ΔY / 3m <b>${riseValue.toFixed(2)} m</b>` : "ΔY unavailable";
        topologyReadout.innerHTML = `<b>${escapeHtml(direction)}</b> · ${heightText} · ${riseText} · ${slopeText}`;
      };
      const resetCellHeight = () => { topologyReadout.textContent = defaultTopologyReadout; };
      cell.addEventListener("mouseenter", showCellHeight);
      cell.addEventListener("focus", showCellHeight);
      cell.addEventListener("mouseleave", resetCellHeight);
      cell.addEventListener("blur", resetCellHeight);
    });
  }
  if (focus) snapToStagePoint(markerPoint(marker, latestResult));
  renderInteractiveMarkers(latestResult);
  $$("#markerTableBody tr").forEach((row) => row.classList.toggle("selected-row", row.dataset.markerId === selectedMarkerId));
}

function openFlatAreaPopup(area) {
  const popup = $("#markerPopup");
  if (!popup || !area) return;
  selectedMarkerId = null;
  selectedAreaId = area.area_id;
  const center = area.center || {};
  const grid = area.grid_reference || {};
  popup.innerHTML = `
    <button class="popup-close" type="button" aria-label="Close flat area details">×</button>
    <div class="popup-kicker">FLAT BUILD AREA</div>
    <div class="popup-title">${escapeHtml(area.area_m2 ?? "—")} m² available</div>
    <div class="popup-path">Hammer candidate · ${escapeHtml(grid.reference || "—")}</div>
    <div class="popup-grid">
      <div class="popup-field"><label>Grid reference</label><b>${escapeHtml(grid.reference || "—")}</b></div>
      <div class="popup-field"><label>Centre X / Y / Z</label><b>${escapeHtml(`${center.x ?? "—"}, ${center.y ?? "—"}, ${center.z ?? "—"}`)}</b></div>
      <div class="popup-field"><label>Y range</label><b>${escapeHtml(`${area.min_y_m ?? "—"} → ${area.max_y_m ?? "—"} m`)}</b></div>
      <div class="popup-field"><label>Mean slope</label><b>${escapeHtml(area.mean_slope_deg ?? "—")}°</b></div>
    </div>
    <div class="popup-quality"><b>FLAT AREA</b><div class="subline">maximum local Y deviation ${escapeHtml(area.max_local_deviation_m ?? "—")} m · minimum allowed Y ${escapeHtml(area.settings?.min_y_m ?? "—")} m</div></div>
  `;
  popup.classList.remove("hidden");
  popup.querySelector(".popup-close").addEventListener("click", (event) => { event.stopPropagation(); closeMarkerPopup(); });
  renderInteractiveMarkers(latestResult);
}

function closeMarkerPopup() {
  selectedMarkerId = null;
  selectedAreaId = null;
  $("#markerPopup")?.classList.add("hidden");
  renderInteractiveMarkers(latestResult);
  $$("#markerTableBody tr").forEach((row) => row.classList.remove("selected-row"));
}

function renderInteractiveFlatAreas(data) {
  const overlay = $("#mapOverlay");
  if (!overlay || !data) return;
  const layout = renderSizeAndInset(data);
  const mapWidth = layout.size - layout.left - layout.right;
  const mapHeight = layout.size - layout.top - layout.bottom;
  (data.flat_areas || []).forEach((area) => {
    const bbox = area.bbox_pixel;
    if (!bbox) return;
    const resolution = Number(area.source_resolution || data.map?.heightmap_resolution || 1);
    if (resolution <= 1) return;
    const minX = Number(bbox.min_x || 0);
    const minY = Number(bbox.min_y || 0);
    const maxX = Number(bbox.max_x || 0);
    const maxY = Number(bbox.max_y || 0);
    const topLeft = displayPixel(minX, minY, resolution, data);
    const bottomRight = displayPixel(maxX, maxY, resolution, data);
    const x0 = Math.min(topLeft.x, bottomRight.x);
    const y0 = Math.min(topLeft.y, bottomRight.y);
    const x1 = Math.max(topLeft.x, bottomRight.x);
    const y1 = Math.max(topLeft.y, bottomRight.y);
    const x = layout.left + x0 / (resolution - 1) * mapWidth;
    const y = layout.top + y0 / (resolution - 1) * mapHeight;
    const width = Math.max(15, (x1 - x0) / (resolution - 1) * mapWidth);
    const height = Math.max(15, (y1 - y0) / (resolution - 1) * mapHeight);
    const group = svgElement("g", { class: "flat-area-group", "data-area-id": area.area_id });
    const rect = svgElement("rect", { x, y, width, height, rx: 8, class: "flat-area-box", fill: "#86c9a1", "fill-opacity": selectedAreaId === area.area_id ? .38 : .17, stroke: "#86c9a1", "stroke-width": selectedAreaId === area.area_id ? 4 : 2 });
    rect.addEventListener("click", (event) => { event.stopPropagation(); openFlatAreaPopup(area); });
    group.appendChild(rect);
    const cx = x + width / 2;
    const cy = y + height / 2;
    const iconGroup = svgElement("g", { class: "flat-area-icon", "data-anchor-x": cx, "data-anchor-y": cy });
    const hammer = svgElement("g", { class: `flat-area-hammer${selectedAreaId === area.area_id ? " selected" : ""}` });
    hammer.appendChild(svgElement("line", { x1: cx - 2, y1: cy + 9, x2: cx + 7, y2: cy - 6, class: "hammer-handle" }));
    hammer.appendChild(svgElement("line", { x1: cx - 8, y1: cy - 8, x2: cx + 6, y2: cy - 8, class: "hammer-head" }));
    hammer.addEventListener("click", (event) => { event.stopPropagation(); openFlatAreaPopup(area); });
    iconGroup.appendChild(hammer);
    const hammerHit = svgElement("circle", { cx, cy, r: 19, class: "flat-area-hammer-hit" });
    hammerHit.addEventListener("click", (event) => { event.stopPropagation(); openFlatAreaPopup(area); });
    iconGroup.appendChild(hammerHit);
    const label = svgElement("text", { x: x + 6, y: y + 17, class: "flat-area-label" });
    label.textContent = `${area.area_m2 ?? "?"} m²`;
    iconGroup.appendChild(label);
    group.appendChild(iconGroup);
    overlay.appendChild(group);
  });
}

function renderInteractiveMarkers(data) {
  const overlay = $("#mapOverlay");
  if (!overlay || !data) return;
  overlay.innerHTML = "";
  if ($("#gridToggle")?.checked) renderMapGrid(data);
  renderInteractiveFlatAreas(data);
  const layout = renderSizeAndInset(data);
  const mapWidth = layout.size - layout.left - layout.right;
  const mapHeight = layout.size - layout.top - layout.bottom;
  const markers = data.markers || [];
  const markerHitLayer = svgElement("g", { class: "marker-hit-layer", "aria-label": "Clickable prefab markers", "pointer-events": "all" });
  markers.forEach((marker) => {
    const point = markerPoint(marker, data);
    if (!point) return;
    const group = svgElement("g", { class: "marker-group", "data-marker-id": marker.marker_id });
    const color = marker.color || "#e6edf3";
    const analysis = marker.analysis || {};
    if (selectedMarkerId === marker.marker_id) appendTopologyOverlay(group, marker, point, data, mapWidth, mapHeight);
    const radii = [];
    if (analysis.slope && analysis.slope.radius_m) radii.push(Number(analysis.slope.radius_m));
    if (analysis.proximity && analysis.proximity.radius_m) radii.push(Number(analysis.proximity.radius_m));
    const radiusMeters = Math.max(...radii, 0);
    if (radiusMeters > 0) {
      group.appendChild(svgElement("circle", { cx: point.x, cy: point.y, r: radiusMeters / Number(data.map.size_m || 1) * mapWidth, class: "marker-ring", stroke: color }));
    }
    const iconGroup = svgElement("g", { class: "marker-icon", "data-anchor-x": point.x, "data-anchor-y": point.y });
    const hit = svgElement("circle", { cx: point.x, cy: point.y, r: selectedMarkerId === marker.marker_id ? 13 : 9, class: `marker-hit${selectedMarkerId === marker.marker_id ? " selected-marker" : ""}`, fill: color, "fill-opacity": selectedMarkerId === marker.marker_id ? .95 : .75, stroke: "#f7fbfc", "stroke-width": selectedMarkerId === marker.marker_id ? 3 : 1.5 });
    hit.addEventListener("click", (event) => { event.stopPropagation(); openMarkerPopup(marker); });
    iconGroup.appendChild(hit);
    const label = svgElement("text", { x: point.x + 13, y: point.y + 5, class: "grid-label" });
    label.textContent = marker.short_name || String(marker.prefab_index ?? "?");
    iconGroup.appendChild(label);
    group.appendChild(iconGroup);
    overlay.appendChild(group);
  });
  // Keep a transparent hit target above the selected heatmap. The sampled
  // cells can cover a rock's visual marker, but must never steal its click.
  markers.forEach((marker) => {
    const point = markerPoint(marker, data);
    if (!point) return;
    const hit = svgElement("circle", {
      cx: point.x,
      cy: point.y,
      r: selectedMarkerId === marker.marker_id ? 18 : 14,
      class: "marker-hit marker-hit-top",
      fill: "rgba(0,0,0,0.001)",
      "fill-opacity": 0.001,
      stroke: "none",
      "pointer-events": "all",
      "data-marker-id": marker.marker_id,
      "data-anchor-x": point.x,
      "data-anchor-y": point.y,
      "aria-label": `Open ${marker.short_name || marker.label || "prefab"} details`,
    });
    hit.addEventListener("click", (event) => {
      event.stopPropagation();
      openMarkerPopup(marker);
    });
    markerHitLayer.appendChild(hit);
  });
  overlay.appendChild(markerHitLayer);
  updateScreenConstantOverlay();
}

function updateScreenConstantOverlay() {
  const overlay = $("#mapOverlay");
  if (!overlay) return;
  const factor = 1 / Math.max(.001, mapState.zoom);
  const applyCounterScale = (node) => {
    const x = Number(node.dataset.anchorX);
    const y = Number(node.dataset.anchorY);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return;
    node.setAttribute("transform", `translate(${x},${y}) scale(${factor}) translate(${-x},${-y})`);
  };
  overlay.querySelectorAll(".marker-icon, .flat-area-icon, .marker-hit-top").forEach(applyCounterScale);
}

function clampMapTranslation() {
  const viewport = $("#mapViewport");
  if (!viewport) return;
  const base = renderSizeAndInset(latestResult || {}).size;
  const scaled = base * mapState.zoom;
  if (scaled <= viewport.clientWidth) {
    mapState.tx = (viewport.clientWidth - scaled) / 2;
  } else {
    mapState.tx = Math.min(0, Math.max(viewport.clientWidth - scaled, mapState.tx));
  }
  if (scaled <= viewport.clientHeight) {
    mapState.ty = (viewport.clientHeight - scaled) / 2;
  } else {
    mapState.ty = Math.min(0, Math.max(viewport.clientHeight - scaled, mapState.ty));
  }
}

function applyMapTransform() {
  const stage = $("#mapStage");
  if (stage) {
    clampMapTranslation();
    stage.style.transform = `translate(${mapState.tx}px, ${mapState.ty}px) scale(${mapState.zoom})`;
    updateScreenConstantOverlay();
  }
}

function resetMapView() {
  const viewport = $("#mapViewport");
  if (!viewport) return;
  const base = renderSizeAndInset(latestResult || {}).size;
  const scale = Math.min(viewport.clientWidth / base, viewport.clientHeight / base) * .96;
  mapState.zoom = Math.max(.18, Math.min(4, scale));
  mapState.tx = (viewport.clientWidth - base * mapState.zoom) / 2;
  mapState.ty = (viewport.clientHeight - base * mapState.zoom) / 2;
  applyMapTransform();
}

function zoomMapAt(clientX, clientY, factor) {
  const viewport = $("#mapViewport");
  if (!viewport) return;
  const rect = viewport.getBoundingClientRect();
  const localX = clientX - rect.left;
  const localY = clientY - rect.top;
  const beforeX = (localX - mapState.tx) / mapState.zoom;
  const beforeY = (localY - mapState.ty) / mapState.zoom;
  const nextZoom = Math.max(.18, Math.min(4, mapState.zoom * factor));
  mapState.zoom = nextZoom;
  mapState.tx = localX - beforeX * nextZoom;
  mapState.ty = localY - beforeY * nextZoom;
  applyMapTransform();
}

function wireInteractiveMap() {
  const viewport = $("#mapViewport");
  if (!viewport || viewport.dataset.wired === "true") return;
  viewport.dataset.wired = "true";
  viewport.addEventListener("wheel", (event) => { event.preventDefault(); zoomMapAt(event.clientX, event.clientY, event.deltaY < 0 ? 1.16 : .86); }, { passive: false });
  viewport.addEventListener("pointerdown", (event) => {
    if (event.target.closest(".marker-hit") || event.target.closest(".flat-area-box") || event.target.closest(".flat-area-hammer") || event.target.closest(".flat-area-hammer-hit") || event.target.closest("button") || event.target.closest("label")) return;
    mapState.dragging = true; mapState.lastX = event.clientX; mapState.lastY = event.clientY;
    viewport.classList.add("dragging"); viewport.setPointerCapture(event.pointerId);
  });
  viewport.addEventListener("pointermove", (event) => {
    if (!mapState.dragging) return;
    mapState.tx += event.clientX - mapState.lastX; mapState.ty += event.clientY - mapState.lastY;
    mapState.lastX = event.clientX; mapState.lastY = event.clientY; applyMapTransform();
  });
  const stopDrag = (event) => { mapState.dragging = false; viewport.classList.remove("dragging"); if (event.pointerId !== undefined && viewport.hasPointerCapture(event.pointerId)) viewport.releasePointerCapture(event.pointerId); };
  viewport.addEventListener("pointerup", stopDrag); viewport.addEventListener("pointercancel", stopDrag);
  viewport.addEventListener("click", (event) => { if (event.target === viewport) closeMarkerPopup(); });
  $("#zoomIn")?.addEventListener("click", (event) => { event.stopPropagation(); const r = viewport.getBoundingClientRect(); zoomMapAt(r.left + r.width / 2, r.top + r.height / 2, 1.35); });
  $("#zoomOut")?.addEventListener("click", (event) => { event.stopPropagation(); const r = viewport.getBoundingClientRect(); zoomMapAt(r.left + r.width / 2, r.top + r.height / 2, .74); });
  $("#resetView")?.addEventListener("click", (event) => { event.stopPropagation(); closeMarkerPopup(); resetMapView(); });
  $("#gridToggle")?.addEventListener("change", () => renderInteractiveMarkers(latestResult));
  window.addEventListener("resize", () => { if (!$("#resultState")?.classList.contains("hidden")) resetMapView(); });
}

function renderStats(data) {
  const summary = data.summary || {};
  const map = data.map || {};
  const stats = [
    ["MARKERS", summary.matched_marker_count ?? 0, "configured instances", "amber"],
    ["PREFABS SCANNED", summary.prefab_count ?? 0, `${summary.unresolved_id_count ?? 0} unresolved IDs`, "blue"],
    ["TERRAIN GRID", map.heightmap_resolution ? `${map.heightmap_resolution}²` : "—", map.heightmap_resolution ? "height samples" : "no height layer", "cyan"],
    ["MAP SPAN", map.size_m ? `${map.size_m} m` : "—", `${map.path_count ?? 0} path records`, "green"],
  ];
  $("#statsGrid").innerHTML = stats.map(([label, value, note, tone]) => `
    <div class="stat-card ${tone}">
      <div class="stat-label">${escapeHtml(label)}</div>
      <div class="stat-value">${escapeHtml(value)}</div>
      <div class="stat-note">${escapeHtml(note)}</div>
    </div>`).join("");
}

function markerTerrain(marker) {
  const a = marker.analysis || {};
  const slope = a.slope;
  const topology = a.topology;
  const proximity = a.proximity;
  const chunks = [];
  if (slope) {
    if (slope.mean_angle_deg !== undefined) chunks.push(`<b>${escapeHtml(slope.mean_angle_deg)}°</b> avg slope`);
    if (slope.p90_angle_deg !== undefined) chunks.push(`<span class="subline">p90 ${escapeHtml(slope.p90_angle_deg)}° · max ${escapeHtml(slope.max_angle_deg)}° · Y range ${escapeHtml(slope.surrounding_y_range_m ?? "—")} m</span>`);
  } else if (marker.kind === "rock" || marker.kind === "god_rock") {
    chunks.push(`<span class="subline">slope unavailable</span>`);
  }
  if (topology && topology.dominant) chunks.push(`<span class="subline">topology: ${escapeHtml(topology.dominant)}</span>`);
  if (proximity) chunks.push(`<span class="subline">${escapeHtml(proximity.nearby_prefab_count)} within ${escapeHtml(proximity.radius_m)} m · ${escapeHtml(proximity.center_prefab_count)} at centre</span>`);
  return chunks.join("") || "<span class=\"subline\">no terrain readout</span>";
}

function renderMarkers(data) {
  const markers = data.markers || [];
  $("#markerCountPill").textContent = markers.length;
  const body = $("#markerTableBody");
  $("#noMarkers").classList.toggle("hidden", markers.length !== 0);
  if (!markers.length) {
    body.innerHTML = "";
    return;
  }
  body.innerHTML = markers.map((marker) => {
    const p = marker.position || {};
    const s = marker.scale || {};
    const position = `${Number(p.x || 0).toFixed(1)}, ${Number(p.y || 0).toFixed(1)}, ${Number(p.z || 0).toFixed(1)}`;
    const scale = `${Number(s.x || 0).toFixed(2)} × ${Number(s.y || 0).toFixed(2)} × ${Number(s.z || 0).toFixed(2)}`;
    const id = marker.prefab_id === null || marker.prefab_id === undefined ? "no prefab id" : `id ${marker.prefab_id}`;
    const bounds = marker.in_bounds ? "in bounds" : "outside map bounds";
    const grid = marker.grid_reference && marker.grid_reference.reference ? marker.grid_reference.reference : "—";
    return `<tr data-marker-id="${escapeHtml(marker.marker_id)}" tabindex="0">
      <td><div class="object-cell"><span class="marker-swatch" style="background:${escapeHtml(marker.color || "#e6edf3")}"></span><div><strong>${escapeHtml(marker.short_name || marker.label || marker.name)}</strong><small>${escapeHtml(grid)} · ${escapeHtml(marker.label || "Prefab")}</small><span class="subline">${escapeHtml(id)} · ${escapeHtml(bounds)}</span></div></div></td>
      <td class="mono">${escapeHtml(position)}<span class="subline">x, y, z metres</span></td>
      <td class="mono">${escapeHtml(scale)}<span class="subline">current scale</span></td>
      <td>${markerTerrain(marker)}</td>
    </tr>`;
  }).join("");
  $$("#markerTableBody tr").forEach((row) => {
    const activate = () => {
      const marker = markers.find((item) => item.marker_id === row.dataset.markerId);
      if (marker) openMarkerPopup(marker, true);
    };
    row.addEventListener("click", activate);
    row.addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); activate(); } });
  });
}

function renderWarnings(data) {
  const box = $("#warningBox");
  const warnings = data.warnings || [];
  if (!warnings.length) {
    box.classList.add("hidden");
    box.innerHTML = "";
    return;
  }
  box.classList.remove("hidden");
  box.innerHTML = `<b>Analysis notes</b><ul>${warnings.map((warning) => `<li>${escapeHtml(warning)}</li>`).join("")}</ul>`;
}

function renderReadout(data) {
  const summary = data.summary || {};
  const map = data.map || {};
  const items = [];
  if ((summary.matched_marker_count || 0) > 0) items.push(["✓", `${summary.matched_marker_count} configured marker${summary.matched_marker_count === 1 ? "" : "s"} placed on the rendered map.`]);
  if ((summary.unresolved_id_count || 0) > 0) items.push(["!", `${summary.unresolved_id_count} prefab IDs could not be named. Add their hashes to the catalog in the advanced rules panel.`]);
  if (!map.heightmap_resolution) items.push(["∠", "No height layer was found, so rock floor-angle values are intentionally left unavailable."]);
  if ((summary.rule_matches || {})["ice-lake"]) items.push(["◌", "Ice-lake proximity rings include every prefab in range; centre counts use the configured centre tolerance."]);
  if (data.flat_summary) items.push(["⚒", `${data.flat_summary.returned_count ?? 0} flat build-area candidate${(data.flat_summary.returned_count ?? 0) === 1 ? "" : "s"} found using the configured slope, relief, topology and minimum-Y filters.`]);
  if (!items.length) items.push(["→", "Adjust the prefab patterns or exact IDs in the advanced rules panel, then run the analysis again."]);
  const flatAreas = data.flat_areas || [];
  const flatList = flatAreas.length ? `<div class="flat-readout-list"><div class="readout-label">CLICKABLE FLAT AREAS</div>${flatAreas.slice(0, 40).map((area) => `<button type="button" class="flat-readout-item" data-area-id="${escapeHtml(area.area_id)}"><span class="readout-icon">⚒</span><span><b>${escapeHtml(area.area_m2 ?? "—")} m²</b><small>${escapeHtml(area.grid_reference?.reference || "—")} · Y ${escapeHtml(area.min_y_m ?? "—")} to ${escapeHtml(area.max_y_m ?? "—")} m · ${escapeHtml(area.mean_slope_deg ?? "—")}°</small></span></button>`).join("")}</div>` : "";
  $("#readoutList").innerHTML = items.map(([icon, text]) => `<div class="readout-item"><span class="readout-icon">${escapeHtml(icon)}</span><span>${escapeHtml(text)}</span></div>`).join("") + flatList;
  $$("#readoutList .flat-readout-item").forEach((button) => button.addEventListener("click", () => {
    const area = flatAreas.find((item) => item.area_id === button.dataset.areaId);
    if (!area) return;
    const bbox = area.bbox_pixel;
    const resolution = Number(area.source_resolution || data.map?.heightmap_resolution || 1);
    if (bbox && resolution > 1) {
      const point = displayPixel((Number(bbox.min_x) + Number(bbox.max_x)) / 2, (Number(bbox.min_y) + Number(bbox.max_y)) / 2, resolution, data);
      const layout = renderSizeAndInset(data);
      snapToStagePoint({ x: layout.left + point.x / (resolution - 1) * (layout.size - layout.left - layout.right), y: layout.top + point.y / (resolution - 1) * (layout.size - layout.top - layout.bottom) });
    }
    openFlatAreaPopup(area);
  }));
}

async function findFlatAreas() {
  if (!latestResult || !latestResult.job_id) return;
  const button = $("#findFlatButton");
  const form = new FormData();
  form.append("min_area_m2", $("#flatMinArea")?.value || "900");
  form.append("max_local_deviation_m", $("#flatDeviation")?.value || "6");
  form.append("max_slope_deg", $("#flatSlope")?.value || "5");
  form.append("min_y_m", $("#flatMinY")?.value || "-1");
  form.append("sample_radius_m", $("#flatRadius")?.value || "15");
  form.append("terrain_y_offset_m", $("#flatYOffset")?.value || "0");
  form.append("max_grid_cells", $("#flatResolution")?.value || "700");
  button.disabled = true;
  button.innerHTML = "<span>…</span> Searching";
  setStatus("Searching the map for connected flat build areas. Larger maps may take a little longer…");
  try {
    const response = await fetch(`/api/jobs/${latestResult.job_id}/flat-areas`, { method: "POST", body: form });
    const result = await response.json();
    if (!response.ok) throw new Error(result.detail || "Flat-area search failed");
    latestResult.flat_areas = result.flat_areas || [];
    latestResult.flat_summary = result.flat_summary || null;
    latestResult.warnings = result.warnings || latestResult.warnings;
    latestResult.map_image_url = result.map_image_url || latestResult.map_image_url;
    renderWarnings(latestResult);
    renderReadout(latestResult);
    const summary = latestResult.flat_summary;
    const flatMeta = summary ? ` · ${summary.returned_count ?? 0} flat areas` : "";
    const map = latestResult.map || {};
    const layerCount = (map.layers || []).length;
    $("#mapMeta").textContent = `${map.heightmap_resolution ? `${map.heightmap_resolution} × ${map.heightmap_resolution} terrain` : "grid backdrop"} · ${layerCount} layers${visualLayerInfo(map)} · height scale ${map.height_scale_m || "—"} m${flatMeta}`;
    const image = $("#mapImage");
    image.onload = () => { $(".map-frame").classList.add("loaded"); renderInteractiveMarkers(latestResult); };
    image.src = `${latestResult.map_image_url}?t=${Date.now()}`;
    $("#downloadJson").href = result.report_json_url || $("#downloadJson").href;
    $("#downloadBundle").href = result.bundle_url || $("#downloadBundle").href;
    setStatus(`Flat-area search complete: ${summary?.returned_count ?? 0} area${(summary?.returned_count ?? 0) === 1 ? "" : "s"} found.`);
  } catch (error) {
    setStatus(error.message || "Flat-area search failed", true);
  } finally {
    button.disabled = false;
    button.innerHTML = "<span>⚒</span> Find flat areas";
  }
}

function showResult(data) {
  latestResult = data;
  selectedMarkerId = null;
  wireInteractiveMap();
  $("#emptyState").classList.add("hidden");
  $("#resultState").classList.remove("hidden");
  const source = data.source || {};
  $("#resultTitle").textContent = source.name || "Annotated world";
  $("#resultSubtitle").textContent = `${source.format || "map"} · analysis job ${data.job_id || ""}`;
  renderStats(data);
  renderWarnings(data);
  renderMarkers(data);
  renderReadout(data);
  const map = data.map || {};
  const layerCount = (map.layers || []).length;
  const gridInfo = map.grid ? ` · ${map.grid.cell_size_m || 150} m grid` : "";
  $("#mapMeta").textContent = `${map.heightmap_resolution ? `${map.heightmap_resolution} × ${map.heightmap_resolution} terrain` : "grid backdrop"} · ${layerCount} layers${visualLayerInfo(map)} · height scale ${map.height_scale_m || "—"} m${gridInfo}`;
  const image = $("#mapImage");
  const stage = $("#mapStage");
  const layout = renderSizeAndInset(data);
  stage.style.width = `${layout.size}px`;
  stage.style.height = `${layout.size}px`;
  $("#mapOverlay").setAttribute("viewBox", `0 0 ${layout.size} ${layout.size}`);
  $("#mapLoading").textContent = "Rendering elevation and markers…";
  $(".map-frame").classList.remove("loaded");
  image.onload = () => {
    $(".map-frame").classList.add("loaded");
    renderInteractiveMarkers(data);
    resetMapView();
  };
  image.src = `${data.map_image_url}?t=${Date.now()}`;
  $("#downloadImage").href = data.map_image_url;
  $("#downloadJson").href = data.report_json_url;
  $("#downloadCsv").href = data.report_csv_url;
  $("#downloadBundle").href = data.bundle_url;
  $("#downloadVisualDebug").href = data.visual_debug_url || "#";
  window.scrollTo({ top: 0, behavior: "smooth" });
}

async function analyze() {
  clearStatus();
  const mapUrl = $("#mapUrl").value.trim();
  const useFile = activeSource === "file" && Boolean(selectedFile);
  const useUrl = activeSource === "url" && Boolean(mapUrl);
  if (!useFile && !useUrl) {
    setStatus(activeSource === "url" ? "Paste a public map URL first." : "Choose a map file first.", true);
    return;
  }
  const form = new FormData();
  if (useFile) form.append("map_file", selectedFile);
  if (useUrl) form.append("map_url", mapUrl);
  form.append("rules_json", $("#rulesJson").value);
  form.append("height_scale_m", $("#heightScale").value || "1000");
  form.append("render_size", "1400");
  const button = $("#analyzeButton");
  button.disabled = true;
  button.querySelector("span:nth-child(2)").textContent = "Analyzing…";
  setStatus("Reading map layers, matching prefab rules and measuring terrain…");
  try {
    const response = await fetch("/api/analyze", { method: "POST", body: form });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "Analysis failed");
    showResult(data);
    clearStatus();
  } catch (error) {
    setStatus(error.message || "Analysis failed", true);
  } finally {
    button.disabled = false;
    button.querySelector("span:nth-child(2)").textContent = "Analyze map";
  }
}

async function loadRules() {
  try {
    const response = await fetch("/api/config/default");
    if (!response.ok) throw new Error("rules unavailable");
    defaultRules = JSON.stringify(await response.json(), null, 2);
  } catch (_) {
    defaultRules = "{\n  \"rules\": []\n}";
  }
  $("#rulesJson").value = defaultRules;
}

async function useDemo() {
  try {
    setStatus("Loading the included demo fixture…");
    const response = await fetch("/demo-map.json");
    if (!response.ok) throw new Error("Demo fixture is not available");
    const blob = await response.blob();
    setSelectedFile(new File([blob], "demo-map.json", { type: "application/json" }));
    activateSource("file");
    setStatus("Demo map ready. Click Analyze map to run it.");
  } catch (error) {
    setStatus(error.message, true);
  }
}

$("#fileInput").addEventListener("change", (event) => setSelectedFile(event.target.files[0] || null));
$("#clearFile").addEventListener("click", () => setSelectedFile(null));
$("#demoButton").addEventListener("click", useDemo);
$("#analyzeButton").addEventListener("click", analyze);
$("#findFlatButton").addEventListener("click", findFlatAreas);
$("#resetRules").addEventListener("click", () => { $("#rulesJson").value = defaultRules; });
$("#mapUrl").addEventListener("input", () => { if ($("#mapUrl").value.trim()) setSelectedFile(null); });

$$('.source-tab').forEach((button) => button.addEventListener('click', () => activateSource(button.dataset.source)));

const dropzone = $("#dropzone");
dropzone.addEventListener("click", () => $("#fileInput").click());
dropzone.addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); $("#fileInput").click(); } });
["dragenter", "dragover"].forEach((name) => dropzone.addEventListener(name, (event) => { event.preventDefault(); dropzone.classList.add("dragging"); }));
["dragleave", "drop"].forEach((name) => dropzone.addEventListener(name, (event) => { event.preventDefault(); dropzone.classList.remove("dragging"); }));
dropzone.addEventListener("drop", (event) => {
  const file = event.dataTransfer.files[0];
  if (file) setSelectedFile(file);
});

loadRules();
