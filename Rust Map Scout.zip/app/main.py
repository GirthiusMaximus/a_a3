"""FastAPI service for Rust Map Scout."""

from __future__ import annotations

import ipaddress
import json
import os
import re
import socket
import uuid
import zipfile
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool

from .analyzer import RuleConfigError, analyze_document, default_config_json, find_flat_areas, flat_areas_geojson, report_csv, report_geojson, report_json
from .map_parser import MapParseError, parse_map
from .renderer import render_annotated_map
from .visual_debug import build_visual_debug_bundle


APP_DIR = Path(__file__).resolve().parent
PROJECT_DIR = APP_DIR.parent
EXAMPLES_DIR = PROJECT_DIR / "examples"
STATIC_DIR = APP_DIR / "static"
OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", "/tmp/rust-map-scout"))
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
MAX_INPUT_BYTES = int(os.getenv("MAX_INPUT_MB", "768")) * 1024 * 1024

app = FastAPI(title="Rust Map Scout", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
ASSET_DIR_TEXT = os.getenv("RUST_ASSET_DIR", "").strip()
ASSET_DIR = Path(ASSET_DIR_TEXT).expanduser() if ASSET_DIR_TEXT else None
if ASSET_DIR is not None and ASSET_DIR.is_dir():
    # Optional, read-only sidecar exports: GLB/glTF/OBJ files can be resolved
    # beside a prefab path by the analyzer. Native .map uploads do not contain
    # Unity mesh bytes themselves.
    app.mount("/rust-assets", StaticFiles(directory=str(ASSET_DIR)), name="rust-assets")


class InputTooLarge(ValueError):
    pass


def _safe_filename(name: str | None) -> str:
    value = Path(name or "map").name
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", value)
    return value[:180] or "map"


def _reject_private_host(hostname: str) -> None:
    lowered = hostname.lower().rstrip(".")
    if lowered in {"localhost", "localhost.localdomain", "ip6-localhost"} or lowered.endswith(".local"):
        raise ValueError("URL host is not allowed")
    try:
        addresses = {info[4][0] for info in socket.getaddrinfo(hostname, None)}
    except socket.gaierror as exc:
        raise ValueError(f"Could not resolve URL host: {exc}") from exc
    for address in addresses:
        ip = ipaddress.ip_address(address)
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified:
            raise ValueError("URL host resolves to a private or reserved address")


async def _download_map(url: str) -> bytes:
    parsed = urlparse(url.strip())
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("Map URL must use http:// or https://")
    _reject_private_host(parsed.hostname)
    headers = {"User-Agent": "RustMapScout/0.1 (+map-analysis)"}
    timeout = httpx.Timeout(60.0, connect=15.0)
    async with httpx.AsyncClient(follow_redirects=True, timeout=timeout, headers=headers) as client:
        async with client.stream("GET", url) as response:
            # Validate redirects too; otherwise a public URL could redirect to
            # a private service inside the container's network.
            for hop in [*response.history, response]:
                if hop.url.host:
                    _reject_private_host(hop.url.host)
            response.raise_for_status()
            content_length = response.headers.get("content-length")
            if content_length and int(content_length) > MAX_INPUT_BYTES:
                raise InputTooLarge("Remote map is larger than the configured upload limit")
            buffer = bytearray()
            async for chunk in response.aiter_bytes(1024 * 1024):
                buffer.extend(chunk)
                if len(buffer) > MAX_INPUT_BYTES:
                    raise InputTooLarge("Remote map is larger than the configured upload limit")
            return bytes(buffer)


def _job_path(job_id: str, suffix: str) -> Path:
    if not re.fullmatch(r"[0-9a-f]{32}", job_id):
        raise HTTPException(status_code=404, detail="Job not found")
    path = OUTPUT_DIR / job_id / suffix
    if not path.exists():
        raise HTTPException(status_code=404, detail="Output not found")
    return path


@app.get("/", include_in_schema=False)
async def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/health")
async def health() -> dict[str, Any]:
    return {"ok": True, "service": "rust-map-scout", "version": app.version}


@app.get("/api/config/default")
async def default_rules() -> JSONResponse:
    return JSONResponse(json.loads(default_config_json()))


@app.get("/demo-map.json", include_in_schema=False)
async def demo_map() -> FileResponse:
    path = EXAMPLES_DIR / "demo-map.json"
    if not path.exists():
        raise HTTPException(status_code=404, detail="Demo map is not installed")
    return FileResponse(path, media_type="application/json", filename="demo-map.json")


@app.post("/api/analyze")
async def analyze(
    map_file: UploadFile | None = File(default=None),
    map_url: str = Form(default=""),
    rules_json: str = Form(default=""),
    height_scale_m: str = Form(default="1000"),
    render_size: str = Form(default="1400"),
) -> JSONResponse:
    if map_file is None and not map_url.strip():
        raise HTTPException(status_code=400, detail="Upload a .map/JSON file or provide a public map URL")

    if map_file is not None:
        try:
            payload = await map_file.read(MAX_INPUT_BYTES + 1)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"Could not read upload: {exc}") from exc
        source_name = _safe_filename(map_file.filename)
        if len(payload) > MAX_INPUT_BYTES:
            raise HTTPException(status_code=413, detail="Uploaded map is larger than the configured limit")
    else:
        try:
            payload = await _download_map(map_url)
        except InputTooLarge as exc:
            raise HTTPException(status_code=413, detail=str(exc)) from exc
        except (ValueError, httpx.HTTPError) as exc:
            raise HTTPException(status_code=400, detail=f"Could not fetch map URL: {exc}") from exc
        source_name = _safe_filename(Path(urlparse(map_url).path).name or "remote-map")

    try:
        # Map decompression/protobuf parsing is CPU-bound for large native maps;
        # keep it out of Uvicorn's event-loop thread.
        document = await run_in_threadpool(parse_map, payload, source_name)
    except MapParseError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    try:
        parsed_height_scale = float(height_scale_m or document.size_y_m or 1000.0)
    except ValueError:
        parsed_height_scale = document.size_y_m or 1000.0
    try:
        output_size = max(700, min(2400, int(float(render_size or 1400))))
    except ValueError:
        output_size = 1400
    try:
        # Terrain sampling, prefab matching, and rule scoring are CPU-bound;
        # run them in Starlette's worker pool so concurrent requests keep the
        # async HTTP loop responsive.
        report = await run_in_threadpool(analyze_document, document, rules_json or None, parsed_height_scale)
    except RuleConfigError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        # Analysis failures should not produce a generic HTML 500 in the UI.
        raise HTTPException(status_code=422, detail=f"Map analysis failed: {exc}") from exc

    job_id = uuid.uuid4().hex
    job_dir = OUTPUT_DIR / job_id
    job_dir.mkdir(parents=True, exist_ok=False)
    image_path = job_dir / "annotated-map.png"
    json_path = job_dir / "report.json"
    csv_path = job_dir / "report.csv"
    geojson_path = job_dir / "markers.geojson"
    source_input_path = job_dir / "source-input"
    bundle_path = job_dir / "rust-map-scout-bundle.zip"
    bundle_notes = (
        "Rust Map Scout analysis bundle\n"
        "=============================\n\n"
        f"Source: {source_name}\n"
        "The PNG is a clean RustEdit-style map backdrop generated from the source map's terrain, ground textures, topology, and paths. Interactive prefab/flat-area overlays live in the web UI and reports.\n"
        "The original source map is not modified. World prefab positions are in the JSON/CSV reports; GeoJSON uses X/Z as point coordinates.\n"
        "For native binary Rust maps, prefab names may require an ID catalog in the submitted rules document.\n"
    ).encode("utf-8")
    report["render"] = {
        "size": output_size,
        "orientation": "flip_y",
        "transform": {
            "sequence": ["native_row_axis_flip_y"],
            "rotate_degrees": 0,
            "mirror_axis": "horizontal",
            "reference": "supplied RustEdit render",
        },
        "normal_map": {
            "enabled": True,
            "source": "heightmap-derived",
            "strength": 1.5,
        },
        "map_rect": {"left": 0, "top": 0, "width": output_size, "height": output_size},
        "map_inset": {"left": 0, "top": 0, "right": 0, "bottom": 0},
    }
    report["flat_areas"] = []
    report["flat_summary"] = None
    try:
        # Keep a private copy for the optional, heavier flat-area pass. It is
        # never included in the public ZIP bundle.
        source_input_path.write_bytes(payload)
        image = await run_in_threadpool(render_annotated_map, document, report, output_size)
        image.save(image_path, format="PNG", optimize=True)
        json_path.write_bytes(report_json(report))
        csv_path.write_bytes(report_csv(report))
        geojson_path.write_bytes(report_geojson(report))
        with zipfile.ZipFile(bundle_path, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
            bundle.writestr("README.txt", bundle_notes)
            bundle.write(image_path, "annotated-map.png")
            bundle.write(json_path, "report.json")
            bundle.write(csv_path, "report.csv")
            bundle.write(geojson_path, "markers.geojson")
    except Exception as exc:
        # Remove partial job directories so failed requests do not accumulate.
        for path in (image_path, json_path, csv_path, geojson_path, source_input_path, bundle_path):
            path.unlink(missing_ok=True)
        job_dir.rmdir()
        raise HTTPException(status_code=422, detail=f"Could not render analysis output: {exc}") from exc

    response = {
        "job_id": job_id,
        "source": report["source"],
        "map": report["map"],
        "render": report["render"],
        "summary": report["summary"],
        "warnings": report["warnings"],
        "markers": report["markers"],
        "flat_areas": report["flat_areas"],
        "flat_summary": report["flat_summary"],
        "map_image_url": f"/api/jobs/{job_id}/map.png",
        "report_json_url": f"/api/jobs/{job_id}/report.json",
        "report_csv_url": f"/api/jobs/{job_id}/report.csv",
        "markers_geojson_url": f"/api/jobs/{job_id}/markers.geojson",
        "bundle_url": f"/api/jobs/{job_id}/bundle.zip",
        "visual_debug_url": f"/api/jobs/{job_id}/visual-debug.zip",
        "flat_search_url": f"/api/jobs/{job_id}/flat-areas",
    }
    return JSONResponse(response)


@app.post("/api/jobs/{job_id}/flat-areas")
async def job_flat_areas(
    job_id: str,
    min_area_m2: str = Form(default=""),
    max_local_deviation_m: str = Form(default=""),
    max_slope_deg: str = Form(default=""),
    min_y_m: str = Form(default=""),
    sample_radius_m: str = Form(default=""),
    max_grid_cells: str = Form(default=""),
    terrain_y_offset_m: str = Form(default=""),
) -> JSONResponse:
    if not re.fullmatch(r"[0-9a-f]{32}", job_id):
        raise HTTPException(status_code=404, detail="Job not found")
    job_dir = OUTPUT_DIR / job_id
    source_path = job_dir / "source-input"
    report_path = job_dir / "report.json"
    if not source_path.exists() or not report_path.exists():
        raise HTTPException(status_code=404, detail="Source map for this job is no longer available")
    try:
        previous_report = json.loads(report_path.read_text("utf-8"))
        source_bytes = source_path.read_bytes()
        document = await run_in_threadpool(
            parse_map,
            source_bytes,
            previous_report.get("source", {}).get("name", "map"),
        )
    except (OSError, MapParseError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=422, detail=f"Could not reload source map for flat-area search: {exc}") from exc

    configured = previous_report.get("rules", {}).get("flat_search", {})
    if not isinstance(configured, dict):
        configured = {}
    settings = dict(configured)
    form_values = {
        "min_area_m2": min_area_m2,
        "max_local_deviation_m": max_local_deviation_m,
        "max_slope_deg": max_slope_deg,
        "min_y_m": min_y_m,
        "sample_radius_m": sample_radius_m,
        "max_grid_cells": max_grid_cells,
        "terrain_y_offset_m": terrain_y_offset_m,
    }
    for key, value in form_values.items():
        if value.strip():
            try:
                settings[key] = int(value) if key == "max_grid_cells" else float(value)
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=f"Flat search setting {key} must be numeric") from exc
    grid = previous_report.get("map", {}).get("grid", {})
    try:
        grid_cell = float(grid.get("cell_size_m", 150.0))
    except (TypeError, ValueError):
        grid_cell = 150.0
    numbering = str(grid.get("numbering", "zero_based"))
    height_scale = float(previous_report.get("map", {}).get("height_scale_m", document.size_y_m or 1000.0))
    try:
        result = await run_in_threadpool(find_flat_areas, document, height_scale, settings, grid_cell, numbering)
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Flat-area search failed: {exc}") from exc

    previous_report["flat_areas"] = result["areas"]
    previous_report["flat_summary"] = result["summary"]
    previous_report["flat_warnings"] = result["warnings"]
    previous_report["warnings"] = list(dict.fromkeys(previous_report.get("warnings", []) + result["warnings"]))
    output_size = int(previous_report.get("render", {}).get("size", 1400))
    image_path = job_dir / "annotated-map.png"
    json_path = job_dir / "report.json"
    csv_path = job_dir / "report.csv"
    geojson_path = job_dir / "markers.geojson"
    flat_geojson_path = job_dir / "flat-areas.geojson"
    bundle_path = job_dir / "rust-map-scout-bundle.zip"
    try:
        image = await run_in_threadpool(render_annotated_map, document, previous_report, output_size)
        image.save(image_path, format="PNG", optimize=True)
        json_path.write_bytes(report_json(previous_report))
        csv_path.write_bytes(report_csv(previous_report))
        geojson_path.write_bytes(report_geojson(previous_report))
        flat_geojson_path.write_bytes(flat_areas_geojson(result["areas"]))
        with zipfile.ZipFile(bundle_path, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
            bundle.writestr("README.txt", "Rust Map Scout analysis bundle\\nThe source map is unchanged. Flat build areas are heuristic, downsampled analysis results.\\n")
            bundle.write(image_path, "annotated-map.png")
            bundle.write(json_path, "report.json")
            bundle.write(csv_path, "report.csv")
            bundle.write(geojson_path, "markers.geojson")
            bundle.write(flat_geojson_path, "flat-areas.geojson")
    except OSError as exc:
        raise HTTPException(status_code=422, detail=f"Could not save flat-area output: {exc}") from exc
    return JSONResponse(
        {
            "job_id": job_id,
            "flat_areas": result["areas"],
            "flat_summary": result["summary"],
            "warnings": previous_report["warnings"],
            "map_image_url": f"/api/jobs/{job_id}/map.png",
            "report_json_url": f"/api/jobs/{job_id}/report.json",
            "flat_areas_geojson_url": f"/api/jobs/{job_id}/flat-areas.geojson",
            "bundle_url": f"/api/jobs/{job_id}/bundle.zip",
        }
    )


@app.get("/api/jobs/{job_id}/visual-debug.zip")
async def job_visual_debug(job_id: str) -> FileResponse:
    """Create a compact decoded-layer bundle without returning the source map."""
    if not re.fullmatch(r"[0-9a-f]{32}", job_id):
        raise HTTPException(status_code=404, detail="Job not found")
    job_dir = OUTPUT_DIR / job_id
    source_path = job_dir / "source-input"
    report_path = job_dir / "report.json"
    output_path = job_dir / "visual-debug.zip"
    if not source_path.exists() or not report_path.exists():
        raise HTTPException(status_code=404, detail="Source map for this job is no longer available")
    if not output_path.exists():
        try:
            previous_report = json.loads(report_path.read_text("utf-8"))
            source_bytes = source_path.read_bytes()
            document = await run_in_threadpool(
                parse_map,
                source_bytes,
                previous_report.get("source", {}).get("name", "map"),
            )
            temporary_path = job_dir / f".visual-debug-{uuid.uuid4().hex}.tmp"
            await run_in_threadpool(build_visual_debug_bundle, document, previous_report, temporary_path)
            temporary_path.replace(output_path)
        except (OSError, MapParseError, json.JSONDecodeError) as exc:
            raise HTTPException(status_code=422, detail=f"Could not build visual-layer diagnostics: {exc}") from exc
        except Exception as exc:
            raise HTTPException(status_code=422, detail=f"Could not build visual-layer diagnostics: {exc}") from exc
    return FileResponse(output_path, media_type="application/zip", filename="rust-map-scout-visual-debug.zip")


@app.get("/api/jobs/{job_id}/map.png")
async def job_map(job_id: str) -> FileResponse:
    return FileResponse(_job_path(job_id, "annotated-map.png"), media_type="image/png", filename="rust-map-scout-annotated.png")


@app.get("/api/jobs/{job_id}/report.json")
async def job_report_json(job_id: str) -> FileResponse:
    return FileResponse(_job_path(job_id, "report.json"), media_type="application/json", filename="rust-map-scout-report.json")


@app.get("/api/jobs/{job_id}/report.csv")
async def job_report_csv(job_id: str) -> FileResponse:
    return FileResponse(_job_path(job_id, "report.csv"), media_type="text/csv", filename="rust-map-scout-report.csv")


@app.get("/api/jobs/{job_id}/markers.geojson")
async def job_markers_geojson(job_id: str) -> FileResponse:
    return FileResponse(_job_path(job_id, "markers.geojson"), media_type="application/geo+json", filename="rust-map-scout-markers.geojson")


@app.get("/api/jobs/{job_id}/flat-areas.geojson")
async def job_flat_areas_geojson(job_id: str) -> FileResponse:
    return FileResponse(_job_path(job_id, "flat-areas.geojson"), media_type="application/geo+json", filename="rust-map-scout-flat-areas.geojson")


@app.get("/api/jobs/{job_id}/bundle.zip")
async def job_bundle(job_id: str) -> FileResponse:
    return FileResponse(_job_path(job_id, "rust-map-scout-bundle.zip"), media_type="application/zip", filename="rust-map-scout-bundle.zip")
