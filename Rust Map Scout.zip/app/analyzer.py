"""Prefab matching and terrain/proximity analysis for Rust maps."""

from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import os
import re
from collections import Counter, deque
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any
from urllib.parse import quote

import numpy as np

try:  # Optional compiled acceleration for large flat-area searches.
    from scipy import ndimage as _ndimage
except ImportError:  # pragma: no cover - minimal installations use the fallback
    _ndimage = None

from .map_parser import MapDocument, PrefabInstance, decode_biome, decode_heightmap, decode_splat, decode_topology


CATEGORY_PREVIEWS: dict[str, str] = {
    "god_rock": "/static/prefab-previews/god-rock.svg",
    "ice_lake": "/static/prefab-previews/ice-lake.svg",
    "cave": "/static/prefab-previews/cave.svg",
    "rock": "/static/prefab-previews/god-rock.svg",
}
GENERIC_CATEGORY_PREVIEW = "/static/prefab-previews/generic.svg"


TOPOLOGY_BITS: dict[str, int] = {
    "Field": 1 << 0,
    "Cliff": 1 << 1,
    "Summit": 1 << 2,
    "Beachside": 1 << 3,
    "Beach": 1 << 4,
    "Forest": 1 << 5,
    "Forestside": 1 << 6,
    "Ocean": 1 << 7,
    "Oceanside": 1 << 8,
    "Decor": 1 << 9,
    "Monument": 1 << 10,
    "Road": 1 << 11,
    "Roadside": 1 << 12,
    "Swamp": 1 << 13,
    "River": 1 << 14,
    "Riverside": 1 << 15,
    "Lake": 1 << 16,
    "Lakeside": 1 << 17,
    "Offshore": 1 << 18,
    "Powerline": 1 << 19,
    "Runway": 1 << 20,
    "Building": 1 << 21,
    "Cliffside": 1 << 22,
    "Mountain": 1 << 23,
    "Clutter": 1 << 24,
    "Alt": 1 << 25,
    "Tier0": 1 << 26,
    "Tier1": 1 << 27,
    "Tier2": 1 << 28,
    "Mainland": 1 << 29,
    "Hilltop": 1 << 30,
}

DEFAULT_CONFIG: dict[str, Any] = {
    "version": 1,
    "catalog": {},
    "grid": {"cell_size_m": 150, "numbering": "zero_based"},
    "flat_search": {
        "min_area_m2": 900,
        "max_local_deviation_m": 6,
        "max_slope_deg": 5,
        "min_y_m": -1,
        "sample_radius_m": 15,
        "max_grid_cells": 700,
        "exclude_topology": ["Ocean", "River", "Lake", "Cliff"],
    },
    "rules": [
        {
            "id": "god-rock",
            "label": "God Rock",
            "kind": "god_rock",
            "paths": [
                "assets/bundled/prefabs/autospawn/decor/v3_rock_formations_large/rock_formation_a.prefab",
                "assets/bundled/prefabs/autospawn/decor/v3_rock_formations_large/rock_formation_e.prefab",
                "assets/bundled/prefabs/autospawn/decor/v3_rock_formations_large/rock_formation_f.prefab",
            ],
            "patterns": [],
            "ids": [291142845],
            "analyze_slope": True,
            "slope_radius_m": 24,
            # The God Rock footprint is roughly 69 × 63 m. A 40 m radius
            # gives the visual sample an 80 × 80 m north-up window with a
            # little margin around the measured formation.
            "topology_radius_m": 40,
            # Align the heatmap cells with an approximately 3 m foundation.
            "topology_grid_size": 27,
            "foundation_footprint_m": 3.0,
            "foundation_height_step_m": 1.25,
            "color": "#f3b562",
            "preview_url": "/static/prefab-previews/god-rock.svg",
        },
        {
            "id": "ice-lake",
            "label": "Ice lake",
            "kind": "ice_lake",
            "paths": [
                "assets/bundled/prefabs/autospawn/monument/ice_lakes/ice_lake_1.prefab",
                "assets/bundled/prefabs/autospawn/monument/ice_lakes/ice_lake_2.prefab",
                "assets/bundled/prefabs/autospawn/monument/ice_lakes/ice_lake_3.prefab",
                "assets/bundled/prefabs/autospawn/monument/ice_lakes/ice_lake_4.prefab",
                "assets/content/nature/ice_lakes/models/ice_lake_a.prefab",
                "assets/content/nature/ice_lakes/models/ice_lake_b.prefab",
                "assets/content/nature/ice_lakes/models/ice_lake_c.prefab",
                "assets/content/nature/ice_lakes/models/ice_lake_d.prefab",
            ],
            "patterns": [],
            "ids": [],
            "building_blocked_suffixes": ["1", "2", "3", "4"],
            "building_clear_suffixes": ["a", "b", "c", "d"],
            "analyze_topology": True,
            "topology_radius_m": 120,
            "proximity_radius_m": 120,
            "center_tolerance_m": 18,
            "color": "#79d7e8",
            "preview_url": "/static/prefab-previews/ice-lake.svg",
        },
        {
            "id": "cave",
            "label": "Cave",
            "kind": "cave",
            "paths": [
                "assets/bundled/prefabs/autospawn/monument/cave/cave_small_easy.prefab",
                "assets/bundled/prefabs/autospawn/monument/cave/cave_small_medium.prefab",
                "assets/bundled/prefabs/autospawn/monument/cave/cave_small_hard.prefab",
                "assets/bundled/prefabs/autospawn/monument/cave/cave_medium_medium.prefab",
                "assets/bundled/prefabs/autospawn/monument/cave/cave_medium_easy.prefab",
                "assets/bundled/prefabs/autospawn/monument/cave/cave_medium_hard.prefab",
                "assets/bundled/prefabs/autospawn/monument/cave/cave_hard_hard.prefab",
                "assets/bundled/prefabs/autospawn/monument/cave/cave_hard_medium.prefab",
                "assets/bundled/prefabs/autospawn/monument/cave/cave_large_sewers_hard.prefab",
            ],
            "patterns": [],
            "ids": [],
            "analyze_topology": True,
            "topology_radius_m": 30,
            "color": "#bd9bef",
            "preview_url": "/static/prefab-previews/cave.svg",
        },
    ],
}


class RuleConfigError(ValueError):
    """Raised for an invalid rules document."""


def prefab_id_for_path(path: str) -> int:
    """Return Rust's uint prefab ID for an asset path.

    Rust's published map examples identify prefab IDs as the little-endian
    first four bytes of the MD5 digest of the full asset path. This also lets
    the starter rules work on native maps without requiring a separate catalog.
    """
    digest = hashlib.md5(_norm_name(path).encode("utf-8"), usedforsecurity=False).digest()
    return int.from_bytes(digest[:4], "little", signed=False)


def _json_or_yaml(text: str) -> Any:
    text = (text or "").strip()
    if not text:
        return DEFAULT_CONFIG
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        try:
            import yaml  # type: ignore

            return yaml.safe_load(text)
        except Exception as exc:  # pragma: no cover - optional YAML path
            raise RuleConfigError(f"Rules must be valid JSON or YAML: {exc}") from exc


def normalize_config(config: str | dict[str, Any] | list[Any] | None) -> dict[str, Any]:
    if config is None or config == "":
        config_obj: Any = DEFAULT_CONFIG
    elif isinstance(config, str):
        config_obj = _json_or_yaml(config)
    else:
        config_obj = config
    if isinstance(config_obj, list):
        config_obj = {"rules": config_obj}
    if not isinstance(config_obj, dict):
        raise RuleConfigError("Rules document must be an object or a list of rules")
    rules = config_obj.get("rules", config_obj.get("prefab_rules", []))
    if not isinstance(rules, list):
        raise RuleConfigError("rules must be a list")
    catalog = config_obj.get("catalog", config_obj.get("prefab_catalog", {}))
    if isinstance(catalog, list):
        catalog_entries: dict[str, Any] = {}
        for entry in catalog:
            if not isinstance(entry, dict) or entry.get("id") is None:
                continue
            value = dict(entry)
            value.pop("id", None)
            catalog_entries[str(entry["id"])] = value if len(value) > 1 or any(k in value for k in ("model_url", "preview_url", "asset_path")) else value.get("name", value.get("path", ""))
        catalog = catalog_entries
    if not isinstance(catalog, dict):
        raise RuleConfigError("catalog must be an object or list")
    normalized_rules: list[dict[str, Any]] = []
    for i, raw in enumerate(rules):
        if not isinstance(raw, dict):
            raise RuleConfigError(f"rule {i + 1} must be an object")
        rid = str(raw.get("id", raw.get("name", f"rule-{i + 1}")))
        label = str(raw.get("label", raw.get("name", rid)))
        patterns = raw.get("patterns", raw.get("contains", []))
        if isinstance(patterns, str):
            patterns = [patterns]
        paths = raw.get("paths", raw.get("prefab_paths", []))
        if isinstance(paths, str):
            paths = [paths]
        ids = raw.get("ids", raw.get("prefab_ids", []))
        if isinstance(ids, (str, int)):
            ids = [ids]
        normalized_paths = [_norm_name(str(p)) for p in (paths or []) if str(p).strip()]
        explicit_ids = [str(v) for v in (ids or [])]
        generated_ids = [str(prefab_id_for_path(path)) for path in normalized_paths]
        normalized = dict(raw)
        normalized.update(
            {
                "id": rid,
                "label": label,
                "kind": str(raw.get("kind", rid)),
                "patterns": [_norm_name(str(p)) for p in (patterns or []) if str(p).strip()],
                "paths": normalized_paths,
                # Path-derived IDs are included automatically for native Rust
                # maps, whose PrefabData has only the uint ID.
                "ids": list(dict.fromkeys(explicit_ids + generated_ids)),
                "generated_ids": generated_ids,
                "categories": [str(v).lower() for v in (raw.get("categories", []) if isinstance(raw.get("categories", []), list) else [raw.get("categories")]) if v is not None],
                "color": str(raw.get("color", "#e6edf3")),
            }
        )
        normalized_rules.append(normalized)
    grid = config_obj.get("grid", {})
    if not isinstance(grid, dict):
        grid = {}
    try:
        grid_cell_size = float(grid.get("cell_size_m", 150))
    except (TypeError, ValueError):
        grid_cell_size = 150.0
    if not math.isfinite(grid_cell_size) or grid_cell_size <= 0:
        grid_cell_size = 150.0
    numbering = str(grid.get("numbering", "zero_based")).lower()
    if numbering not in {"zero_based", "one_based"}:
        numbering = "zero_based"
    flat_search = config_obj.get("flat_search", {})
    if not isinstance(flat_search, dict):
        flat_search = {}
    return {
        "version": config_obj.get("version", 1),
        "catalog": {str(k): v for k, v in catalog.items()},
        "grid": {"cell_size_m": grid_cell_size, "numbering": numbering},
        "flat_search": flat_search,
        "rules": normalized_rules,
    }


def default_config_json() -> str:
    # Expose the path-derived uint IDs in the starter document so users can
    # inspect or copy them when working with native binary maps.
    return json.dumps(normalize_config(DEFAULT_CONFIG), indent=2)


def _catalog_info(prefab: PrefabInstance, catalog: dict[str, Any]) -> dict[str, Any]:
    if prefab.prefab_id is None:
        return {}
    value = catalog.get(str(prefab.prefab_id))
    return value if isinstance(value, dict) else {"name": value}


def _catalog_name(prefab: PrefabInstance, catalog: dict[str, Any]) -> str:
    if prefab.name:
        return prefab.name
    info = _catalog_info(prefab, catalog)
    return str(info.get("name", info.get("path", info.get("prefab", ""))) or "")


def _catalog_preview(prefab: PrefabInstance, catalog: dict[str, Any]) -> str:
    info = _catalog_info(prefab, catalog)
    return str(info.get("preview_url", info.get("preview", info.get("thumbnail", ""))) or "")


def _catalog_model(prefab: PrefabInstance, catalog: dict[str, Any]) -> tuple[str, str, str]:
    """Return an optional extracted model URL, format, and source asset path.

    The native .map has no mesh bytes, so these values are deliberately
    opt-in catalog/interchange metadata. This keeps native analysis useful
    while allowing a mounted/exported Rust asset pipeline to provide GLB,
    glTF, or OBJ models without changing the map parser.
    """
    info = _catalog_info(prefab, catalog)
    model_url = str(info.get("model_url", info.get("model", info.get("mesh_url", info.get("mesh", "")))) or "")
    model_format = str(info.get("model_format", info.get("format", "")) or "")
    asset_path = str(info.get("asset_path", info.get("asset", "")) or "")
    if not model_format and model_url:
        model_format = model_url.rsplit("?", 1)[0].rsplit(".", 1)[-1].lower() if "." in model_url.rsplit("?", 1)[0] else ""
    return model_url, model_format, asset_path


@lru_cache(maxsize=1024)
def _mounted_model_asset(asset_path: str) -> tuple[str, str, str]:
    """Resolve an exported model beside a Rust prefab when assets are mounted.

    A native .map contains the prefab reference but not Unity mesh bytes. If a
    deployment mounts ``RUST_ASSET_DIR`` with a legally obtained export, this
    accepts common sidecar GLB/glTF/OBJ files and exposes only the relative
    static URL. Unity AssetBundles still need an external conversion step;
    silently pretending that a prefab text reference is a mesh would be worse.
    """
    root_text = os.getenv("RUST_ASSET_DIR", "").strip()
    raw_path = str(asset_path or "").replace("\\", "/").lstrip("/")
    if not root_text or not raw_path:
        return "", "", ""
    root = Path(root_text).expanduser()
    try:
        root = root.resolve()
    except OSError:
        return "", "", ""
    supported = (".glb", ".gltf", ".obj")
    raw = Path(raw_path)
    candidates: list[Path] = []
    if raw.suffix.lower() in supported:
        candidates.append(root / raw)
    else:
        candidates.extend(root / raw.with_suffix(ext) for ext in supported)
        if raw.suffix.lower() == ".prefab":
            stem = raw.with_suffix("")
            candidates.extend(root / Path(f"{stem}_model{ext}") for ext in supported)
    seen: set[Path] = set()
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
            if resolved in seen or not resolved.is_relative_to(root) or not resolved.is_file():
                continue
            seen.add(resolved)
            relative = resolved.relative_to(root).as_posix()
            model_format = resolved.suffix.lower().lstrip(".")
            return f"/rust-assets/{quote(relative, safe='/:@-._~')}", model_format, relative
        except OSError:
            continue
    return "", "", ""


def _norm_name(name: str) -> str:
    return name.lower().replace("\\", "/")


def prefab_short_name(name: str) -> str:
    """Return the compact prefab name used in marker popups and tables."""
    normalized = _norm_name(name).rstrip("/")
    if not normalized:
        return "unknown prefab"
    short = normalized.rsplit("/", 1)[-1]
    if short.endswith(".prefab"):
        short = short[:-7]
    return short or "unknown prefab"


def _column_name(index: int) -> str:
    """Excel-style letters: 0 -> A, 25 -> Z, 26 -> AA."""
    if index < 0:
        return "?"
    result = ""
    number = index + 1
    while number:
        number, remainder = divmod(number - 1, 26)
        result = chr(65 + remainder) + result
    return result


def grid_reference(
    doc: MapDocument,
    x: float,
    z: float,
    cell_size_m: float = 150.0,
    numbering: str = "zero_based",
) -> dict[str, Any]:
    """Calculate the Rust-style horizontal letter / vertical number cell."""
    origin_x, origin_z = doc.origin
    column = math.floor((x - origin_x) / cell_size_m)
    row_from_north = math.floor((origin_z + doc.size_m - z) / cell_size_m)
    if numbering == "one_based":
        row = row_from_north + 1
    else:
        row = row_from_north
    return {
        "reference": f"{_column_name(column)}{row}",
        "column": int(column),
        "row": int(row),
        "cell_size_m": float(cell_size_m),
        "numbering": numbering,
    }


def _matches(prefab: PrefabInstance, rule: dict[str, Any], resolved_name: str) -> bool:
    prefab_id = str(prefab.prefab_id) if prefab.prefab_id is not None else ""
    ids = set(rule.get("ids", []))
    if prefab_id and prefab_id in ids:
        return True
    categories = set(rule.get("categories", []))
    if categories and prefab.category.lower() not in categories:
        return False
    haystack = _norm_name(resolved_name)
    paths = rule.get("paths", [])
    if any(haystack == path or haystack.endswith("/" + path) for path in paths):
        return True
    patterns = rule.get("patterns", [])
    if any(pattern in haystack for pattern in patterns):
        return True
    regexes = rule.get("regex", rule.get("regexes", []))
    if isinstance(regexes, str):
        regexes = [regexes]
    for expression in regexes or []:
        try:
            if re.search(str(expression), resolved_name, flags=re.IGNORECASE):
                return True
        except re.error:
            continue
    return False


def _pixel_for(doc: MapDocument, x: float, z: float, resolution: int) -> tuple[float, float, bool]:
    origin_x, origin_z = doc.origin
    px = (x - origin_x) / doc.size_m * (resolution - 1)
    pz = (z - origin_z) / doc.size_m * (resolution - 1)
    return px, pz, 0.0 <= px <= resolution - 1 and 0.0 <= pz <= resolution - 1


def _pixel_distance_to_world(doc: MapDocument, resolution: int) -> float:
    return doc.size_m / max(1, resolution - 1)


def _disk_values(array: np.ndarray, px: float, pz: float, radius_px: float) -> np.ndarray:
    if array is None or array.size == 0:
        return np.asarray([], dtype=np.float32)
    if radius_px <= 0.5:
        x = int(round(px))
        z = int(round(pz))
        if 0 <= z < array.shape[0] and 0 <= x < array.shape[1]:
            return np.asarray([array[z, x]])
        return np.asarray([], dtype=array.dtype)
    x0 = max(0, int(math.floor(px - radius_px)))
    x1 = min(array.shape[1] - 1, int(math.ceil(px + radius_px)))
    z0 = max(0, int(math.floor(pz - radius_px)))
    z1 = min(array.shape[0] - 1, int(math.ceil(pz + radius_px)))
    if x0 > x1 or z0 > z1:
        return np.asarray([], dtype=array.dtype)
    yy, xx = np.ogrid[z0 : z1 + 1, x0 : x1 + 1]
    mask = (xx - px) ** 2 + (yy - pz) ** 2 <= radius_px**2
    return array[z0 : z1 + 1, x0 : x1 + 1][mask]


TOPOLOGY_VISUAL_PRIORITY = [
    "Ocean", "Offshore", "Lake", "River", "Cliff", "Road", "Runway",
    "Beach", "Beachside", "Forest", "Forestside", "Field", "Hilltop",
    "Summit", "Mountain", "Swamp", "Building", "Monument", "Decor", "None",
]


def _topology_visual_grid(
    topology: np.ndarray,
    px: float,
    pz: float,
    radius_px: float,
    radius_m: float | None,
    height: np.ndarray | None = None,
    height_scale_m: float | None = None,
    grid_size: int = 27,
    foundation_size_m: float = 3.0,
    foundation_step_m: float = 1.25,
) -> dict[str, Any]:
    """Return topology labels plus mean terrain-Y values for each sample cell."""
    grid_size = max(9, min(int(grid_size), 31))
    half_width = max(1.0, float(radius_px) * 2.0)
    x0 = max(0, int(math.floor(px - radius_px)))
    x1 = min(topology.shape[1], int(math.ceil(px + radius_px)) + 1)
    z0 = max(0, int(math.floor(pz - radius_px)))
    z1 = min(topology.shape[0], int(math.ceil(pz + radius_px)) + 1)
    cells: list[list[str | None]] = []
    heights: list[list[float | None]] = []
    sampled_heights: list[float] = []
    priority = {name: index for index, name in enumerate(TOPOLOGY_VISUAL_PRIORITY)}
    height_scale = float(height_scale_m or 1.0)
    topology_height_ratio_x = (height.shape[1] - 1) / max(1, topology.shape[1] - 1) if height is not None else 1.0
    topology_height_ratio_z = (height.shape[0] - 1) / max(1, topology.shape[0] - 1) if height is not None else 1.0
    for row in range(grid_size):
        cell_row: list[str | None] = []
        height_row: list[float | None] = []
        for column in range(grid_size):
            local_x = -radius_px + (column + 0.5) * half_width / grid_size
            local_z = -radius_px + (row + 0.5) * half_width / grid_size
            if local_x * local_x + local_z * local_z > radius_px * radius_px * 1.08:
                cell_row.append(None)
                height_row.append(None)
                continue
            block_x0 = max(x0, min(x1 - 1, int(math.floor(x0 + column * (x1 - x0) / grid_size))))
            block_x1 = max(block_x0 + 1, min(x1, int(math.ceil(x0 + (column + 1) * (x1 - x0) / grid_size))))
            block_z0 = max(z0, min(z1 - 1, int(math.floor(z0 + row * (z1 - z0) / grid_size))))
            block_z1 = max(block_z0 + 1, min(z1, int(math.ceil(z0 + (row + 1) * (z1 - z0) / grid_size))))
            values = topology[block_z0:block_z1, block_x0:block_x1].astype(np.int64, copy=False).ravel()
            counts: Counter[str] = Counter()
            for name, bit in TOPOLOGY_BITS.items():
                count = int(np.count_nonzero((values & bit) != 0))
                if count:
                    counts[name] = count
            if counts:
                label = min(counts, key=lambda name: (-counts[name], priority.get(name, 999)))
            else:
                label = "None"
            cell_row.append(label)
            if height is not None:
                height_x0 = max(0, int(math.floor(block_x0 * topology_height_ratio_x)))
                height_x1 = min(height.shape[1], max(height_x0 + 1, int(math.ceil(block_x1 * topology_height_ratio_x))))
                height_z0 = max(0, int(math.floor(block_z0 * topology_height_ratio_z)))
                height_z1 = min(height.shape[0], max(height_z0 + 1, int(math.ceil(block_z1 * topology_height_ratio_z))))
                height_values = height[height_z0:height_z1, height_x0:height_x1].astype(np.float32, copy=False)
                y_value = float(np.mean(height_values) * height_scale) if height_values.size else None
            else:
                y_value = None
            height_row.append(round(y_value, 2) if y_value is not None else None)
            if y_value is not None and math.isfinite(y_value):
                sampled_heights.append(y_value)
        cells.append(cell_row)
        heights.append(height_row)

    # Derive a per-cell terrain angle from the sampled Y grid. The display
    # uses this field as the green-to-red heatmap: flat cells are green and
    # steep cells are red. Missing cells outside the circular sample remain
    # null so they are not treated as flat terrain.
    slope_grid: list[list[float | None]] = [[None for _ in range(grid_size)] for _ in range(grid_size)]
    sampled_slopes: list[float] = []
    sample_cell_m = float(radius_m) * 2.0 / grid_size if radius_m is not None else None
    if sample_cell_m and sample_cell_m > 0 and sampled_heights:
        y_grid = np.full((grid_size, grid_size), np.nan, dtype=np.float32)
        for row_index, row in enumerate(heights):
            for column_index, value in enumerate(row):
                if value is not None and math.isfinite(float(value)):
                    y_grid[row_index, column_index] = float(value)

        def gradient_at(row_index: int, column_index: int, axis: int) -> float:
            current = y_grid[row_index, column_index]
            if not math.isfinite(float(current)):
                return 0.0
            if axis == 0:
                negative = y_grid[row_index - 1, column_index] if row_index > 0 else np.nan
                positive = y_grid[row_index + 1, column_index] if row_index + 1 < grid_size else np.nan
            else:
                negative = y_grid[row_index, column_index - 1] if column_index > 0 else np.nan
                positive = y_grid[row_index, column_index + 1] if column_index + 1 < grid_size else np.nan
            if math.isfinite(float(negative)) and math.isfinite(float(positive)):
                return float(positive - negative) / (2.0 * sample_cell_m)
            if math.isfinite(float(positive)):
                return float(positive - current) / sample_cell_m
            if math.isfinite(float(negative)):
                return float(current - negative) / sample_cell_m
            return 0.0

        for row_index in range(grid_size):
            for column_index in range(grid_size):
                if not math.isfinite(float(y_grid[row_index, column_index])):
                    continue
                gradient_x = gradient_at(row_index, column_index, 1)
                gradient_z = gradient_at(row_index, column_index, 0)
                slope_degrees = math.degrees(math.atan(math.hypot(gradient_x, gradient_z)))
                slope_grid[row_index][column_index] = round(slope_degrees, 2)
                sampled_slopes.append(slope_degrees)

    foundation_size = max(0.1, float(foundation_size_m or 3.0))
    foundation_step = max(0.01, float(foundation_step_m or 1.25))
    foundation_rise_grid: list[list[float | None]] = [[None for _ in range(grid_size)] for _ in range(grid_size)]
    sampled_foundation_rises: list[float] = []
    for row_index, row in enumerate(slope_grid):
        for column_index, slope_value in enumerate(row):
            if slope_value is None:
                continue
            rise = math.tan(math.radians(float(slope_value))) * foundation_size
            foundation_rise_grid[row_index][column_index] = round(float(rise), 2)
            sampled_foundation_rises.append(float(rise))

    result: dict[str, Any] = {
        "size": grid_size,
        "radius_m": float(radius_m) if radius_m is not None else None,
        "cell_m": round(float(radius_m) * 2.0 / grid_size, 3) if radius_m is not None else None,
        "center": grid_size // 2,
        "orientation": "north_up",
        "axis_labels": {"top": "North", "bottom": "South", "left": "West", "right": "East"},
        "bounds_m": {
            "north": float(radius_m) if radius_m is not None else None,
            "south": float(radius_m) if radius_m is not None else None,
            "west": float(radius_m) if radius_m is not None else None,
            "east": float(radius_m) if radius_m is not None else None,
        },
        "cells": cells,
        "heights_m": heights,
        "slope_deg": slope_grid,
        "rise_per_foundation_m": foundation_rise_grid,
        "foundation_reference": {
            "footprint_m": round(foundation_size, 2),
            "height_step_m": round(foundation_step, 2),
            "step_slope_deg": round(math.degrees(math.atan(foundation_step / foundation_size)), 2),
        },
    }
    if sampled_heights:
        result["height_min_m"] = round(float(min(sampled_heights)), 2)
        result["height_max_m"] = round(float(max(sampled_heights)), 2)
        center_height = heights[grid_size // 2][grid_size // 2]
        result["center_height_m"] = center_height
    if sampled_slopes:
        result["slope_min_deg"] = round(float(min(sampled_slopes)), 2)
        result["slope_max_deg"] = round(float(max(sampled_slopes)), 2)
        result["slope_mean_deg"] = round(float(np.mean(sampled_slopes)), 2)
    if sampled_foundation_rises:
        result["rise_min_m"] = round(float(min(sampled_foundation_rises)), 2)
        result["rise_max_m"] = round(float(max(sampled_foundation_rises)), 2)
        result["rise_mean_m"] = round(float(np.mean(sampled_foundation_rises)), 2)
    return result


def _topology_summary(
    topology: np.ndarray | None,
    px: float,
    pz: float,
    radius_px: float,
    radius_m: float | None = None,
    height: np.ndarray | None = None,
    height_scale_m: float | None = None,
    include_visual_grid: bool = False,
    visual_grid_size: int = 27,
    foundation_size_m: float = 3.0,
    foundation_step_m: float = 1.25,
) -> dict[str, Any] | None:
    if topology is None:
        return None
    values = _disk_values(topology, px, pz, radius_px).astype(np.int64, copy=False)
    if values.size == 0:
        return {"sample_count": 0, "flags": [], "coverage_percent": {}, "radius_m": radius_m}
    counts: Counter[str] = Counter()
    for name, bit in TOPOLOGY_BITS.items():
        count = int(np.count_nonzero((values & bit) != 0))
        if count:
            counts[name] = count
    unknown = int(np.count_nonzero(values & ~sum(TOPOLOGY_BITS.values())))
    coverage = {name: round(count / values.size * 100.0, 2) for name, count in counts.most_common()}
    dominant = counts.most_common(1)[0][0] if counts else None
    center_x = int(round(px))
    center_z = int(round(pz))
    center_value = int(topology[center_z, center_x]) if 0 <= center_z < topology.shape[0] and 0 <= center_x < topology.shape[1] else 0
    center_flags = [name for name, bit in TOPOLOGY_BITS.items() if center_value & bit]
    result = {
        "sample_count": int(values.size),
        "flags": [name for name, _ in counts.most_common()],
        "coverage_percent": coverage,
        "dominant": dominant,
        "unknown_bit_samples": unknown,
        "center_flags_approx": center_flags,
    }
    if include_visual_grid:
        result["sample_grid"] = _topology_visual_grid(
            topology,
            px,
            pz,
            radius_px,
            radius_m,
            height=height,
            height_scale_m=height_scale_m,
            grid_size=visual_grid_size,
            foundation_size_m=foundation_size_m,
            foundation_step_m=foundation_step_m,
        )
    if radius_m is not None:
        result["radius_m"] = float(radius_m)
    return result


def _slope_summary(
    height: np.ndarray | None,
    px: float,
    pz: float,
    radius_m: float,
    doc: MapDocument,
    height_scale_m: float,
    prefab_y_m: float | None = None,
) -> dict[str, Any] | None:
    if height is None:
        return None
    resolution = height.shape[0]
    cell_m = _pixel_distance_to_world(doc, resolution)
    height_m = height.astype(np.float32) * float(height_scale_m)
    # np.gradient's first array axis is the map's z/row direction.
    dz_dz, dz_dx = np.gradient(height_m, cell_m, cell_m)
    angle = np.degrees(np.arctan(np.hypot(dz_dx, dz_dz))).astype(np.float32)
    neighborhood_radius_px = max(0.5, radius_m / cell_m)
    values = _disk_values(angle, px, pz, neighborhood_radius_px)
    values = values[np.isfinite(values)]
    neighborhood_y_values = _disk_values(height_m, px, pz, neighborhood_radius_px)
    neighborhood_y_values = neighborhood_y_values[np.isfinite(neighborhood_y_values)]
    center_values = _disk_values(angle, px, pz, 0.5)
    if values.size == 0:
        return {"sample_count": 0, "radius_m": radius_m}
    terrain_values = _disk_values(height_m, px, pz, 0.5)
    center_angle = float(center_values[0]) if center_values.size else None
    terrain_elevation = float(terrain_values[0]) if terrain_values.size else None
    summary = {
        "radius_m": float(radius_m),
        "sample_count": int(values.size),
        "center_angle_deg": round(center_angle, 2) if center_angle is not None else None,
        "mean_angle_deg": round(float(np.mean(values)), 2),
        "median_angle_deg": round(float(np.median(values)), 2),
        "p90_angle_deg": round(float(np.percentile(values, 90)), 2),
        "max_angle_deg": round(float(np.max(values)), 2),
        "terrain_elevation_m": round(terrain_elevation, 2) if terrain_elevation is not None else None,
        "surrounding_y_min_m": round(float(np.min(neighborhood_y_values)), 2) if neighborhood_y_values.size else None,
        "surrounding_y_max_m": round(float(np.max(neighborhood_y_values)), 2) if neighborhood_y_values.size else None,
        "surrounding_y_mean_m": round(float(np.mean(neighborhood_y_values)), 2) if neighborhood_y_values.size else None,
        "surrounding_y_std_m": round(float(np.std(neighborhood_y_values)), 2) if neighborhood_y_values.size else None,
        "surrounding_y_range_m": round(float(np.max(neighborhood_y_values) - np.min(neighborhood_y_values)), 2) if neighborhood_y_values.size else None,
        "height_scale_m": float(height_scale_m),
    }
    if prefab_y_m is not None:
        summary["prefab_y_m"] = round(float(prefab_y_m), 2)
        if terrain_elevation is not None:
            summary["vertical_delta_m"] = round(float(prefab_y_m - terrain_elevation), 2)
            summary["vertical_delta_abs_m"] = round(abs(float(prefab_y_m - terrain_elevation)), 2)
    return summary


def _safe_color(value: Any) -> str:
    color = str(value or "#e6edf3")
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", color):
        return "#e6edf3"
    return color


def _box_mean(array: np.ndarray, radius_px: int) -> np.ndarray:
    if radius_px <= 0:
        return array.astype(np.float32, copy=False)
    padded = np.pad(array.astype(np.float64, copy=False), ((radius_px, radius_px), (radius_px, radius_px)), mode="edge")
    integral = np.pad(padded, ((1, 0), (1, 0)), mode="constant")
    integral = integral.cumsum(axis=0).cumsum(axis=1)
    width = 2 * radius_px + 1
    total = integral[width:, width:] - integral[:-width, width:] - integral[width:, :-width] + integral[:-width, :-width]
    return (total / float(width * width)).astype(np.float32)


def _float_setting(settings: dict[str, Any], key: str, default: float, minimum: float | None = None) -> float:
    try:
        value = float(settings.get(key, default))
    except (TypeError, ValueError):
        value = default
    if not math.isfinite(value):
        value = default
    if minimum is not None:
        value = max(minimum, value)
    return value


def _visual_layer_summary(array: np.ndarray | None, names: list[str]) -> dict[str, Any]:
    """Summarise decoded visual channels for diagnosing bad map colours."""
    if array is None or array.ndim != 3 or array.shape[0] == 0:
        return {"present": False, "resolution": None, "channels": []}
    means = np.mean(array.astype(np.float32), axis=(1, 2)) / 255.0
    step = max(1, array.shape[1] // 512)
    sample = array[:, ::step, ::step].astype(np.float32)
    totals = np.maximum(np.sum(sample, axis=0), 1.0)
    dominant = np.argmax(sample / totals[None, ...], axis=0)
    counts = np.bincount(dominant.ravel(), minlength=array.shape[0]).astype(np.float64)
    counts /= max(1, dominant.size)
    channels = []
    for index in range(array.shape[0]):
        channels.append({
            "name": names[index] if index < len(names) else f"Channel {index}",
            "mean_weight": round(float(means[index]), 5),
            "dominant_percent": round(float(counts[index] * 100.0), 2),
        })
    return {"present": True, "resolution": int(array.shape[1]), "channels": channels}


def _connected_component_stats(
    candidate: np.ndarray,
    sampled_height: np.ndarray,
    slope: np.ndarray,
    local_deviation: np.ndarray,
    x_index: np.ndarray,
    z_index: np.ndarray,
    min_cells: int,
) -> list[dict[str, Any]]:
    """Return component aggregates, using compiled labeling when available.

    The fallback is intentionally dependency-free. SciPy's compiled connected
    component pass is substantially faster for the 700²/1200² flat search and
    releases the GIL, while the rest of the service remains usable in minimal
    installs without SciPy.
    """
    if _ndimage is not None:
        structure = np.asarray([[0, 1, 0], [1, 1, 1], [0, 1, 0]], dtype=np.uint8)
        labels, component_count = _ndimage.label(candidate, structure=structure)
        counts = np.bincount(labels.ravel(), minlength=component_count + 1)
        component_ids = np.flatnonzero(counts >= min_cells)
        component_ids = component_ids[component_ids != 0]
        if not component_ids.size:
            return []
        label_values = labels.ravel()
        valid = label_values > 0
        label_values = label_values[valid]
        x_values = np.tile(x_index, candidate.shape[0])[valid]
        z_values = np.repeat(z_index, candidate.shape[1])[valid]
        y_values = sampled_height.ravel()[valid]
        slope_values = slope.ravel()[valid]
        deviation_values = local_deviation.ravel()[valid]
        size = component_count + 1
        stats = {
            "count": counts,
            "sum_x": np.bincount(label_values, weights=x_values, minlength=size),
            "sum_z": np.bincount(label_values, weights=z_values, minlength=size),
            "sum_y": np.bincount(label_values, weights=y_values, minlength=size),
            "sum_slope": np.bincount(label_values, weights=slope_values, minlength=size),
        }
        min_x = np.full(size, np.inf); min_z = np.full(size, np.inf); min_y = np.full(size, np.inf)
        max_x = np.full(size, -np.inf); max_z = np.full(size, -np.inf); max_y = np.full(size, -np.inf); max_deviation = np.full(size, -np.inf)
        np.minimum.at(min_x, label_values, x_values); np.minimum.at(min_z, label_values, z_values); np.minimum.at(min_y, label_values, y_values)
        np.maximum.at(max_x, label_values, x_values); np.maximum.at(max_z, label_values, z_values); np.maximum.at(max_y, label_values, y_values); np.maximum.at(max_deviation, label_values, deviation_values)
        return [
            {
                "count": int(stats["count"][component_id]),
                "sum_x": float(stats["sum_x"][component_id]),
                "sum_z": float(stats["sum_z"][component_id]),
                "sum_y": float(stats["sum_y"][component_id]),
                "sum_slope": float(stats["sum_slope"][component_id]),
                "min_x": int(min_x[component_id]), "max_x": int(max_x[component_id]),
                "min_z": int(min_z[component_id]), "max_z": int(max_z[component_id]),
                "max_deviation": float(max_deviation[component_id]),
                "min_y": float(min_y[component_id]), "max_y": float(max_y[component_id]),
            }
            for component_id in component_ids
        ]

    visited = np.zeros(candidate.shape, dtype=bool)
    stats: list[dict[str, Any]] = []
    height_rows, height_cols = candidate.shape
    for start_z in range(height_rows):
        for start_x in range(height_cols):
            if not candidate[start_z, start_x] or visited[start_z, start_x]:
                continue
            queue: deque[tuple[int, int]] = deque([(start_z, start_x)])
            visited[start_z, start_x] = True
            count = 0
            sum_x = sum_z = sum_y = sum_slope = 0.0
            min_x = min_z = 10**9; max_x = max_z = -1
            max_component_deviation = 0.0
            min_component_y = float("inf"); max_component_y = float("-inf")
            while queue:
                z_pos, x_pos = queue.popleft()
                count += 1
                original_x = float(x_index[x_pos]); original_z = float(z_index[z_pos])
                sum_x += original_x; sum_z += original_z
                cell_y = float(sampled_height[z_pos, x_pos]); sum_y += cell_y
                min_component_y = min(min_component_y, cell_y); max_component_y = max(max_component_y, cell_y)
                sum_slope += float(slope[z_pos, x_pos])
                max_component_deviation = max(max_component_deviation, float(local_deviation[z_pos, x_pos]))
                min_x = min(min_x, int(original_x)); max_x = max(max_x, int(original_x))
                min_z = min(min_z, int(original_z)); max_z = max(max_z, int(original_z))
                for next_z, next_x in ((z_pos - 1, x_pos), (z_pos + 1, x_pos), (z_pos, x_pos - 1), (z_pos, x_pos + 1)):
                    if 0 <= next_z < height_rows and 0 <= next_x < height_cols and candidate[next_z, next_x] and not visited[next_z, next_x]:
                        visited[next_z, next_x] = True; queue.append((next_z, next_x))
            if count >= min_cells:
                stats.append({
                    "count": count, "sum_x": sum_x, "sum_z": sum_z, "sum_y": sum_y, "sum_slope": sum_slope,
                    "min_x": min_x, "max_x": max_x, "min_z": min_z, "max_z": max_z,
                    "max_deviation": max_component_deviation, "min_y": min_component_y, "max_y": max_component_y,
                })
    return stats

def find_flat_areas(
    doc: MapDocument,
    height_scale_m: float,
    settings: dict[str, Any] | None = None,
    grid_cell_size_m: float = 150.0,
    grid_numbering: str = "zero_based",
) -> dict[str, Any]:
    """Find connected, buildable, low-relief terrain patches.

    The search intentionally runs on a capped sampling grid. This keeps a 4097
    map bounded in memory while still returning world-space coordinates and
    original heightmap pixel bounds for the interactive overlay.
    """
    settings = settings if isinstance(settings, dict) else {}
    height = decode_heightmap(doc)
    topology = decode_topology(doc)
    if height is None:
        return {"areas": [], "summary": {"candidate_count": 0, "sampled_resolution": None}, "warnings": ["Flat-area search requires a height/terrain layer."]}

    min_area_m2 = _float_setting(settings, "min_area_m2", 900.0, 1.0)
    max_deviation_m = _float_setting(settings, "max_local_deviation_m", 6.0, 0.01)
    max_slope_deg = _float_setting(settings, "max_slope_deg", 5.0, 0.1)
    min_y_m = _float_setting(settings, "min_y_m", -1.0)
    sample_radius_m = _float_setting(settings, "sample_radius_m", 15.0, 0.0)
    try:
        max_grid_cells = int(settings.get("max_grid_cells", 700))
    except (TypeError, ValueError):
        max_grid_cells = 700
    max_grid_cells = max(64, min(1200, max_grid_cells))
    exclude_topology = settings.get("exclude_topology", ["Ocean", "River", "Lake", "Cliff"])
    if isinstance(exclude_topology, str):
        exclude_topology = [exclude_topology]
    exclude_mask = 0
    for name in exclude_topology or []:
        if str(name) in TOPOLOGY_BITS:
            exclude_mask |= TOPOLOGY_BITS[str(name)]

    source_resolution = int(height.shape[0])
    sampled_resolution = min(source_resolution, max_grid_cells)
    z_index = np.linspace(0, source_resolution - 1, sampled_resolution).round().astype(np.int32)
    x_index = z_index.copy()
    sampled_height = height[np.ix_(z_index, x_index)].astype(np.float32) * float(height_scale_m)
    # `terrain_y_offset_m` lets an exporter specify the Unity terrain datum.
    sampled_height += _float_setting(settings, "terrain_y_offset_m", 0.0)
    cell_m = doc.size_m / max(1, sampled_resolution - 1)

    dz_dz, dz_dx = np.gradient(sampled_height, cell_m, cell_m)
    slope = np.degrees(np.arctan(np.hypot(dz_dx, dz_dz))).astype(np.float32)
    radius_px = int(round(sample_radius_m / cell_m))
    local_mean = _box_mean(sampled_height, radius_px)
    local_sq_mean = _box_mean(sampled_height * sampled_height, radius_px)
    local_std = np.sqrt(np.maximum(0.0, local_sq_mean - local_mean * local_mean))
    local_deviation = local_std * 2.0

    candidate = np.isfinite(sampled_height) & (sampled_height >= min_y_m) & (slope <= max_slope_deg) & (local_deviation <= max_deviation_m)
    if topology is not None and exclude_mask:
        topo_z = np.linspace(0, topology.shape[0] - 1, sampled_resolution).round().astype(np.int32)
        topo_x = np.linspace(0, topology.shape[1] - 1, sampled_resolution).round().astype(np.int32)
        topo_sample = topology[np.ix_(topo_z, topo_x)]
        candidate &= (topo_sample & exclude_mask) == 0

    min_cells = max(4, int(math.ceil(min_area_m2 / max(cell_m * cell_m, 1e-6))))
    component_stats = _connected_component_stats(candidate, sampled_height, slope, local_deviation, x_index, z_index, min_cells)
    areas: list[dict[str, Any]] = []
    for component in component_stats:
        count = int(component["count"])
        center_px = float(component["sum_x"]) / count
        center_pz = float(component["sum_z"]) / count
        world_x = doc.origin[0] + center_px / max(1, source_resolution - 1) * doc.size_m
        world_z = doc.origin[1] + center_pz / max(1, source_resolution - 1) * doc.size_m
        mean_y = float(component["sum_y"]) / count
        min_x = int(component["min_x"]); max_x = int(component["max_x"])
        min_z = int(component["min_z"]); max_z = int(component["max_z"])
        area = {
            "area_id": f"flat-{len(areas) + 1}",
            "icon": "hammer",
            "label": "Flat build area",
            "area_m2": round(count * cell_m * cell_m, 2),
            "grid_reference": grid_reference(doc, world_x, world_z, grid_cell_size_m, grid_numbering),
            "center": {"x": round(world_x, 2), "y": round(mean_y, 2), "z": round(world_z, 2)},
            "mean_y_m": round(mean_y, 2),
            "min_y_m": round(float(component["min_y"]), 2),
            "max_y_m": round(float(component["max_y"]), 2),
            "max_local_deviation_m": round(float(component["max_deviation"]), 2),
            "mean_slope_deg": round(float(component["sum_slope"]) / count, 2),
            "source_resolution": source_resolution,
            "sampled_resolution": sampled_resolution,
            "bbox_pixel": {"min_x": min_x, "max_x": max_x, "min_y": min_z, "max_y": max_z},
            "bbox_world": {
                "min_x": round(doc.origin[0] + min_x / max(1, source_resolution - 1) * doc.size_m, 2),
                "max_x": round(doc.origin[0] + max_x / max(1, source_resolution - 1) * doc.size_m, 2),
                "min_z": round(doc.origin[1] + min_z / max(1, source_resolution - 1) * doc.size_m, 2),
                "max_z": round(doc.origin[1] + max_z / max(1, source_resolution - 1) * doc.size_m, 2),
            },
            "settings": {
                "min_area_m2": min_area_m2,
                "max_local_deviation_m": max_deviation_m,
                "max_slope_deg": max_slope_deg,
                "min_y_m": min_y_m,
                "sample_radius_m": sample_radius_m,
                "terrain_y_offset_m": _float_setting(settings, "terrain_y_offset_m", 0.0),
            },
        }
        areas.append(area)
    areas.sort(key=lambda item: item["area_m2"], reverse=True)
    for index, area in enumerate(areas, 1):
        area["area_id"] = f"flat-{index}"
    warnings: list[str] = []
    if not areas:
        warnings.append("No flat areas met the configured area, slope, relief, elevation, and topology constraints.")
    if sampled_resolution < source_resolution:
        warnings.append(f"Flat search was downsampled from {source_resolution}² to {sampled_resolution}² to bound memory and runtime.")
    return {
        "areas": areas[:250],
        "summary": {
            "candidate_count": len(areas),
            "returned_count": min(len(areas), 250),
            "sampled_resolution": sampled_resolution,
            "source_resolution": source_resolution,
            "min_area_m2": min_area_m2,
            "max_local_deviation_m": max_deviation_m,
            "max_slope_deg": max_slope_deg,
            "min_y_m": min_y_m,
        },
        "warnings": warnings,
    }


def flat_areas_geojson(areas: list[dict[str, Any]]) -> bytes:
    features: list[dict[str, Any]] = []
    for area in areas:
        center = area.get("center", {})
        bbox = area.get("bbox_world")
        if not bbox:
            # A point is still useful to GIS clients if the rectangular bounds
            # are not available in an older job.
            geometry = {"type": "Point", "coordinates": [center.get("x", 0), center.get("z", 0)]}
        else:
            geometry = {
                "type": "Polygon",
                "coordinates": [[
                    [bbox["min_x"], bbox["min_z"]], [bbox["max_x"], bbox["min_z"]],
                    [bbox["max_x"], bbox["max_z"]], [bbox["min_x"], bbox["max_z"]], [bbox["min_x"], bbox["min_z"]],
                ]],
            }
        features.append({"type": "Feature", "geometry": geometry, "properties": area})
    return json.dumps({"type": "FeatureCollection", "features": features}, indent=2, ensure_ascii=False).encode("utf-8")


def _distance(a: PrefabInstance, b: PrefabInstance) -> float:
    return math.hypot(a.position[0] - b.position[0], a.position[2] - b.position[2])


def analyze_document(
    doc: MapDocument,
    config: str | dict[str, Any] | list[Any] | None = None,
    height_scale_m: float | None = None,
) -> dict[str, Any]:
    normalized = normalize_config(config)
    catalog = normalized["catalog"]
    rules = normalized["rules"]
    grid_config = normalized.get("grid", {})
    grid_cell_size = float(grid_config.get("cell_size_m", 150.0))
    grid_numbering = str(grid_config.get("numbering", "zero_based"))
    height = decode_heightmap(doc)
    topology = decode_topology(doc)
    splat = decode_splat(doc)
    biome = decode_biome(doc)
    scale_m = float(height_scale_m or doc.size_y_m or 1000.0)
    if not math.isfinite(scale_m) or scale_m <= 0:
        scale_m = 1000.0

    configured_path_by_id: dict[str, str] = {}
    for rule in rules:
        for configured_path in rule.get("paths", []):
            configured_path_by_id[str(prefab_id_for_path(configured_path))] = configured_path
    resolved_names: list[str] = []
    resolved_name_sources: list[str] = []
    unknown_ids = 0
    for prefab in doc.prefabs:
        catalog_name = _catalog_name(prefab, catalog)
        configured_name = configured_path_by_id.get(str(prefab.prefab_id), "") if prefab.prefab_id is not None else ""
        name = catalog_name or configured_name
        resolved_names.append(name)
        resolved_name_sources.append("catalog" if catalog_name else ("configured-path-id" if configured_name else "unresolved"))
        if not name and prefab.prefab_id is not None:
            unknown_ids += 1

    markers: list[dict[str, Any]] = []
    matched_indices: set[int] = set()
    matched_rule_ids: Counter[str] = Counter()
    matched_needs_height = False
    matched_needs_topology = False
    resolution = int(height.shape[0]) if height is not None else (int(topology.shape[0]) if topology is not None else 0)

    for prefab_index, prefab in enumerate(doc.prefabs):
        resolved_name = resolved_names[prefab_index]
        for rule in rules:
            display_name = resolved_name or prefab.display_name
            inferred_rule_path = ""
            if not resolved_name and prefab.prefab_id is not None:
                for candidate_path in rule.get("paths", []):
                    if str(prefab_id_for_path(candidate_path)) == str(prefab.prefab_id):
                        inferred_rule_path = candidate_path
                        display_name = candidate_path
                        break
            if not _matches(prefab, rule, display_name):
                continue
            matched_indices.add(prefab_index)
            matched_rule_ids[rule["id"]] += 1
            kind = str(rule.get("kind", "")).lower()
            wants_slope = bool(rule.get("analyze_slope", kind in {"rock", "rock_formation"}))
            wants_topology = bool(rule.get("analyze_topology", wants_slope or kind in {"ice_lake", "lake"}))
            if wants_slope:
                matched_needs_height = True
            if wants_topology:
                matched_needs_topology = True
            px = pz = None
            topo_px = topo_pz = None
            in_bounds = False
            if resolution:
                px, pz, in_bounds = _pixel_for(doc, prefab.position[0], prefab.position[2], resolution)
            if topology is not None:
                topo_px, topo_pz, _ = _pixel_for(doc, prefab.position[0], prefab.position[2], topology.shape[0])
            radius_slope = float(rule.get("slope_radius_m", 24.0))
            default_topology_radius = 40.0 if rule.get("id") == "god-rock" or str(rule.get("kind", "")).lower() == "god_rock" else 24.0
            radius_topology = float(rule.get("topology_radius_m", rule.get("proximity_radius_m", default_topology_radius)))
            short_name = prefab_short_name(display_name)
            catalog_preview = _catalog_preview(prefab, catalog)
            catalog_model_url, catalog_model_format, catalog_asset_path = _catalog_model(prefab, catalog)
            model_url = prefab.model_url or catalog_model_url or str(rule.get("model_url", rule.get("model", "")) or "")
            model_format = prefab.model_format or catalog_model_format
            asset_path = prefab.asset_path or catalog_asset_path or (display_name if "/" in display_name or display_name.endswith(".prefab") else "")
            mounted_url, mounted_format, mounted_asset_path = _mounted_model_asset(asset_path)
            if not model_url and mounted_url:
                model_url = mounted_url
                model_format = model_format or mounted_format
                asset_path = mounted_asset_path
            if not model_format and model_url:
                model_format = model_url.rsplit("?", 1)[0].rsplit(".", 1)[-1].lower() if "." in model_url.rsplit("?", 1)[0] else ""
            explicit_preview = prefab.preview_url or catalog_preview
            preview_url = explicit_preview or str(rule.get("preview_url", "")) or CATEGORY_PREVIEWS.get(kind, GENERIC_CATEGORY_PREVIEW)
            marker: dict[str, Any] = {
                "marker_id": f"{rule['id']}:{prefab_index}",
                "rule_id": rule["id"],
                "label": rule["label"],
                "kind": kind,
                "color": _safe_color(rule.get("color")),
                "prefab_index": prefab_index,
                "prefab_id": prefab.prefab_id,
                "category": prefab.category,
                "name": display_name,
                "short_name": short_name,
                "preview_url": preview_url,
                "preview_kind": "asset" if explicit_preview else "category",
                "preview_source": "extracted-asset" if model_url else "category-fallback",
                "preview_is_placeholder": not bool(explicit_preview),
                "model_url": model_url,
                "model_format": model_format,
                "asset_path": asset_path,
                "name_resolved": bool(resolved_name or inferred_rule_path),
                "name_source": resolved_name_sources[prefab_index] if resolved_name else ("rule-path-id" if inferred_rule_path else "unresolved"),
                "grid_reference": grid_reference(doc, prefab.position[0], prefab.position[2], grid_cell_size, grid_numbering),
                "position": {"x": round(prefab.position[0], 3), "y": round(prefab.position[1], 3), "z": round(prefab.position[2], 3)},
                "rotation": {"x": round(prefab.rotation[0], 3), "y": round(prefab.rotation[1], 3), "z": round(prefab.rotation[2], 3)},
                "scale": {"x": round(prefab.scale[0], 4), "y": round(prefab.scale[1], 4), "z": round(prefab.scale[2], 4)},
                "in_bounds": in_bounds,
                "analysis": {},
            }
            if resolution and px is not None and pz is not None:
                # Image y follows the decoded map row (z), which keeps the
                # overlay and topology/height sampling aligned.
                marker["pixel"] = {"x": round(float(px), 2), "y": round(float(pz), 2), "resolution": resolution}
            else:
                marker["pixel"] = None

            if wants_slope:
                marker["analysis"]["slope"] = _slope_summary(
                    height,
                    px or 0.0,
                    pz or 0.0,
                    radius_slope,
                    doc,
                    scale_m,
                    prefab.position[1],
                )
            if wants_topology:
                topology_cell_m = _pixel_distance_to_world(doc, topology.shape[0]) if topology is not None else 1.0
                is_god_rock = rule.get("id") == "god-rock" or kind == "god_rock"
                try:
                    foundation_size_m = max(0.1, float(rule.get("foundation_footprint_m", 3.0)))
                except (TypeError, ValueError):
                    foundation_size_m = 3.0
                try:
                    foundation_step_m = max(0.01, float(rule.get("foundation_height_step_m", 1.25)))
                except (TypeError, ValueError):
                    foundation_step_m = 1.25
                if is_god_rock:
                    try:
                        visual_grid_size = max(9, min(31, int(rule.get("topology_grid_size", 27))))
                    except (TypeError, ValueError):
                        visual_grid_size = 27
                else:
                    visual_grid_size = 27
                topology_summary = _topology_summary(
                    topology,
                    topo_px if topo_px is not None else 0.0,
                    topo_pz if topo_pz is not None else 0.0,
                    max(0.5, radius_topology / topology_cell_m),
                    radius_topology,
                    height=height,
                    height_scale_m=scale_m,
                    include_visual_grid=is_god_rock,
                    visual_grid_size=visual_grid_size,
                    foundation_size_m=foundation_size_m,
                    foundation_step_m=foundation_step_m,
                )
                if is_god_rock and topology_summary and topology_summary.get("sample_grid"):
                    center_x = float(prefab.position[0])
                    center_z = float(prefab.position[2])
                    sample_grid = topology_summary["sample_grid"]
                    sample_grid["center_world"] = {
                        "x": round(center_x, 2),
                        "z": round(center_z, 2),
                    }
                    sample_grid["world_bounds"] = {
                        "west_x": round(center_x - radius_topology, 2),
                        "east_x": round(center_x + radius_topology, 2),
                        "south_z": round(center_z - radius_topology, 2),
                        "north_z": round(center_z + radius_topology, 2),
                    }
                marker["analysis"]["topology"] = topology_summary
            if kind in {"ice_lake", "lake", "frozen_lake"}:
                suffix_match = re.search(r"(?:_|-)([0-9]+|[a-z])$", short_name.lower())
                suffix = suffix_match.group(1) if suffix_match else ""
                blocked_suffixes = {str(value).lower() for value in rule.get("building_blocked_suffixes", [])}
                clear_suffixes = {str(value).lower() for value in rule.get("building_clear_suffixes", [])}
                if suffix in blocked_suffixes:
                    status = "blocked"
                    message = "Numbered ice-lake variant: map elements can block building."
                elif suffix in clear_suffixes:
                    status = "clear"
                    message = "Lettered ice-lake variant: no configured building-blocking elements detected."
                else:
                    status = "unknown"
                    message = "Variant suffix was not classified by the starter rule."
                marker["analysis"]["building"] = {"status": status, "suffix": suffix, "message": message}
            if kind in {"ice_lake", "lake", "frozen_lake"} or "proximity_radius_m" in rule:
                radius = max(0.0, float(rule.get("proximity_radius_m", 120.0)))
                center_tolerance = max(0.0, float(rule.get("center_tolerance_m", 18.0)))
                nearby: list[dict[str, Any]] = []
                for other_index, other in enumerate(doc.prefabs):
                    if other_index == prefab_index:
                        continue
                    distance = _distance(prefab, other)
                    if distance <= radius:
                        other_name = resolved_names[other_index] or other.display_name
                        nearby.append(
                            {
                                "prefab_index": other_index,
                                "prefab_id": other.prefab_id,
                                "name": other_name,
                                "short_name": prefab_short_name(other_name),
                                "name_resolved": bool(resolved_names[other_index]),
                                "category": other.category,
                                "grid_reference": grid_reference(doc, other.position[0], other.position[2], grid_cell_size, grid_numbering),
                                "distance_m": round(distance, 3),
                                "at_center": distance <= center_tolerance,
                                "position": {"x": round(other.position[0], 3), "y": round(other.position[1], 3), "z": round(other.position[2], 3)},
                            }
                        )
                nearby.sort(key=lambda entry: entry["distance_m"])
                marker["analysis"]["proximity"] = {
                    "radius_m": radius,
                    "center_tolerance_m": center_tolerance,
                    "nearby_prefab_count": len(nearby),
                    "nearby_prefabs": nearby[:250],
                    "center_prefab_count": sum(1 for entry in nearby if entry["at_center"]),
                }
            markers.append(marker)

    warnings: list[str] = []
    if not doc.prefabs:
        warnings.append("No prefab instances were found in the input map.")
    if unknown_ids:
        warnings.append(
            f"{unknown_ids} prefab IDs have no name. Native Rust .map files store prefab hashes, so add a catalog mapping in the rules JSON to match those objects by name."
        )
    if matched_needs_height and height is None:
        warnings.append("A matched rule requests slope analysis, but no height/terrain layer was present; slope values are unavailable.")
    if matched_needs_topology and topology is None:
        warnings.append("A matched rule requests topology analysis, but no topology layer was present.")
    if splat is None:
        warnings.append("No Rust splat/ground-texture layer was found; the renderer is using height and biome colour fallback rather than RustEdit texture weights.")
    if biome is None:
        warnings.append("No Rust biome layer was found; Arctic/Tundra contextual snow correction is unavailable.")
    if not markers and rules:
        warnings.append("No prefab instances matched the configured starter rules. Add exact prefab IDs or path/name patterns to the rules JSON.")
    if doc.source_format == "rust-binary" and not catalog:
        warnings.append("Native Rust maps expose numeric prefab IDs. Starter path IDs are derived automatically; add a catalog only when you need names and previews for other, non-starter prefabs.")

    unmatched_categories = Counter((prefab.category or "(none)") for i, prefab in enumerate(doc.prefabs) if i not in matched_indices)
    layer_info: list[dict[str, Any]] = []
    for name, payload in doc.maps.items():
        entry: dict[str, Any] = {"name": name, "bytes": len(payload)}
        lower_name = str(name).lower().replace("_", "")
        channel_count = {"splat": 8, "biome": 4, "alpha": 1}.get(lower_name)
        if channel_count and len(payload) % channel_count == 0:
            channel_bytes = len(payload) // channel_count
            channel_resolution = int(round(math.sqrt(channel_bytes)))
            if channel_resolution * channel_resolution == channel_bytes:
                entry["resolution"] = channel_resolution
                entry["channels"] = channel_count
                entry["element_bytes"] = 1
        if "resolution" not in entry and len(payload) % 4 == 0:
            res4 = int(round(math.sqrt(len(payload) // 4)))
            if res4 * res4 * 4 == len(payload):
                entry["resolution"] = res4
                entry["element_bytes"] = 4
        if "resolution" not in entry and len(payload) % 2 == 0:
            res2 = int(round(math.sqrt(len(payload) // 2)))
            if res2 * res2 * 2 == len(payload):
                entry["resolution"] = res2
                entry["element_bytes"] = 2
        layer_info.append(entry)

    return {
        "tool": {"name": "Rust Map Scout", "version": "0.1.0"},
        "source": {"name": doc.source_name, "format": doc.source_format, "serialization_version": doc.serialization_version, "timestamp": doc.timestamp},
        "map": {
            "size_m": round(doc.size_m, 3),
            "height_scale_m": round(scale_m, 3),
            "origin": {"x": round(doc.origin[0], 3), "z": round(doc.origin[1], 3)},
            "grid": normalized["grid"],
            "layers": layer_info,
            "heightmap_resolution": int(height.shape[0]) if height is not None else None,
            "topology_resolution": int(topology.shape[0]) if topology is not None else None,
            "visual_layers": {
                "splat": _visual_layer_summary(splat, ["Dirt", "Forest", "Grass", "Gravel", "Rock", "Sand", "Snow", "Stones"]),
                "biome": _visual_layer_summary(biome, ["Arid", "Temperate", "Tundra", "Arctic", "Jungle"]),
            },
            "path_count": len(doc.paths),
        },
        "summary": {
            "prefab_count": len(doc.prefabs),
            "matched_marker_count": len(markers),
            "matched_prefab_count": len(matched_indices),
            "unmatched_prefab_count": max(0, len(doc.prefabs) - len(matched_indices)),
            "unresolved_id_count": unknown_ids,
            "rule_matches": dict(matched_rule_ids),
            "unmatched_categories": dict(unmatched_categories),
        },
        "rules": normalized,
        "markers": markers,
        "warnings": warnings,
    }


def report_json(report: dict[str, Any]) -> bytes:
    return json.dumps(report, indent=2, ensure_ascii=False).encode("utf-8")


def report_geojson(report: dict[str, Any]) -> bytes:
    """Export matched prefab points in world X/Z coordinates."""
    features: list[dict[str, Any]] = []
    for marker in report.get("markers", []):
        position = marker.get("position", {})
        analysis = marker.get("analysis", {})
        slope = analysis.get("slope") or {}
        proximity = analysis.get("proximity") or {}
        topology = analysis.get("topology") or {}
        building = analysis.get("building") or {}
        properties = {
            "marker_id": marker.get("marker_id"),
            "rule_id": marker.get("rule_id"),
            "label": marker.get("label"),
            "kind": marker.get("kind"),
            "name": marker.get("name"),
            "short_name": marker.get("short_name"),
            "preview_url": marker.get("preview_url"),
            "preview_kind": marker.get("preview_kind"),
            "model_url": marker.get("model_url"),
            "model_format": marker.get("model_format"),
            "asset_path": marker.get("asset_path"),
            "prefab_id": marker.get("prefab_id"),
            "grid_reference": marker.get("grid_reference", {}).get("reference"),
            "building_status": building.get("status"),
            "building_message": building.get("message"),
            "category": marker.get("category"),
            "world_y": position.get("y"),
            "rotation": marker.get("rotation"),
            "scale": marker.get("scale"),
            "in_bounds": marker.get("in_bounds"),
            "slope_mean_deg": slope.get("mean_angle_deg"),
            "slope_p90_deg": slope.get("p90_angle_deg"),
            "surrounding_y_range_m": slope.get("surrounding_y_range_m"),
            "topology_dominant": topology.get("dominant"),
            "nearby_prefab_count": proximity.get("nearby_prefab_count"),
            "center_prefab_count": proximity.get("center_prefab_count"),
        }
        features.append(
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [position.get("x", 0), position.get("z", 0)]},
                "properties": properties,
            }
        )
    return json.dumps({"type": "FeatureCollection", "features": features}, indent=2, ensure_ascii=False).encode("utf-8")


def report_csv(report: dict[str, Any]) -> bytes:
    output = io.StringIO()
    fieldnames = [
        "marker_id",
        "rule_id",
        "label",
        "kind",
        "name",
        "short_name",
        "preview_url",
        "preview_kind",
        "model_url",
        "model_format",
        "asset_path",
        "prefab_id",
        "category",
        "grid_reference",
        "building_status",
        "position_x",
        "position_y",
        "position_z",
        "rotation_x",
        "rotation_y",
        "rotation_z",
        "scale_x",
        "scale_y",
        "scale_z",
        "in_bounds",
        "slope_center_deg",
        "slope_mean_deg",
        "slope_p90_deg",
        "slope_max_deg",
        "terrain_y_delta_m",
        "topology_dominant",
        "nearby_prefab_count",
        "center_prefab_count",
    ]
    writer = csv.DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()
    for marker in report.get("markers", []):
        pos = marker.get("position", {})
        rotation = marker.get("rotation", {})
        scale = marker.get("scale", {})
        slope = marker.get("analysis", {}).get("slope") or {}
        topology = marker.get("analysis", {}).get("topology") or {}
        proximity = marker.get("analysis", {}).get("proximity") or {}
        writer.writerow(
            {
                "marker_id": marker.get("marker_id", ""),
                "rule_id": marker.get("rule_id", ""),
                "label": marker.get("label", ""),
                "kind": marker.get("kind", ""),
                "name": marker.get("name", ""),
                "short_name": marker.get("short_name", ""),
                "preview_url": marker.get("preview_url", ""),
                "preview_kind": marker.get("preview_kind", ""),
                "model_url": marker.get("model_url", ""),
                "model_format": marker.get("model_format", ""),
                "asset_path": marker.get("asset_path", ""),
                "prefab_id": marker.get("prefab_id", ""),
                "category": marker.get("category", ""),
                "grid_reference": marker.get("grid_reference", {}).get("reference", ""),
                "building_status": (marker.get("analysis", {}).get("building") or {}).get("status", ""),
                "position_x": pos.get("x", ""),
                "position_y": pos.get("y", ""),
                "position_z": pos.get("z", ""),
                "rotation_x": rotation.get("x", ""),
                "rotation_y": rotation.get("y", ""),
                "rotation_z": rotation.get("z", ""),
                "scale_x": scale.get("x", ""),
                "scale_y": scale.get("y", ""),
                "scale_z": scale.get("z", ""),
                "in_bounds": marker.get("in_bounds", ""),
                "slope_center_deg": slope.get("center_angle_deg", ""),
                "slope_mean_deg": slope.get("mean_angle_deg", ""),
                "slope_p90_deg": slope.get("p90_angle_deg", ""),
                "slope_max_deg": slope.get("max_angle_deg", ""),
                "terrain_y_delta_m": slope.get("vertical_delta_m", ""),
                "topology_dominant": topology.get("dominant", ""),
                "nearby_prefab_count": proximity.get("nearby_prefab_count", ""),
                "center_prefab_count": proximity.get("center_prefab_count", ""),
            }
        )
    return output.getvalue().encode("utf-8")


__all__ = [
    "DEFAULT_CONFIG",
    "RuleConfigError",
    "analyze_document",
    "default_config_json",
    "find_flat_areas",
    "flat_areas_geojson",
    "normalize_config",
    "report_csv",
    "report_geojson",
    "report_json",
]
