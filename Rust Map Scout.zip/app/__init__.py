"""Rust Map Scout application package."""
