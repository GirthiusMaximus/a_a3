# Rust Map Scout — AI Agent Review Brief

## 1. Purpose

Rust Map Scout is a Dockerized Rust map inspection and terrain-visualization application. It accepts a native Rust `.map`, a RustEdit/interchange JSON export, a ZIP containing either, or a public map URL. It parses terrain layers, prefab instances, and authored paths; renders a clean RustEdit-style map backdrop; and exposes an interactive browser overlay with configured prefab markers and terrain measurements.

The application is intended for AI-agent review of:

- Map parsing and coordinate/orientation correctness.
- RustEdit-aligned terrain rendering.
- Prefab matching and marker interaction.
- God Rock height/slope sampling.
- Flat build-area search.
- Large-map performance, memory bounds, and Docker deployment.

The current user-facing design deliberately **does not assign an automatic poor/review/ideal build-spot verdict**. Users decide from the terrain measurements and heatmap.

---

## 2. Current goals and non-goals

### Goals

1. Parse native Rust maps without requiring an external prefab catalog for the supplied starter paths.
2. Preserve RustEdit-authoritative visual conventions:
   - Native row-axis correction is `flip_y`.
   - World X/Z coordinates use a centred terrain by default.
   - Splat, biome, topology, water, height, and authored path data remain separately diagnosable.
3. Render a clean downloadable PNG that contains terrain/path presentation but **not** web UI markers, grid lines, heatmap overlays, labels, or popups.
4. Let users click configured prefab markers for exact world coordinates and rule-specific measurements.
5. Give God Rock markers a height-first, slope-aware heatmap centred on the marker.
6. Make the God Rock sample close to a Rust foundation footprint:
   - 40 m radius.
   - 80 m × 80 m sample window.
   - 27 × 27 cells.
   - Approximately 2.963 m per cell.
   - Foundation reference: 3.0 m footprint and 1.25 m adjacent height allowance.
7. Keep map-space regions, heatmap cells, and analysis rings aligned with the map when panning/zooming, while keeping marker icons and labels screen-readable and screen-sized.
8. Keep heavy parsing, analysis, rendering, and flat-area search off the async event loop.

### Non-goals / deliberate limitations

- Native `.map` files do not contain Unity mesh bytes. Exact prefab models require legally obtained sidecar assets and `RUST_ASSET_DIR`.
- Exact RustEdit texture/shader reproduction is not possible without the original game texture, shader, UV, lighting, and colour-grading assets.
- No automatic God Rock build-spot quality verdict is emitted.
- Topology category names are not rendered inside the God Rock height/slope heatmap. Topology data may still exist in backend topology summaries and reports for general terrain diagnostics.
- The clean PNG is not an editable map and does not modify the original `.map`.

---

## 3. Repository layout

```text
app/
  analyzer.py       Prefab matching, terrain analysis, God Rock sampling, flat search, report exports.
  main.py           FastAPI application, upload/download endpoints, job lifecycle.
  map_parser.py     JSON/native Rust map parsing and terrain-layer decoding.
  renderer.py       Clean PNG compositor and RustEdit-style terrain rendering.
  visual_debug.py   Compact decoded-layer diagnostic ZIP generation.
  static/
    index.html      Browser UI shell.
    app.js          Browser analysis workflow, map interactions, popups and overlays.
    styles.css      UI, map, popup, heatmap, and overlay styles.
examples/
  demo-map.json     Compact JSON fixture used by tests and the demo button.
tests/
  test_map_scout.py Regression coverage for parsing, matching, rendering constants, orientation, and God Rock samples.
README.md            User/deployment documentation.
PROJECT_SPEC.md      Authoritative project brief.
AI_AGENT_REVIEW.md   This document.
```

`/home/user/uploads` was temporary workspace material and has been removed. Application job data is written to `OUTPUT_DIR`, which defaults to `/tmp/rust-map-scout` and is not part of the project source tree.

---

## 4. Runtime and deployment parameters

### Environment variables

| Variable | Default | Purpose |
|---|---:|---|
| `MAX_INPUT_MB` | `768` | Maximum uploaded/downloaded map size in MB. |
| `OUTPUT_DIR` | `/tmp/rust-map-scout` | Per-job source copy and generated output directory. |
| `WEB_CONCURRENCY` | `1` in Docker compose | Uvicorn worker count. Each worker is an independent process. |
| `RUST_ASSET_DIR` | empty | Optional read-only directory containing GLB/glTF/OBJ sidecar exports. |

### Python dependencies

Pinned or constrained in `requirements.txt`:

- FastAPI `0.116.1`
- Uvicorn standard `0.35.0`
- python-multipart `0.0.20`
- httpx `0.28.1`
- NumPy `2.3.3`
- SciPy `>=1.15,<2.0`
- Pillow `11.3.0`
- PyYAML `6.0.2`
- lz4 `4.4.4`

### Docker

- Base image: `python:3.12-slim`.
- Container port: `8000`.
- Uvicorn binds to `0.0.0.0`.
- Docker compose persists `/tmp/rust-map-scout` through the `rust-map-scout-output` volume.
- The Arena development preview used during this session runs the same app on port `8001`.

### Useful commands

```bash
# Tests
python -m pytest -q

# JavaScript syntax validation
node --check app/static/app.js

# Python compilation validation
python -m compileall -q app

# Docker deployment
docker compose up --build
```

---

## 5. Input formats and parser data model

### `PrefabInstance`

Defined in `app/map_parser.py`:

```python
@dataclass
class PrefabInstance:
    category: str = ""
    prefab_id: int | str | None = None
    name: str = ""
    preview_url: str = ""
    model_url: str = ""
    model_format: str = ""
    asset_path: str = ""
    position: tuple[float, float, float] = (0.0, 0.0, 0.0)
    rotation: tuple[float, float, float] = (0.0, 0.0, 0.0)
    scale: tuple[float, float, float] = (1.0, 1.0, 1.0)
    index: int = 0
```

Properties:

- `id_text -> str`: string form of `prefab_id`, or empty string.
- `display_name -> str`: embedded name, `id:<id>`, or `unknown prefab`.

### `MapDocument`

```python
@dataclass
class MapDocument:
    size_m: float = 4500.0
    size_y_m: float = 1000.0
    maps: dict[str, bytes] = {}
    prefabs: list[PrefabInstance] = []
    paths: list[dict[str, Any]] = []
    source_format: str = "unknown"
    serialization_version: int | None = None
    timestamp: int | None = None
    source_name: str = "map"
    origin_x_m: float | None = None
    origin_z_m: float | None = None
    metadata: dict[str, Any] = {}
```

`MapDocument.origin` defaults to `(-size_m / 2, -size_m / 2)` unless explicit `origin_x_m`/`origin_z_m` are supplied.

### Supported inputs

`parse_map(data: bytes, source_name: str = "map") -> MapDocument` auto-detects:

1. JSON object or list.
2. ZIP containing the first supported JSON file or `.map` file.
3. Native Rust binary map.

Native Rust binary flow:

```text
4-byte serialization version
8-byte timestamp
legacy LZ4 stream
protobuf WorldData
```

The protobuf decoder is deliberately schema-focused and does not require code generation.

### Terrain decoders

- `decode_heightmap(doc) -> np.ndarray | None`
  - Supports little-endian signed 16-bit normalized terrain values divided by `32766.0`.
  - Supports little-endian float32 normalized values.
  - Returns a 2D float array clipped to `[0, 1]`.
- `decode_topology(doc) -> np.ndarray | None`
  - Supports little-endian int32 bitmask values.
  - Returns a 2D int64 array.
- `decode_splat(doc) -> np.ndarray | None`
  - Decodes 8 channel-major byte channels.
- `decode_biome(doc) -> np.ndarray | None`
  - Decodes current 5-channel or legacy 4-channel biome maps.
- `decode_alpha(doc) -> np.ndarray | None`
  - Decodes a one-channel byte map.
- `decode_water(doc) -> np.ndarray | None`
  - Supports float32 and 16-bit water maps.

Channel-major splat/biome data is shaped `[channel, z, x]`, not interleaved per pixel.

---

## 6. Prefab matching and starter configuration

### Prefab ID derivation

```python
prefab_id_for_path(path: str) -> int
```

Normalizes path separators/lowercase, computes MD5, and interprets the first four digest bytes as a little-endian unsigned integer. This lets native Rust maps match configured starter paths even though native `PrefabData` contains only a numeric hash.

### Configuration normalization

```python
normalize_config(
    config: str | dict[str, Any] | list[Any] | None
) -> dict[str, Any]
```

Accepts JSON, optional YAML, dictionaries, or a list of rules. It normalizes:

- `rules` / `prefab_rules`
- `catalog` / `prefab_catalog`
- `paths` / `prefab_paths`
- `patterns` / `contains`
- `ids` / `prefab_ids`
- `categories`
- Grid cell size and row numbering.

`default_config_json() -> str` returns the normalized starter configuration as formatted JSON.

### Starter rules

#### God Rock

- Rule ID: `god-rock`
- Kind: `god_rock`
- Paths:
  - `assets/bundled/prefabs/autospawn/decor/v3_rock_formations_large/rock_formation_a.prefab`
  - `assets/bundled/prefabs/autospawn/decor/v3_rock_formations_large/rock_formation_e.prefab`
  - `assets/bundled/prefabs/autospawn/decor/v3_rock_formations_large/rock_formation_f.prefab`
- Explicit ID: `291142845`
- `analyze_slope: true`
- `slope_radius_m: 24`
- `topology_radius_m: 40`
- `topology_grid_size: 27`
- `foundation_footprint_m: 3.0`
- `foundation_height_step_m: 1.25`
- Preview: `/static/prefab-previews/god-rock.svg`

The rule no longer has a quality-threshold block and no automatic build-spot verdict is produced.

#### Ice lakes

- Rule ID: `ice-lake`
- Kind: `ice_lake`
- Numbered paths:
  - `assets/bundled/prefabs/autospawn/monument/ice_lakes/ice_lake_1.prefab`
  - `assets/bundled/prefabs/autospawn/monument/ice_lakes/ice_lake_2.prefab`
  - `assets/bundled/prefabs/autospawn/monument/ice_lakes/ice_lake_3.prefab`
  - `assets/bundled/prefabs/autospawn/monument/ice_lakes/ice_lake_4.prefab`
- Lettered paths:
  - `assets/content/nature/ice_lakes/models/ice_lake_a.prefab`
  - `assets/content/nature/ice_lakes/models/ice_lake_b.prefab`
  - `assets/content/nature/ice_lakes/models/ice_lake_c.prefab`
  - `assets/content/nature/ice_lakes/models/ice_lake_d.prefab`
- `building_blocked_suffixes: ["1", "2", "3", "4"]`
- `building_clear_suffixes: ["a", "b", "c", "d"]`
- `topology_radius_m: 120`
- `proximity_radius_m: 120`
- `center_tolerance_m: 18`

The separate ice-lake building-blocker classification is retained.

#### Caves

Rule ID: `cave`, kind `cave`, with the supplied cave paths. Caves are highlighted and receive normal marker/topology display without special scoring.

---

## 7. Core analysis functions

### Basic geometry and matching

```python
def prefab_short_name(name: str) -> str: ...
def grid_reference(
    doc: MapDocument,
    x: float,
    z: float,
    cell_size_m: float = 150.0,
    numbering: str = "zero_based",
) -> dict[str, Any]: ...
def _matches(
    prefab: PrefabInstance,
    rule: dict[str, Any],
    resolved_name: str,
) -> bool: ...
def _pixel_for(
    doc: MapDocument,
    x: float,
    z: float,
    resolution: int,
) -> tuple[float, float, bool]: ...
def _disk_values(
    array: np.ndarray,
    px: float,
    pz: float,
    radius_px: float,
) -> np.ndarray: ...
```

`grid_reference` uses horizontal letter columns and rows measured from north. Default grid cells are 150 m and zero-based.

### Topology summary

```python
def _topology_summary(
    topology: np.ndarray | None,
    px: float,
    pz: float,
    radius_px: float,
    radius_m: float | None = None,
    height: np.ndarray | None = None,
    height_scale_m: float | None = None,
    include_visual_grid: bool = False,
    visual_grid_size: int = 27,
    foundation_size_m: float = 3.0,
    foundation_step_m: float = 1.25,
) -> dict[str, Any] | None: ...
```

It calculates topology bit coverage, dominant flags, unknown bits, and centre flags. For God Rock, `include_visual_grid=True` adds the height/slope sample grid.

### God Rock height/slope sample

```python
def _topology_visual_grid(
    topology: np.ndarray,
    px: float,
    pz: float,
    radius_px: float,
    radius_m: float | None,
    height: np.ndarray | None = None,
    height_scale_m: float | None = None,
    grid_size: int = 27,
    foundation_size_m: float = 3.0,
    foundation_step_m: float = 1.25,
) -> dict[str, Any]: ...
```

Sampling behavior:

1. Build a square grid inside a circular radius.
2. Aggregate topology labels per cell for backend topology data.
3. Aggregate mean terrain Y per cell from the heightmap, multiplied by `height_scale_m`.
4. Calculate per-cell terrain slope from finite differences of the sampled Y grid.
5. Convert slope to estimated absolute Y rise over the foundation footprint:

   ```text
   rise_per_foundation_m = tan(slope_degrees) × foundation_size_m
   ```

6. Use north-up display metadata and preserve `flip_y` row ordering in the browser.

Returned `sample_grid` fields:

```text
size                         27
radius_m                    40.0
cell_m                      2.963
center                      13
orientation                 "north_up"
axis_labels                {top: North, bottom: South, left: West, right: East}
bounds_m                   nominal N/S/E/W radius bounds
cells                      backend topology labels; not rendered in the height heatmap
heights_m                  per-cell world-Y elevations
slope_deg                  per-cell slope angle
rise_per_foundation_m      per-cell estimated Y rise across 3 m
foundation_reference       {footprint_m: 3.0, height_step_m: 1.25, step_slope_deg: 22.62}
height_min_m
height_max_m
center_height_m
slope_min_deg
slope_max_deg
slope_mean_deg
rise_min_m
rise_max_m
rise_mean_m
center_world               marker X/Z
world_bounds               west/east X and south/north Z
```

The 1.25 m rise over 3 m corresponds to approximately `22.62°`. The frontend heatmap maps the ratio `rise_per_foundation_m / 1.25` to green/yellow/orange/red. This is a visual reference, not an automatic build decision.

### Rock terrain summary

```python
def _slope_summary(
    height: np.ndarray | None,
    px: float,
    pz: float,
    radius_m: float,
    doc: MapDocument,
    height_scale_m: float,
    prefab_y_m: float | None = None,
) -> dict[str, Any] | None: ...
```

Returns centre/mean/median/p90/max angle, terrain elevation, surrounding Y min/max/mean/std/range, height scale, and prefab-vs-terrain Y delta measurements. These are measurements only; there is no `analysis.quality` result.

### Main analysis entry point

```python
def analyze_document(
    doc: MapDocument,
    config: str | dict[str, Any] | list[Any] | None = None,
    height_scale_m: float | None = None,
) -> dict[str, Any]: ...
```

It:

1. Normalizes configuration.
2. Decodes height, topology, splat, and biome layers.
3. Resolves names from embedded names, catalogs, or configured path-derived IDs.
4. Matches each prefab against each rule.
5. Creates marker records with world transforms, grid reference, previews, optional sidecar model links, pixel coordinates, slope, topology, proximity, and ice-lake building metadata.
6. Adds God Rock sample grids only for `rule_id == "god-rock"` or `kind == "god_rock"`.
7. Emits warnings for missing layers, unknown IDs, unmatched rules, and missing data.
8. Does **not** emit automatic build-spot quality classifications.

### Flat-area search

```python
def find_flat_areas(
    doc: MapDocument,
    height_scale_m: float,
    settings: dict[str, Any] | None = None,
    grid_cell_size_m: float = 150.0,
    grid_numbering: str = "zero_based",
) -> dict[str, Any]: ...
```

Default settings:

```json
{
  "min_area_m2": 900,
  "max_local_deviation_m": 6,
  "max_slope_deg": 5,
  "min_y_m": -1,
  "sample_radius_m": 15,
  "max_grid_cells": 700,
  "exclude_topology": ["Ocean", "River", "Lake", "Cliff"]
}
```

The search downsamples to a maximum of 1200 cells per side, uses SciPy connected components when available, and falls back to a dependency-free breadth-first component search. It returns area polygons/boxes with centre, Y range, local deviation, slope, source pixel bounds, world bounds, grid reference, and search settings.

Export helpers:

```python
def flat_areas_geojson(areas: list[dict[str, Any]]) -> bytes: ...
def report_json(report: dict[str, Any]) -> bytes: ...
def report_geojson(report: dict[str, Any]) -> bytes: ...
def report_csv(report: dict[str, Any]) -> bytes: ...
```

The CSV no longer contains a `quality_status` column.

---

## 8. Renderer and clean PNG contract

Important renderer constants in `app/renderer.py`:

```python
SPLAT_PALETTE = [
    (153, 122, 84),  # Dirt
    (63, 76, 18),    # Forest
    (90, 94, 52),    # Grass
    (64, 62, 56),    # Gravel
    (102, 100, 96),  # Rock
    (178, 168, 135), # Sand
    (220, 237, 240), # Snow
    (35, 71, 70),    # Stones
]
WATER_COLOR = (43, 81, 92)  # #2B515C
NORMAL_MAP_STRENGTH = 1.5
```

Key functions:

```python
def _sample_grid(array, out_width, out_height, resample=BILINEAR) -> np.ndarray: ...
def _terrain_shade(height, out_size, scale_m, normal_strength=1.5) -> tuple[np.ndarray, np.ndarray]: ...
def _normalise_channels(channels) -> np.ndarray: ...
def _biome_weights(biome, out_size) -> np.ndarray | None: ...
def _apply_biome_context(rgb, biome_weights, splat_weights) -> np.ndarray: ...
def _height_base(height, out_size, scale_m, topology=None, biome=None) -> Image.Image: ...
def _splat_base(height, splat, biome, topology, out_size, scale_m) -> Image.Image: ...
def _topology_base(topology, out_size) -> Image.Image: ...
def _empty_base(out_size) -> Image.Image: ...
def _orient_base(base, orientation) -> Image.Image: ...
def _display_point(doc, world_x, world_z, map_width, map_height, orientation) -> tuple[float, float]: ...
def render_annotated_map(doc, report, output_size=1400) -> Image.Image: ...
```

Rendering rules:

- Splat channel order is Dirt, Forest, Grass, Gravel, Rock, Sand, Snow, Stones.
- Biome order is Arid, Temperate, Tundra, Arctic, Jungle for five-channel maps; four-channel maps remain supported.
- Snow/ice remains snow-like; Arctic/Tundra context repairs sparse Snow paint without replacing the requested palette.
- Water, ocean, offshore, river, lake, and lakeside use `#2B515C` where the compositor applies topology water masking.
- Height-derived normal-map hillshade strength is exactly `1.5`.
- Native decoded rows are displayed with `flip_y` so north/RustEdit row orientation is correct.
- Paths are authored into the clean backdrop subtly.
- UI markers and interactive overlays are never drawn into the downloaded PNG.

---

## 9. FastAPI endpoints and parameters

### `GET /`

Returns the static browser UI.

### `GET /api/health`

Returns:

```json
{"ok": true, "service": "rust-map-scout", "version": "0.1.0"}
```

### `GET /api/config/default`

Returns the normalized starter rules JSON.

### `GET /demo-map.json`

Returns the compact JSON demo fixture.

### `POST /api/analyze`

Multipart form fields:

| Field | Required | Default | Description |
|---|---:|---:|---|
| `map_file` | one of file/URL | — | `.map`, JSON, or ZIP upload. |
| `map_url` | one of file/URL | empty | Public HTTP/HTTPS URL fetched server-side. Private/reserved hosts are rejected. |
| `rules_json` | no | starter rules | JSON or YAML rule document. |
| `height_scale_m` | no | `1000` | Normalized heightmap vertical extent in metres. |
| `render_size` | no | `1400` | Clean PNG size, clamped to 700–2400. |

The response includes:

```text
job_id
source
map
render
summary
warnings
markers
flat_areas
flat_summary
map_image_url
report_json_url
report_csv_url
markers_geojson_url
bundle_url
visual_debug_url
flat_search_url
```

### `POST /api/jobs/{job_id}/flat-areas`

Runs the optional heavier flat-area search. Form fields override configured flat-search values:

```text
min_area_m2
max_local_deviation_m
max_slope_deg
min_y_m
sample_radius_m
max_grid_cells
terrain_y_offset_m
```

### `GET /api/jobs/{job_id}/map.png`

Returns the clean rendered PNG.

### `GET /api/jobs/{job_id}/report.json`

Returns the full JSON report.

### `GET /api/jobs/{job_id}/report.csv`

Returns marker CSV measurements without build-quality status.

### `GET /api/jobs/{job_id}/markers.geojson`

Returns matched prefab points as X/Z GeoJSON features.

### `GET /api/jobs/{job_id}/flat-areas.geojson`

Returns flat-area polygons when flat search has been run.

### `GET /api/jobs/{job_id}/bundle.zip`

Returns a ZIP containing the clean PNG, JSON report, CSV report, GeoJSON marker points, and README notes. The original uploaded map is not included.

### `GET /api/jobs/{job_id}/visual-debug.zip`

Builds/returns a compact decoded-layer ZIP containing height, splat, biome, topology, water, diagnostics, and renderer preview. The original large map is deliberately excluded.

---

## 10. Browser UI functions and interaction contract

Important functions in `app/static/app.js`:

```javascript
escapeHtml(value)
safeResourceUrl(value)
formatBytes(value)
setStatus(message, error = false)
renderMapGrid(data)
markerPoint(marker, data)
openMarkerPopup(marker, focus = false)
openFlatAreaPopup(area)
closeMarkerPopup()
renderInteractiveFlatAreas(data)
renderInteractiveMarkers(data)
updateScreenConstantOverlay()
renderStats(data)
markerTerrain(marker)
renderMarkers(data)
renderWarnings(data)
renderReadout(data)
findFlatAreas()
showResult(data)
analyze()
loadRules()
useDemo()
```

### Map overlay separation

- The clean PNG is an `<img>` inside `#mapStage`.
- `#mapOverlay` is an SVG UI layer above it.
- Map-space objects such as heatmap cells, topology/sample rings, grid lines, and flat-area rectangles follow map zoom/pan.
- Marker circles, prefab labels, flat-area hammer icons, and their click targets are wrapped in counter-scaled SVG groups by `updateScreenConstantOverlay()`. Their screen size remains stable while their anchor moves with the map.
- The heatmap and marker overlays are not part of the downloaded PNG.

### God Rock popup

The popup shows:

- Prefab identity and world X/Y/Z.
- Grid reference and scale.
- Floor-angle summary measurements.
- Height/slope heatmap.
- Y range and centre Y.
- 3 m foundation reference and 1.25 m adjacent height allowance.
- North/South/East/West axes and world bounds.
- Per-cell directional hover/focus values: Y, slope, and estimated rise over 3 m.

Topology category names are intentionally omitted from this height/slope visualization.

---

## 11. Report shape and important marker fields

Each matched marker generally contains:

```text
marker_id
rule_id
label
kind
color
prefab_index
prefab_id
category
name
short_name
preview_url
preview_kind
preview_source
preview_is_placeholder
model_url
model_format
asset_path
name_resolved
name_source
grid_reference
position {x, y, z}
rotation {x, y, z}
scale {x, y, z}
in_bounds
pixel {x, y, resolution} | null
analysis
```

`analysis` can contain:

- `slope`: floor-angle and Y measurements.
- `topology`: bit coverage, dominant flags, centre flags, and for God Rock `sample_grid`.
- `proximity`: ice-lake/nearby-prefab counts and entries.
- `building`: separate ice-lake suffix/blocker classification.

It does not contain `quality` for automatic build-spot classification.

---

## 12. Orientation and coordinate rules

- World X/Z is mapped against `MapDocument.origin` and `size_m`.
- World X increases eastward in the display convention.
- World Z increases northward in the display convention used by the Rust grid reference.
- Source raster arrays are indexed `[z, x]`.
- The browser reverses source rows for `render.orientation == "flip_y"`, keeping north at the top.
- The renderer and interactive marker/grid projection must use the same orientation.
- Any change to orientation must update:
  - `_orient_base`
  - `_display_point`
  - frontend `displayPixel`
  - grid labels
  - God Rock sample row order
  - marker positions

---

## 13. Regression and acceptance checklist for AI agents

Before accepting a change, verify:

1. Native `.map`, JSON, and ZIP parsing still work.
2. God Rock A/E/F all match, including Formation F ID `291142845`.
3. Only God Rock markers receive the height/slope sample heatmap.
4. Ice lakes and caves still open their popups.
5. The God Rock sample remains 40 m radius, 27 × 27, approximately 3 m cells.
6. Every valid sampled cell has Y, slope, and rise-over-3-m values.
7. Heatmap directions remain north-up with `flip_y` preserved.
8. Flat terrain is greener; terrain approaching/exceeding 1.25 m rise over 3 m transitions yellow/orange/red.
9. No automatic `analysis.quality`, poor/review/ideal label, or CSV `quality_status` is reintroduced.
10. Marker icons, labels, hammer icons, and hit targets remain screen-sized during zoom.
11. Heatmap/map-space rectangles still scale and align with the raster.
12. Downloaded PNG contains no markers or UI overlays.
13. Water/offshore remains `#2B515C`.
14. Normal-map strength remains exactly `1.5`.
15. Snow/ice remains snow-like.
16. `python -m pytest -q` passes.
17. `node --check app/static/app.js` passes.
18. Large-map processing remains bounded and CPU-heavy work stays in worker threads.

Current baseline test count: **9 passing tests**.
