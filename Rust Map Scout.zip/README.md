# Rust Map Scout

A Dockerized Rust map inspection tool. Upload a native Rust `.map`, a RustEdit/interchange JSON export, or provide a public map URL. The service parses the map, renders an annotated terrain view, and produces JSON/CSV findings for configured prefab rules.

## What it does

- Parses the native Rust world format: header, legacy LZ4 stream, protobuf `WorldData`, map layers, prefab transforms, and path records.
- Accepts JSON interchange maps and ZIP files containing a supported `.map` or JSON file.
- Renders a clean, square RustEdit-style top-down backdrop from the map's native ground-texture (splat) layer when present, with biome grading, terrain relief, RustEdit-reference-aligned native row-axis correction, and authored road/river/rail paths. Interactive markers and analysis overlays are added only by the web UI, not baked into the PNG.
- Starter rules now target the supplied God Rock paths:
  - `rock_formation_a.prefab`
  - `rock_formation_e.prefab`
  - `rock_formation_f.prefab` (derived prefab ID `291142845`)
- The rendered result is an interactive map: drag to pan, scroll or use +/- to zoom, toggle the 150 m grid, and click markers for a detail popup.
- Marker popups show prefab short name, full path, X/Y/Z, Rust grid reference, current scale, topology, and terrain measurements. Selecting a God Rock also paints its sampled window directly around the marker and shows a height/slope heatmap in the popup. The God Rock sample is a 27 × 27 north-up window with a 40 m radius (80 × 80 m) so it covers formations around 69 × 63 m while keeping each cell close to a 3 × 3 m foundation footprint. Every sampled cell includes terrain Y, derived slope, and estimated Y rise across 3 m. Flat cells are green; terrain approaching the 1.25 m adjacent-foundation height allowance transitions through yellow/orange; terrain above that becomes red. North/South/East/West labels, world bounds, Y range, centre Y, and directional cell hover readouts are included. Topology categories are not included in this height sample.
- For rock rules, the heightmap is sampled around the prefab and reports floor angle statistics: centre, mean, median, p90, and maximum. Map Scout exposes these measurements and the heatmap without assigning an automatic poor/review/ideal build-spot verdict; the user decides from the terrain evidence.

- For ice-lake rules, lists every other prefab within the configured radius and counts objects within the centre tolerance. Numbered variants are flagged as potentially building-blocked; lettered variants are flagged as clear under the supplied starter rule.
- Cave paths from the supplied list are highlighted as monument markers.
- Reports topology flags such as Lake, Lakeside, Cliff, Road, Mountain, and Field around each marker.
- Runs an optional downsampled flat-build-area search with compiled SciPy connected-component/statistics acceleration when available, a bounded dependency-free fallback, minimum Y filtering, local Y-deviation checks, slope limits, topology exclusions, hammer overlays, and GeoJSON output. CPU-heavy parsing, analysis, rendering, and flat searches run in worker threads so concurrent requests do not block the async HTTP loop.
- Provides downloadable JSON, CSV, GeoJSON marker points, and a ZIP bundle from each job.

## Important prefab-name limitation

Native Rust `PrefabData` stores a numeric `id`/hash, position, rotation, and scale; it does not carry the human-readable prefab path. The supplied starter paths now derive their uint IDs automatically from the full asset paths, so those rules work on native binary maps without a catalog. An ID catalog is still useful for other prefabs and exact previews. Open **Prefab rules & catalog** in the UI and add entries such as:

```json
{
  "catalog": {
    "123456789": {
      "name": "assets/content/nature/rock_formation_granite.prefab",
      "preview_url": "/static/prefab-previews/god-rock.svg",
      "model_url": "/rust-assets/assets/content/nature/rock_formation_granite.glb",
      "model_format": "glb"
    }
  },
  "rules": [
    {
      "id": "rock-formation",
      "label": "Rock formation",
      "patterns": ["rock_formation"],
      "analyze_slope": true,
      "slope_radius_m": 24
    }
  ]
}
```

Prefab previews can be supplied in an interchange prefab record with `preview_url` plus `model_url`/`model_format`, or in the catalog entry with `preview_url`, `model_url`, and optional `asset_path`. The starter UI includes self-contained category 3D-style previews for God Rock, Ice Lake, and Cave. Native `.map` files do not contain Unity mesh bytes, so exact model extraction is not possible from the map alone. For a deployment with legally obtained Rust asset exports, set `RUST_ASSET_DIR`; GLB, glTF, or OBJ sidecar files beside the prefab path are exposed read-only at `/rust-assets/...` and linked from the marker popup. If no model is available, the category preview remains usable rather than failing the popup.

You can also match directly by numeric IDs:

```json
{
  "rules": [
    { "id": "ice-lake", "label": "Ice lake", "ids": ["987654321"], "kind": "ice_lake", "proximity_radius_m": 120 }
  ]
}
```

## Run with Docker

```bash
docker compose up --build
```

Then open <http://localhost:8000>. The container binds Uvicorn to `0.0.0.0`, so it also works behind the Arena live preview proxy. Set `WEB_CONCURRENCY` to the number of worker processes appropriate for the host; CPU-heavy work is moved off the async loop, and SciPy/NumPy accelerate the large flat-area pass. For a large local map, raise the limit without putting the file in the workspace, for example `MAX_INPUT_MB=4096 docker compose up --build`, then POST the file directly to the local service with `curl -F map_file=@/path/to/world.map http://localhost:8000/api/analyze`.

Direct Docker invocation:

```bash
docker build -t rust-map-scout .
docker run --rm -p 8000:8000 -e WEB_CONCURRENCY=1 rust-map-scout
```

## HTTP API

`POST /api/analyze` accepts multipart form fields:

- `map_file`: uploaded `.map`, JSON, or ZIP
- `map_url`: public `http://` or `https://` map URL (use instead of `map_file`)
- `rules_json`: JSON or YAML rules document
- `height_scale_m`: vertical extent used for normalized height-to-slope conversion; defaults to `1000`
- `render_size`: clean PNG backdrop size from `700` to `2400`; defaults to `1400`

After an analysis, `POST /api/jobs/{job_id}/flat-areas` runs the heavier flat-build-area pass. Optional form fields are `min_area_m2`, `max_local_deviation_m`, `max_slope_deg`, `min_y_m`, `sample_radius_m`, `max_grid_cells`, and `terrain_y_offset_m`. The response updates the clean map backdrop and exposes `flat-areas.geojson`. `GET /api/jobs/{job_id}/visual-debug.zip` creates a compact ZIP containing decoded height, splat, biome, topology and water layer PNGs, channel diagnostics, and the current renderer preview without including the original large `.map`. In the web view, each returned rectangle and hammer badge has a click target; the downloaded PNG is intentionally a static export.

Response example shape:

```json
{
  "job_id": "…",
  "map_image_url": "/api/jobs/…/map.png",
  "report_json_url": "/api/jobs/…/report.json",
  "report_csv_url": "/api/jobs/…/report.csv",
  "markers_geojson_url": "/api/jobs/…/markers.geojson",
  "bundle_url": "/api/jobs/…/bundle.zip",
  "markers": [],
  "warnings": [],
  "visual_debug_url": "/api/jobs/…/visual-debug.zip"
}
```

The demo fixture is available at `/demo-map.json` and is also exposed through the UI.

## Map-coordinate and terrain assumptions

World X/Z coordinates are mapped against a centred terrain (`-size/2` through `+size/2`), matching RustEdit's terrain positioning. Height and topology layers use RustEdit's normal little-endian maps: normalized terrain shorts, and 32-bit topology bitmasks. The native raster rows are flipped top-to-bottom in the display compositor so RustEdit grid row A0 remains at the top; the report records this as `native_row_axis_flip_y` and the interactive markers/grid use the same transform. For exporters with another origin or vertical scale, include `origin`/`size_y` in JSON or change the height scale in the UI.

The visual compositor follows Rust's layer order: splat channels are Dirt, Forest, Grass, Gravel, Rock, Sand, Snow, Stones; biome channels are Arid, Temperate, Tundra, Arctic, and Jungle on current five-channel maps (with four-channel older maps still supported). The renderer uses the supplied exact splat palette, derives a heightmap normal-map hillshade at strength `1.5`, and uses Arctic/Tundra only to repair the sparse Snow paint. Water and offshore use `#2B515C`. The JSON report includes `map.visual_layers` channel diagnostics and `render.normal_map` settings so a large-map run can confirm which layers and shading strength were used.

Each job also exposes `markers.geojson` and `bundle.zip`. The bundle contains the clean PNG backdrop, JSON report, CSV report, GeoJSON points, and a notes file.

The clean PNG is a visual map backdrop and does not inject new game prefabs into the original `.map`; the source map remains unchanged. That avoids changing server content or requiring a marker prefab asset. The report contains exact world coordinates and all computed measurements for downstream map-editing workflows.
