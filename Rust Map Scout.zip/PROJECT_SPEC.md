# Rust Map Scout — authoritative project brief

## Required workflow

1. Ingest a Rust `.map` from upload or public URL.
2. Render the map from its terrain/topology/prefab data.
3. Show the rendered image in a pannable/zoomable web map.
4. Overlay configured prefabs and flat-area candidates.
5. Clicking an overlay shows short name, full path when known, X/Y/Z, Rust grid reference, scale, an exact extracted model link when supplied (or a self-contained category 3D-style preview fallback), topology and any rule-specific findings.
6. When a God Rock marker is selected, paint its sampled topology disk around the marker and show a compact colour-coded topology grid/legend, then export the clean PNG backdrop (without web overlays), JSON/CSV reports, GeoJSON, and a Docker-deployable bundle.

## Starter prefab rules

### God Rock

- `assets/bundled/prefabs/autospawn/decor/v3_rock_formations_large/rock_formation_a.prefab`
- `assets/bundled/prefabs/autospawn/decor/v3_rock_formations_large/rock_formation_e.prefab`
- `assets/bundled/prefabs/autospawn/decor/v3_rock_formations_large/rock_formation_f.prefab` (derived ID `291142845`)

Assess:

- Prefab Y versus sampled terrain Y at its position.
- Surrounding sampled Y values and Y range/flatness. The God Rock sample is a 27 × 27 north-up, 40 m-radius (80 × 80 m) window, keeping cells close to a 3 × 3 m foundation footprint. Each sampled cell has world-Y elevation, derived slope angle, and estimated Y rise across 3 m. North/South/East/West labels and world bounds make direction explicit. The heatmap is green for flatter terrain, transitions through yellow/orange as the 1.25 m adjacent-foundation height allowance is approached, and is red above that reference. The God Rock sample does not include topology category references.
- Expose the terrain measurements and heatmap without assigning an automatic poor/review/ideal build-spot result; the user makes that determination from the evidence.

### Ice Lakes

Numbered, potentially building-blocked:

- `assets/bundled/prefabs/autospawn/monument/ice_lakes/ice_lake_1.prefab`
- `assets/bundled/prefabs/autospawn/monument/ice_lakes/ice_lake_2.prefab`
- `assets/bundled/prefabs/autospawn/monument/ice_lakes/ice_lake_3.prefab`
- `assets/bundled/prefabs/autospawn/monument/ice_lakes/ice_lake_4.prefab`

Lettered, treated as no configured building blockers:

- `assets/content/nature/ice_lakes/models/ice_lake_a.prefab`
- `assets/content/nature/ice_lakes/models/ice_lake_b.prefab`
- `assets/content/nature/ice_lakes/models/ice_lake_c.prefab`
- `assets/content/nature/ice_lakes/models/ice_lake_d.prefab`

### Caves

Highlight all supplied cave paths; no special scoring beyond marker/topology display is currently required.

## Flat-area search

Run as a separate, bounded computation after prefab analysis. Find connected, large areas with low local Y deviation and low slope. Exclude configured water/cliff topology. Allow Y below 0 down to Y -1 by default; expose terrain-Y offset because exporters may use different vertical datums. Downsample larger maps to cap memory use.

## Known data constraint

Native Rust `PrefabData` contains a numeric prefab ID/hash, transform, and category rather than a human-readable path or mesh. The supplied starter paths now derive their uint IDs automatically from the full asset paths, so those rules work without a catalog. An ID catalog or asset/preview manifest is still needed for other prefab names and exact preview renders. The UI supports catalog/interchange entries with `name`, `preview_url`, `model_url`, `model_format`, and `asset_path`; set `RUST_ASSET_DIR` to expose legally obtained GLB/glTF/OBJ sidecar exports. Category 3D-style illustrations remain the fallback because the native map itself cannot supply Unity model bytes.

The map compositor uses Rust's splat order (Dirt, Forest, Grass, Gravel, Rock, Sand, Snow, Stones) and supports both older four-channel biome maps (Arid, Temperate, Tundra, Arctic) and current five-channel maps with Jungle. The renderer uses the supplied exact splat palette, derives a heightmap normal-map hillshade at strength `1.5`, and uses Arctic/Tundra context only to repair sparse Snow paint. Water and offshore use `#2B515C`. The supplied RustEdit reference establishes a top-to-bottom native row-axis correction, recorded as `native_row_axis_flip_y`; markers and grid overlays use the same transform. Reports expose decoded visual-layer and normal-map diagnostics when a large map is processed. Exact RustEdit texture detail still requires the corresponding terrain texture assets, while the built-in palette remains a safe fallback.
